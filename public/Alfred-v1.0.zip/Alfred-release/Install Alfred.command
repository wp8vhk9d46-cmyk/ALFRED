#!/bin/bash
# Install Alfred — double-click this file in Finder to install.
# Requires: macOS 12.3+, Python 3.10+, Anthropic API key.

DIR="$(cd "$(dirname "$0")" && pwd)"
ALFRED_HOME="$HOME/.alfred"
BACKEND_DST="$ALFRED_HOME/app"

clear
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  Alfred Installer                                        ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# macOS version check
OS_MAJOR=$(sw_vers -productVersion | cut -d. -f1)
if [ "$OS_MAJOR" -lt 12 ]; then
    echo "❌  macOS 12.3+ required. Found: $(sw_vers -productVersion)"
    read -rp "Press Enter to exit." _; exit 1
fi

# Python check
if ! command -v python3 &>/dev/null; then
    echo "❌  Python 3 not found."
    echo "    Install from: https://www.python.org/downloads/"
    open "https://www.python.org/downloads/"
    read -rp "Press Enter to exit." _; exit 1
fi
PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "   Python $PY_VER ✓"

# Create dirs
echo "▸ Creating ~/.alfred..."
mkdir -p "$ALFRED_HOME/logs" "$ALFRED_HOME/generated" "$ALFRED_HOME/app"

# Install Python deps
echo "▸ Installing Python packages..."
python3 -m pip install --quiet --break-system-packages \
    anthropic python-dotenv requests openai 2>/dev/null || \
python3 -m pip install --quiet \
    anthropic python-dotenv requests openai
echo "   anthropic, python-dotenv, requests, openai ✓"

# Copy backend
echo "▸ Installing backend..."
cp -r "$DIR/backend/." "$BACKEND_DST/"
echo "   Backend → $BACKEND_DST ✓"

# Copy Alfred.app
echo "▸ Installing Alfred.app..."
rm -rf "/Applications/Alfred.app"
cp -r "$DIR/Alfred.app" "/Applications/Alfred.app"
codesign --force --deep --sign - "/Applications/Alfred.app" 2>/dev/null || true
echo "   /Applications/Alfred.app ✓"

# API key setup
ENV_FILE="$ALFRED_HOME/.env"
if [ ! -f "$ENV_FILE" ] || ! grep -q "ANTHROPIC_API_KEY=sk-" "$ENV_FILE" 2>/dev/null; then
    echo ""
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║  API Key Required                                        ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    echo "  Alfred needs an Anthropic API key to talk to Claude."
    echo "  Get yours free at: https://console.anthropic.com/"
    echo ""
    read -rp "  Paste your Anthropic API key (sk-ant-...): " API_KEY
    if [[ "$API_KEY" == sk-* ]]; then
        echo "ANTHROPIC_API_KEY=$API_KEY" > "$ENV_FILE"
        echo "   API key saved ✓"
    else
        echo "   ⚠️  Key doesn't look right — saved anyway. Edit ~/.alfred/.env to fix."
        echo "ANTHROPIC_API_KEY=$API_KEY" > "$ENV_FILE"
    fi

    # Optional: OpenAI for image generation
    echo ""
    read -rp "  OpenAI API key for image generation (optional, press Enter to skip): " OAI_KEY
    if [[ "$OAI_KEY" == sk-* ]]; then
        echo "OPENAI_API_KEY=$OAI_KEY" >> "$ENV_FILE"
        echo "   OpenAI key saved ✓"
    fi
else
    echo "   API key already configured ✓"
fi

# Launch
echo ""
echo "▸ Launching Alfred..."
open "/Applications/Alfred.app"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  ✅  Alfred is installed!                                ║"
echo "║                                                          ║"
echo "║  Look for the ▲ icon in your menu bar.                  ║"
echo "║  Press Cmd+Shift+J anywhere to open the bar.            ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
read -rp "Press Enter to close this window." _
