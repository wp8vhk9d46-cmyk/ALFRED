"""
memory.py — Local knowledge base for the voice assistant
SQLite-backed, semantic-ish search via keyword matching + recency scoring
"""

import json
import sqlite3
import time
import re
from datetime import datetime

from config import MEMORY_DB as DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    summary      TEXT    NOT NULL,
    detail       TEXT    NOT NULL DEFAULT '',
    tags         TEXT    NOT NULL DEFAULT '[]',
    source       TEXT    NOT NULL DEFAULT 'auto',
    created_at   REAL    NOT NULL,
    accessed_at  REAL    NOT NULL,
    access_count INTEGER NOT NULL DEFAULT 0,
    useful       INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_mem_accessed ON memories(accessed_at DESC);
CREATE INDEX IF NOT EXISTS idx_mem_source  ON memories(source);

CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    summary, detail, tags,
    content='memories',
    content_rowid='id'
);

CREATE TRIGGER IF NOT EXISTS mem_ai AFTER INSERT ON memories BEGIN
    INSERT INTO memories_fts(rowid, summary, detail, tags)
    VALUES (new.id, new.summary, new.detail, new.tags);
END;

CREATE TRIGGER IF NOT EXISTS mem_ad AFTER DELETE ON memories BEGIN
    INSERT INTO memories_fts(memories_fts, rowid, summary, detail, tags)
    VALUES ('delete', old.id, old.summary, old.detail, old.tags);
END;

CREATE TRIGGER IF NOT EXISTS mem_au AFTER UPDATE ON memories BEGIN
    INSERT INTO memories_fts(memories_fts, rowid, summary, detail, tags)
    VALUES ('delete', old.id, old.summary, old.detail, old.tags);
    INSERT INTO memories_fts(rowid, summary, detail, tags)
    VALUES (new.id, new.summary, new.detail, new.tags);
END;
"""


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.row_factory = sqlite3.Row
    return conn


# ── Chat History ────────────────────────────────────────────────────────────────
def init_chat_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS chat_history (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            role      TEXT    NOT NULL,
            content   TEXT    NOT NULL,
            created_at REAL   NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_chat_ts ON chat_history(created_at DESC)")
    conn.commit()
    conn.close()


MAX_CHAT_MESSAGES = 60  # keep last 60 messages (30 exchanges)


def save_conversation(messages: list[dict]):
    """Save the current conversation window to SQLite."""
    if not messages:
        return
    now = time.time()
    conn = get_db()
    try:
        conn.execute("DELETE FROM chat_history")
        for m in messages:
            conn.execute(
                "INSERT INTO chat_history (role, content, created_at) VALUES (?, ?, ?)",
                (str(m.get("role", "user")), str(m.get("content", ""))[:10000], now)
            )
        conn.commit()
    finally:
        conn.close()


def load_conversation() -> list[dict]:
    """Load saved conversation. Returns list of {role, content} dicts."""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT role, content FROM chat_history ORDER BY id ASC LIMIT ?",
            (MAX_CHAT_MESSAGES,)
        ).fetchall()
    finally:
        conn.close()
    return [{"role": r["role"], "content": r["content"]} for r in rows]


def init_db():
    conn = get_db()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


# ── Save ────────────────────────────────────────────────────────────────────────
def save_memory(summary: str, detail: str, tags: list[str], source: str = "auto") -> int:
    """Save a new memory. Returns the new memory ID."""
    now = time.time()
    tags_json = json.dumps([t.lower().strip() for t in tags])
    conn = get_db()
    cur = conn.execute(
        """INSERT INTO memories (summary, detail, tags, source, created_at, accessed_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (summary.strip(), detail.strip(), tags_json, source, now, now)
    )
    mid = cur.lastrowid
    conn.commit()
    conn.close()
    return mid


# ── Search ──────────────────────────────────────────────────────────────────────
def search_memories(query: str, limit: int = 5) -> list[dict]:
    """
    Search memories by query. Uses FTS5 full-text search + recency boost.
    Returns list of dicts with id, summary, detail, tags, source, created_at.
    """
    if not query or not query.strip():
        return []

    conn = get_db()

    # Extract keywords from query (remove stop words)
    stop = {"the","a","an","is","are","was","were","be","been","being","have","has",
            "had","do","does","did","will","would","could","should","may","might",
            "shall","can","need","dare","ought","used","to","of","in","for","on",
            "with","at","by","from","up","about","into","through","and","or","but",
            "if","then","that","this","it","i","you","my","your","me","we","us"}
    words = [w for w in re.findall(r'\w+', query.lower()) if w not in stop and len(w) > 2]

    if not words:
        # Fallback: just return most recent
        rows = conn.execute(
            "SELECT * FROM memories WHERE useful=1 ORDER BY accessed_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        conn.close()
        return [_row_to_dict(r) for r in rows]

    # FTS search
    fts_query = " OR ".join(words)
    try:
        rows = conn.execute(
            """SELECT m.*, rank
               FROM memories m
               JOIN memories_fts fts ON m.id = fts.rowid
               WHERE memories_fts MATCH ? AND m.useful = 1
               ORDER BY rank
               LIMIT ?""",
            (fts_query, limit * 2)
        ).fetchall()
    except Exception:
        rows = []

    # Also do simple LIKE search as fallback/supplement
    like_conditions = " OR ".join(
        ["summary LIKE ? OR detail LIKE ? OR tags LIKE ?"] * len(words)
    )
    like_params = []
    for w in words:
        like_params += [f"%{w}%", f"%{w}%", f"%{w}%"]
    like_params.append(limit * 2)

    like_rows = conn.execute(
        f"SELECT * FROM memories WHERE useful=1 AND ({like_conditions}) ORDER BY accessed_at DESC LIMIT ?",
        like_params
    ).fetchall()

    conn.close()

    # Merge results, deduplicate by id, score by recency + access count
    seen = set()
    results = []
    now = time.time()

    for r in list(rows) + list(like_rows):
        rid = r["id"]
        if rid in seen:
            continue
        seen.add(rid)
        d = _row_to_dict(r)
        # Recency score: decay over ~30 days
        age_days = (now - r["accessed_at"]) / 86400
        recency_score = max(0, 1 - age_days / 30)
        d["_score"] = recency_score + (r["access_count"] * 0.05)
        results.append(d)

    results.sort(key=lambda x: x["_score"], reverse=True)
    return results[:limit]


def _row_to_dict(row) -> dict:
    d = dict(row)
    try:
        d["tags"] = json.loads(d.get("tags") or "[]")
    except:
        d["tags"] = []
    d.pop("_score", None)
    d.pop("rank", None)
    return d


# ── Mark accessed ───────────────────────────────────────────────────────────────
def mark_accessed(memory_id: int):
    conn = get_db()
    conn.execute(
        "UPDATE memories SET accessed_at=?, access_count=access_count+1 WHERE id=?",
        (time.time(), memory_id)
    )
    conn.commit()
    conn.close()


# ── Stats ───────────────────────────────────────────────────────────────────────
def get_stats() -> dict:
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM memories WHERE useful=1").fetchone()[0]
    auto  = conn.execute("SELECT COUNT(*) FROM memories WHERE useful=1 AND source='auto'").fetchone()[0]
    manual = conn.execute("SELECT COUNT(*) FROM memories WHERE useful=1 AND source='manual'").fetchone()[0]
    recent = conn.execute(
        "SELECT summary FROM memories WHERE useful=1 ORDER BY created_at DESC LIMIT 3"
    ).fetchall()
    conn.close()
    return {
        "total": total,
        "auto": auto,
        "manual": manual,
        "recent": [r["summary"] for r in recent]
    }


# ── Format for prompt ───────────────────────────────────────────────────────────
def format_memories_for_prompt(memories: list[dict]) -> str:
    if not memories:
        return ""
    lines = ["[Relevant memories from past conversations:]"]
    for i, m in enumerate(memories, 1):
        tags_str = ", ".join(m["tags"][:4]) if m["tags"] else ""
        date_str = datetime.fromtimestamp(m["created_at"]).strftime("%b %d")
        lines.append(f"{i}. [{date_str}] {m['summary']}")
        if m["detail"] and m["detail"] != m["summary"]:
            # Truncate detail
            detail = m["detail"][:200] + ("..." if len(m["detail"]) > 200 else "")
            lines.append(f"   Detail: {detail}")
        if tags_str:
            lines.append(f"   Tags: {tags_str}")
    return "\n".join(lines)


# ── CLI for browsing memories ────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    stats = get_stats()
    print(f"\n📚 Memory Database — {DB_PATH}")
    print(f"   Total: {stats['total']} memories ({stats['auto']} auto, {stats['manual']} manual)")
    if stats["recent"]:
        print(f"   Recent: {', '.join(stats['recent'])}")
    print()

    import sys
    if len(sys.argv) > 1:
        query = " ".join(sys.argv[1:])
        results = search_memories(query)
        print(f"Search: '{query}' → {len(results)} results\n")
        for r in results:
            print(f"[{r['id']}] {r['summary']}")
            print(f"     {r['detail'][:120]}")
            print(f"     tags: {r['tags']}  source: {r['source']}")
            print()
    else:
        conn = get_db()
        rows = conn.execute(
            "SELECT * FROM memories WHERE useful=1 ORDER BY created_at DESC LIMIT 20"
        ).fetchall()
        conn.close()
        for r in rows:
            d = _row_to_dict(r)
            date = datetime.fromtimestamp(d["created_at"]).strftime("%b %d %H:%M")
            print(f"[{d['id']}] ({date}) {d['summary']}")
            print(f"     tags: {d['tags']}  accessed: {d['access_count']}x")
            print()
