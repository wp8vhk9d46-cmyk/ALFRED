"""
followups.py — Generate "next action" chips after substantial responses.

After Alfred answers something meaningful, suggest 2-4 short next steps.
Makes it feel like an agent that's thinking ahead, not a search box.

Public:
    suggest(query, answer, client) -> list[dict {label, query}]
        Returns 0-4 follow-up chips. Returns [] for trivial answers.

    should_suggest(query, answer) -> bool
        Quick heuristic to skip on greetings, math, errors, etc.
"""
from __future__ import annotations
import re
import json


FOLLOWUP_MODEL = "claude-haiku-4-5-20251001"


# Skip followups for these query types — they're complete by themselves
_SKIP_PATTERNS = [
    r"^\s*(hi|hey|hello|yo|sup|good (morning|night|afternoon|evening))",
    r"^\s*\d+\s*[+\-*/]",  # math
    r"^\s*what'?s? \d",
    r"^\s*lock my screen",
    r"^\s*set (volume|brightness)",
    r"^\s*open ",
    r"^\s*launch ",
    r"^\s*time$",
    r"^\s*what time",
    r"^\s*remember (that|my)",  # memory adds — answer is "saved"
]


def should_suggest(query: str, answer: str) -> bool:
    """Quick gate — only suggest followups for substantive answers."""
    if not answer or len(answer) < 100:
        return False
    if not query:
        return False
    q_low = query.lower().strip()
    for pat in _SKIP_PATTERNS:
        if re.search(pat, q_low):
            return False
    # Skip if answer is just an error or "Done"
    if answer.lower().startswith(("error", "couldn't", "i couldn't",
                                   "no ", "done", "opening", "opened")):
        return False
    return True


def suggest(query: str, answer: str, client) -> list[dict]:
    """
    Return 0-4 follow-up chips. Each is {label, query}.
    Empty list on any failure or for trivial answers.
    """
    if not should_suggest(query, answer):
        return []

    prompt = (
        f"User asked: {query!r}\n\n"
        f"Alfred answered:\n```\n{answer[:2500]}\n```\n\n"
        f"Suggest 2-3 NEXT actions the user might want to take based on this answer. "
        f"Each should be a SHORT chip label (≤4 words) plus the actual query "
        f"to send if they tap it.\n\n"
        f"Output ONLY a JSON array like:\n"
        f'[{{"label": "Compare to last year", "query": "compare this to last year"}},\n'
        f' {{"label": "Track daily", "query": "track this topic daily and notify me"}}]\n\n'
        f"Rules:\n"
        f"- 2-3 suggestions max\n"
        f"- Labels must be ≤4 words and feel like buttons\n"
        f"- Queries should be natural — what the user would actually type\n"
        f"- Suggestions must build on the actual answer, not be generic\n"
        f"- Skip suggestions like 'tell me more' — be specific\n"
        f"- If nothing useful comes to mind, return []\n"
        f"- JSON only, no prose"
    )

    try:
        resp = client.messages.create(
            model=FOLLOWUP_MODEL,
            max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = resp.content[0].text.strip()
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.MULTILINE)
        chips = json.loads(raw)
        if not isinstance(chips, list):
            return []
        # Validate + cap at 3
        cleaned = []
        for c in chips[:3]:
            if not isinstance(c, dict): continue
            label = str(c.get("label", "")).strip()
            q = str(c.get("query", "")).strip()
            if 2 <= len(label) <= 30 and 2 <= len(q) <= 200:
                cleaned.append({"label": label, "query": q})
        return cleaned
    except Exception as e:
        print(f"[followups] failed: {e}")
        return []
