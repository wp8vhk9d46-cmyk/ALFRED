"""
background_tasks.py — Run Alfred tasks in the background while the user works.

Triggers when query starts with "in the background" / "while I work" /
"meanwhile" / etc. Spawns the task as a detached asyncio Task, returns
control immediately, surfaces the result via:

  1. macOS notification when complete
  2. "show my background tasks" / "what did you find" follow-up query

Public API:
    is_background_request(text) -> bool, cleaned_text
    spawn(text, run_coro_factory) -> task_id
    list_tasks() -> list[dict]
    get_summary() -> str  (used when user asks "what did you find")
    pop_finished() -> list[dict]  (consumed once, then forgotten)

Tasks are stored in-memory; on Alfred restart they're forgotten. That's
the right tradeoff for a 'while I work' feature — these are session tasks.
"""
from __future__ import annotations
import asyncio
import time
import uuid
import subprocess
from typing import Callable, Awaitable


# In-memory registry. Maps task_id → record dict.
_tasks: dict[str, dict] = {}


# ── Detection ─────────────────────────────────────────────────────────────────

_BG_TRIGGERS = [
    "in the background", "in background",
    "while i work", "while i'm working", "while i am working",
    "meanwhile",
    "asynchronously",
    "in parallel",
    "go research", "go find", "go look up",  # implies non-blocking
]


def is_background_request(text: str) -> tuple[bool, str]:
    """
    Returns (is_background, cleaned_text) where cleaned_text is the query
    minus the background-trigger phrase.

    Safety: explicitly REJECTS meta-questions about background tasks
    (e.g. "summarize what I asked you to do in the background") so they
    aren't recursively re-spawned.
    """
    if not text:
        return False, text
    t_low = text.lower().strip()

    # Never re-spawn a query that's ASKING ABOUT background tasks
    meta_phrases = [
        "what i asked you to do",
        "what you're doing",
        "what you are doing",
        "what is running",
        "what's running",
        "background task", "background job",
        "what did you find",
        "show my task", "show tasks", "list tasks",
    ]
    if any(p in t_low for p in meta_phrases):
        return False, text

    for trig in _BG_TRIGGERS:
        # Match at the START of the query — strong intent signal
        if t_low.startswith(trig):
            cleaned = text[len(trig):].lstrip(" ,:").strip()
            if cleaned:
                return True, cleaned
        # Match "<task>, in the background" at the END of the query
        # (only matches if trigger is in the LAST 30% of the text)
        comma_pat = ", " + trig
        space_pat = " " + trig
        idx = t_low.rfind(comma_pat)
        if idx == -1:
            idx = t_low.rfind(space_pat)
        # Trigger must be in the last 30% of the text — not buried mid-sentence
        if idx > 0 and idx > len(t_low) * 0.5:
            # And what follows the trigger should be empty or a tail
            tail = t_low[idx + len(comma_pat if comma_pat in t_low else space_pat):].strip()
            if tail in ("", ".", "!", "please", "please.", "thanks"):
                cleaned = text[:idx].strip().rstrip(",")
                if cleaned and len(cleaned) > 5:
                    return True, cleaned
    return False, text


def is_status_query(text: str) -> bool:
    """Detect 'what are my background tasks' / 'what did you find'."""
    t = text.lower().strip()
    return any(p in t for p in [
        "background task", "background job",
        "what did you find", "what's the status",
        "what is the status", "show my tasks", "show tasks",
        "any updates", "are you done",
        "what i asked you to do",  # "summarize what i asked you to do"
        "what you found",
    ])


def has_unread_results() -> bool:
    """Are there finished tasks the user hasn't been shown the result of yet?"""
    return any(r["status"] in ("done", "error") and not r["consumed"]
               for r in _tasks.values())


def get_unread_summary() -> str:
    """One-line summary for surfacing on bar open."""
    unread = [r for r in _tasks.values()
              if r["status"] in ("done", "error") and not r["consumed"]]
    if not unread:
        return ""
    if len(unread) == 1:
        r = unread[0]
        verb = "Done" if r["status"] == "done" else "Failed"
        return f"{verb}: {r['query'][:70]}"
    return f"{len(unread)} background tasks finished — say 'show my tasks'."


# ── Spawn ─────────────────────────────────────────────────────────────────────

def spawn(query: str, coro_factory: Callable[[], Awaitable[str]],
          loop: asyncio.AbstractEventLoop | None = None) -> str:
    """
    Schedule a background task. `coro_factory` is a callable that returns
    a coroutine (we call it inside the loop). Returns a short task_id.
    """
    task_id = uuid.uuid4().hex[:6]
    record = {
        "id": task_id,
        "query": query,
        "started_at": time.time(),
        "completed_at": None,
        "status": "running",   # running | done | error
        "result": "",
        "error": "",
        "task": None,
        "consumed": False,
    }
    _tasks[task_id] = record

    async def _runner():
        try:
            result = await coro_factory()
            record["result"] = result or ""
            record["status"] = "done"
        except Exception as e:
            record["error"] = str(e)
            record["status"] = "error"
        finally:
            record["completed_at"] = time.time()
            _notify_complete(record)

    loop = loop or asyncio.get_event_loop()
    record["task"] = loop.create_task(_runner())
    print(f"[bg] spawned [{task_id}]: {query[:60]}")
    return task_id


# ── Status / pop ──────────────────────────────────────────────────────────────

def list_tasks() -> list[dict]:
    """Return public summary of all tasks (no internal task object)."""
    return [
        {k: v for k, v in r.items() if k != "task"}
        for r in _tasks.values()
    ]


def get_summary() -> str:
    """Human-readable summary of all background tasks (running + finished)."""
    if not _tasks:
        return "No background tasks have been started."
    lines = []
    running = [r for r in _tasks.values() if r["status"] == "running"]
    done    = [r for r in _tasks.values() if r["status"] == "done"]
    errored = [r for r in _tasks.values() if r["status"] == "error"]

    if running:
        lines.append(f"**Still running** ({len(running)}):")
        for r in running:
            elapsed = int(time.time() - r["started_at"])
            lines.append(f"  • [{r['id']}] {r['query'][:80]} ({elapsed}s)")

    if done:
        lines.append(f"\n**Completed** ({len(done)}):")
        for r in done:
            lines.append(f"\n— [{r['id']}] **{r['query'][:80]}**")
            result = r["result"] or "(no result)"
            lines.append(result[:1500])

    if errored:
        lines.append(f"\n**Failed** ({len(errored)}):")
        for r in errored:
            lines.append(f"  • [{r['id']}] {r['query'][:80]}: {r['error']}")

    return "\n".join(lines)


def pop_finished() -> list[dict]:
    """
    Return finished, unconsumed tasks. Marks them consumed so we don't
    re-show them.
    """
    out = []
    for r in _tasks.values():
        if r["status"] in ("done", "error") and not r["consumed"]:
            r["consumed"] = True
            out.append({k: v for k, v in r.items() if k != "task"})
    return out


def clear_finished() -> int:
    """Drop all finished tasks. Returns count removed."""
    to_drop = [k for k, r in _tasks.items()
               if r["status"] in ("done", "error")]
    for k in to_drop:
        _tasks.pop(k, None)
    return len(to_drop)


# ── Notification ──────────────────────────────────────────────────────────────

def _notify_complete(record: dict) -> None:
    """Log task completion and fire a macOS system notification.
    Results also surface on next bar open via the unread-summary banner."""
    if record["status"] == "done":
        print(f"[bg] ✓ task {record['id']} complete: {record['query'][:60]}")
        short_query = record["query"][:60]
        body = f"Background task done: {short_query}"
        try:
            import subprocess
            subprocess.run(
                [
                    "osascript", "-e",
                    f'display notification "{body}" with title "Alfred" sound name "Submarine"',
                ],
                capture_output=True,
                timeout=5,
            )
        except Exception as _e:
            print(f"[bg] notification failed: {_e}")
    else:
        print(f"[bg] ✗ task {record['id']} failed: {record['error'][:80]}")
