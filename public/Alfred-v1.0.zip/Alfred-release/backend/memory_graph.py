"""
memory_graph.py — Entity-relation memory with temporal reasoning

Upgrades Alfred's flat memory (memory.py) with a knowledge graph layer:
  - Entities: people, projects, places, things the user mentions
  - Relations: typed edges between entities ("works_at", "discussed", "decided")
  - Timestamps: every fact is dated, so the graph can answer "when did X happen"
  - Contradictions: newer facts override older ones automatically

This sits NEXT TO the existing memory.py, not replacing it. The flat memory
still stores conversational summaries; the graph stores structured facts.

DEMO MOMENT: ask "what did we decide last Tuesday about pricing?" and the
graph retrieves the decision with its timestamp and surrounding context.
"""

import re
import json
import time
import sqlite3
from datetime import datetime, timedelta
from typing import Optional

from config import MEMORY_GRAPH_DB as GRAPH_DB


SCHEMA = """
CREATE TABLE IF NOT EXISTS entities (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    type        TEXT NOT NULL,
    aliases     TEXT,
    first_seen  REAL NOT NULL,
    last_seen   REAL NOT NULL,
    UNIQUE(name, type)
);
CREATE INDEX IF NOT EXISTS idx_ent_name ON entities(name);
CREATE INDEX IF NOT EXISTS idx_ent_type ON entities(type);

CREATE TABLE IF NOT EXISTS facts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id   INTEGER NOT NULL,
    predicate    TEXT NOT NULL,
    object_text  TEXT NOT NULL,
    object_id    INTEGER,
    timestamp    REAL NOT NULL,
    source       TEXT DEFAULT 'auto',
    superseded   INTEGER DEFAULT 0,
    confidence   REAL DEFAULT 1.0,
    FOREIGN KEY (subject_id) REFERENCES entities(id),
    FOREIGN KEY (object_id) REFERENCES entities(id)
);
CREATE INDEX IF NOT EXISTS idx_facts_subj ON facts(subject_id);
CREATE INDEX IF NOT EXISTS idx_facts_pred ON facts(predicate);
CREATE INDEX IF NOT EXISTS idx_facts_ts ON facts(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_facts_super ON facts(superseded);

CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(
    object_text, content='facts', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS facts_ai AFTER INSERT ON facts BEGIN
    INSERT INTO facts_fts(rowid, object_text) VALUES (new.id, new.object_text);
END;
"""


def _db():
    conn = sqlite3.connect(GRAPH_DB)
    conn.row_factory = sqlite3.Row
    return conn


def _init():
    conn = _db()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


_init()


# ── Entities ──────────────────────────────────────────────────────────────────

def upsert_entity(name: str, etype: str = "thing", aliases: list[str] = None) -> int:
    name = name.strip()
    etype = etype.strip().lower()
    if not name:
        return -1
    now = time.time()
    aliases_json = json.dumps(aliases or [])
    conn = _db()
    existing = conn.execute(
        "SELECT id FROM entities WHERE name=? AND type=?", (name, etype)
    ).fetchone()
    if existing:
        conn.execute("UPDATE entities SET last_seen=? WHERE id=?", (now, existing["id"]))
        conn.commit()
        eid = existing["id"]
    else:
        cur = conn.execute(
            "INSERT INTO entities (name, type, aliases, first_seen, last_seen) VALUES (?,?,?,?,?)",
            (name, etype, aliases_json, now, now)
        )
        eid = cur.lastrowid
        conn.commit()
    conn.close()
    return eid


def find_entity(name: str) -> Optional[dict]:
    """Find an entity by name or alias (case-insensitive, fuzzy)."""
    name_low = name.strip().lower()
    conn = _db()
    # Exact name match
    rows = conn.execute(
        "SELECT * FROM entities WHERE LOWER(name)=? ORDER BY last_seen DESC", (name_low,)
    ).fetchall()
    if not rows:
        # Try alias match
        rows = conn.execute(
            "SELECT * FROM entities WHERE LOWER(aliases) LIKE ? ORDER BY last_seen DESC",
            (f'%"{name_low}"%',)
        ).fetchall()
    if not rows:
        # Fuzzy: contains
        rows = conn.execute(
            "SELECT * FROM entities WHERE LOWER(name) LIKE ? ORDER BY last_seen DESC LIMIT 5",
            (f"%{name_low}%",)
        ).fetchall()
    conn.close()
    if not rows:
        return None
    e = dict(rows[0])
    try:
        e["aliases"] = json.loads(e.get("aliases") or "[]")
    except Exception:
        e["aliases"] = []
    return e


# ── Facts ─────────────────────────────────────────────────────────────────────

# Predicates that should supersede older values (one-true-value)
SUPERSEDING_PREDICATES = {
    "works_at", "lives_in", "located_at", "manages", "uses", "prefers",
    "current_role", "owns", "married_to", "current_status",
}


def add_fact(subject: str, predicate: str, obj: str,
             subject_type: str = "thing",
             object_type: Optional[str] = None,
             timestamp: Optional[float] = None,
             source: str = "auto",
             confidence: float = 1.0) -> int:
    if not subject or not predicate or not obj:
        return -1
    ts = timestamp if timestamp is not None else time.time()
    pred = predicate.strip().lower().replace(" ", "_")

    sid = upsert_entity(subject, subject_type)
    oid = None
    if object_type:
        oid = upsert_entity(obj, object_type)

    conn = _db()
    # If superseding, mark old facts for this (subject, predicate) as superseded
    if pred in SUPERSEDING_PREDICATES:
        conn.execute(
            "UPDATE facts SET superseded=1 WHERE subject_id=? AND predicate=? AND superseded=0",
            (sid, pred)
        )
    cur = conn.execute(
        """INSERT INTO facts (subject_id, predicate, object_text, object_id, timestamp, source, confidence)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (sid, pred, obj, oid, ts, source, confidence)
    )
    fid = cur.lastrowid
    conn.commit()
    conn.close()

    try:
        from obsidian_logger import log_fact
        log_fact(subject, predicate, obj, ts, confidence, source)
    except Exception:
        pass

    return fid


def get_facts_about(name: str, include_superseded: bool = False) -> list[dict]:
    e = find_entity(name)
    if not e:
        return []
    conn = _db()
    if include_superseded:
        rows = conn.execute(
            "SELECT * FROM facts WHERE subject_id=? ORDER BY timestamp DESC", (e["id"],)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM facts WHERE subject_id=? AND superseded=0 ORDER BY timestamp DESC",
            (e["id"],)
        ).fetchall()
    conn.close()
    return [_fact_to_dict(r) for r in rows]


def search_facts(query: str, since: Optional[float] = None,
                 until: Optional[float] = None, limit: int = 10) -> list[dict]:
    """Free-text search over facts, optionally bounded by time."""
    conn = _db()
    sql = """SELECT facts.* FROM facts
             JOIN facts_fts ON facts.id = facts_fts.rowid
             WHERE facts_fts MATCH ? AND facts.superseded=0"""
    params = [query]
    if since is not None:
        sql += " AND facts.timestamp >= ?"
        params.append(since)
    if until is not None:
        sql += " AND facts.timestamp <= ?"
        params.append(until)
    sql += " ORDER BY facts.timestamp DESC LIMIT ?"
    params.append(limit)
    try:
        rows = conn.execute(sql, params).fetchall()
    except Exception:
        # FTS query failed (special chars) — fall back to LIKE
        sql = """SELECT * FROM facts WHERE superseded=0 AND object_text LIKE ?"""
        params = [f"%{query}%"]
        if since is not None:
            sql += " AND timestamp >= ?"
            params.append(since)
        if until is not None:
            sql += " AND timestamp <= ?"
            params.append(until)
        sql += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [_fact_to_dict(r) for r in rows]


def _fact_to_dict(row) -> dict:
    d = dict(row)
    d["timestamp_str"] = datetime.fromtimestamp(d["timestamp"]).strftime("%b %d %Y %H:%M")
    # Resolve subject name
    conn = _db()
    s = conn.execute("SELECT name, type FROM entities WHERE id=?", (d["subject_id"],)).fetchone()
    if s:
        d["subject"] = s["name"]
        d["subject_type"] = s["type"]
    conn.close()
    return d


# ── Time parsing for natural queries ──────────────────────────────────────────

def parse_time_phrase(phrase: str) -> tuple[Optional[float], Optional[float]]:
    """
    Parse a natural time phrase to (since, until) timestamps.
    Examples: "yesterday", "last week", "last Tuesday", "this morning"
    Returns (None, None) if unparseable.
    """
    p = phrase.lower().strip()
    now = datetime.now()

    if "yesterday" in p:
        start = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        return start.timestamp(), end.timestamp()

    if "today" in p or "this morning" in p:
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        return start.timestamp(), now.timestamp()

    if "this week" in p:
        start = now - timedelta(days=now.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        return start.timestamp(), now.timestamp()

    if "last week" in p:
        last_monday = now - timedelta(days=now.weekday() + 7)
        last_monday = last_monday.replace(hour=0, minute=0, second=0, microsecond=0)
        last_sunday = last_monday + timedelta(days=7)
        return last_monday.timestamp(), last_sunday.timestamp()

    if "last month" in p:
        first_this = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        last_month_end = first_this - timedelta(seconds=1)
        first_last = last_month_end.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        return first_last.timestamp(), first_this.timestamp()

    # "last Tuesday" / "last Friday"
    weekdays = ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
    for i, day in enumerate(weekdays):
        if f"last {day}" in p or f"on {day}" in p:
            days_back = (now.weekday() - i) % 7
            if days_back == 0:
                days_back = 7
            target = (now - timedelta(days=days_back)).replace(hour=0, minute=0, second=0, microsecond=0)
            return target.timestamp(), (target + timedelta(days=1)).timestamp()

    # "N days ago" / "N hours ago"
    m = re.search(r"(\d+)\s+(day|hour|week|minute)s?\s+ago", p)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        delta_map = {"minute": timedelta(minutes=n),
                     "hour":   timedelta(hours=n),
                     "day":    timedelta(days=n),
                     "week":   timedelta(weeks=n)}
        target = now - delta_map[unit]
        return target.timestamp() - 600, target.timestamp() + 600  # 20 min window

    return None, None


# ── Extraction (Claude reads conversation, pulls structured facts) ────────────

EXTRACT_SYSTEM = """You extract structured facts from a conversation snippet for a knowledge graph.

Return ONLY valid JSON in this format:
{
  "entities": [
    {"name": "...", "type": "person|project|company|place|thing|topic"}
  ],
  "facts": [
    {"subject": "Alice", "predicate": "works_at", "object": "Acme Corp",
     "subject_type": "person", "object_type": "company"}
  ]
}

Rules:
- Only extract facts the user clearly STATED, not implied or hypothetical
- Predicates should be short snake_case verbs ("works_at", "discussed", "decided", "prefers", "owns")
- Use the user's exact terminology
- If nothing is worth saving, return {"entities": [], "facts": []}
- Skip generic facts the system already knows ("water is wet")"""


def extract_and_save(conversation_text: str, client) -> int:
    """
    Send conversation snippet to Claude, extract entities/facts, save to graph.
    Returns number of facts added.
    """
    if not client or not conversation_text.strip():
        return 0
    try:
        resp = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=600,
            system=EXTRACT_SYSTEM,
            messages=[{"role": "user", "content": conversation_text[:3000]}]
        )
        raw = resp.content[0].text.strip()
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.MULTILINE).strip()
        data = json.loads(raw)

        # Add entities first
        for e in data.get("entities", []):
            upsert_entity(e.get("name", ""), e.get("type", "thing"))

        added = 0
        for f in data.get("facts", []):
            fid = add_fact(
                subject=f.get("subject", ""),
                predicate=f.get("predicate", ""),
                obj=f.get("object", ""),
                subject_type=f.get("subject_type", "thing"),
                object_type=f.get("object_type"),
            )
            if fid > 0:
                added += 1
        if added:
            print(f"[graph] Added {added} facts from conversation")
        return added
    except Exception as e:
        print(f"[graph] Extraction failed: {e}")
        return 0


# ── Query ─────────────────────────────────────────────────────────────────────

def answer_temporal_question(query: str, client) -> Optional[str]:
    """
    Answer questions like "what did we decide last Tuesday about pricing".
    Returns a natural-language answer or None if no facts found.
    """
    # Detect time phrase
    time_phrases = ["yesterday", "today", "this week", "last week", "last month",
                    "this morning", "last monday", "last tuesday", "last wednesday",
                    "last thursday", "last friday", "last saturday", "last sunday"]
    matched_phrase = None
    for tp in time_phrases:
        if tp in query.lower():
            matched_phrase = tp
            break
    if not matched_phrase:
        m = re.search(r"\d+\s+(?:day|hour|week|minute)s?\s+ago", query.lower())
        if m:
            matched_phrase = m.group(0)

    since, until = (None, None)
    if matched_phrase:
        since, until = parse_time_phrase(matched_phrase)

    # Extract topic keywords from query (drop time phrase + question words)
    cleaned = query.lower()
    if matched_phrase:
        cleaned = cleaned.replace(matched_phrase, "")
    for w in ["what", "did", "we", "say", "decide", "discuss", "talk", "about",
              "the", "a", "an", "on", "in", "tell", "me", "and", "or"]:
        cleaned = re.sub(rf"\b{w}\b", "", cleaned)
    topic = cleaned.strip(" ?.,").strip() or query

    facts = search_facts(topic, since=since, until=until, limit=10)
    if not facts:
        return None

    # Synthesize with Claude
    fact_lines = "\n".join(
        f"[{f['timestamp_str']}] {f.get('subject','?')} {f['predicate']} {f['object_text']}"
        for f in facts
    )
    prompt = (
        f"User asked: {query}\n\n"
        f"Relevant facts from memory graph:\n{fact_lines}\n\n"
        "Answer the user's question naturally based on these facts. "
        "Cite when each fact happened if relevant. Be concise."
    )
    try:
        resp = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=400,
            messages=[{"role": "user", "content": prompt}]
        )
        return resp.content[0].text.strip()
    except Exception as e:
        return f"Found {len(facts)} relevant facts but couldn't synthesize: {e}"


def stats() -> dict:
    conn = _db()
    n_ent  = conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
    n_fact = conn.execute("SELECT COUNT(*) FROM facts WHERE superseded=0").fetchone()[0]
    n_sup  = conn.execute("SELECT COUNT(*) FROM facts WHERE superseded=1").fetchone()[0]
    types_rows = conn.execute(
        "SELECT type, COUNT(*) c FROM entities GROUP BY type ORDER BY c DESC"
    ).fetchall()
    conn.close()
    return {
        "entities":     n_ent,
        "active_facts": n_fact,
        "superseded":   n_sup,
        "by_type":      {r["type"]: r["c"] for r in types_rows},
    }


# ── Voice command handler ────────────────────────────────────────────────────

def handle_graph_command(text: str, client=None) -> Optional[str]:
    low = text.lower().strip()

    # Stats
    if any(p in low for p in ["graph stats", "memory graph stats", "what do you know about me",
                                "knowledge stats"]):
        s = stats()
        return (f"I have {s['entities']} entities and {s['active_facts']} active facts "
                f"({s['superseded']} superseded). Top types: "
                f"{', '.join(f'{k}={v}' for k,v in list(s['by_type'].items())[:5])}")

    # "What do you know about X"
    m = re.match(r"(?:what do you know|tell me|what.+know)\s+about\s+(.+)", low)
    if m:
        name = m.group(1).strip(" ?.,")
        facts = get_facts_about(name)
        if not facts:
            return f"I don't have anything in the graph about {name}."
        lines = [f"What I know about {name}:"]
        for f in facts[:8]:
            lines.append(f"• [{f['timestamp_str']}] {f['predicate']} → {f['object_text']}")
        return "\n".join(lines)

    # Temporal questions: "what did we decide..."
    if any(t in low for t in ["last tuesday", "last monday", "last wednesday",
                                "last thursday", "last friday", "yesterday",
                                "last week", "last month", "days ago", "hours ago",
                                "this morning", "this week"]) and client:
        if any(q in low for q in ["what did", "what was", "did we", "what happened",
                                    "tell me about", "remember when"]):
            answer = answer_temporal_question(text, client)
            if answer:
                return answer

    return None
