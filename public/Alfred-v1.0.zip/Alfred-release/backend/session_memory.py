"""
session_memory.py — Persist the last conversation exchange across Alfred sessions.

Saves the most recent user/assistant pair to ~/.alfred/session_memory.json so that
the next session can recall what was just discussed.

Public API:
    save_exchange(user: str, assistant: str) -> None
    load_last_exchange() -> dict | None   # {"user": ..., "assistant": ..., "timestamp": ...}
"""

import json
import os
import time
from pathlib import Path

_MEMORY_PATH = Path.home() / ".alfred" / "session_memory.json"


def save_exchange(user: str, assistant: str) -> None:
    """Persist the latest user/assistant exchange to disk."""
    if not user or not assistant:
        return
    payload = {
        "user":      user,
        "assistant": assistant,
        "timestamp": int(time.time()),
    }
    try:
        _MEMORY_PATH.parent.mkdir(parents=True, exist_ok=True)
        _MEMORY_PATH.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"[session_memory] save failed: {e}")


def load_last_exchange() -> dict | None:
    """Load the last saved exchange. Returns None if none exists or on error."""
    try:
        if not _MEMORY_PATH.exists():
            return None
        data = json.loads(_MEMORY_PATH.read_text(encoding="utf-8"))
        if data.get("user") and data.get("assistant"):
            return data
        return None
    except Exception as e:
        print(f"[session_memory] load failed: {e}")
        return None
