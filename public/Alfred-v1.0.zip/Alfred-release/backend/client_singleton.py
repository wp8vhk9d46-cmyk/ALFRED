"""
client_singleton.py — One shared client + caching helpers.
Supports: anthropic, openrouter, deepseek, ollama
"""

import time
from typing import Any

from config import ALFRED_BACKEND as BACKEND

# ── Load the right backend ────────────────────────────────────────────────────
if BACKEND == "openrouter":
    from openrouter_client import (
        OpenRouterClient as _ClientClass,
        AsyncOpenRouterClient as _AsyncClientClass,
        cached_system, cache_stats, log_cache_stats
    )
elif BACKEND == "deepseek":
    from deepseek_client import (
        DeepSeekClient as _ClientClass,
        AsyncDeepSeekClient as _AsyncClientClass,
        cached_system, cache_stats, log_cache_stats
    )
elif BACKEND == "ollama":
    from ollama_client import (
        OllamaClient as _ClientClass,
        AsyncOllamaClient as _AsyncClientClass,
        cached_system, cache_stats, log_cache_stats
    )
else:
    import anthropic as _anthropic
    _ClientClass = _anthropic.Anthropic
    _AsyncClientClass = _anthropic.AsyncAnthropic

    def cached_system(text: str, ttl: str = "5m") -> list:
        cache_control = {"type": "ephemeral"}
        if ttl == "1h":
            cache_control["ttl"] = "1h"
        return [{"type": "text", "text": text, "cache_control": cache_control}]

    def cache_stats(response) -> dict:
        usage = getattr(response, "usage", None)
        if usage is None:
            return {"input": 0, "output": 0, "cache_read": 0, "cache_create": 0}
        return {
            "input":        getattr(usage, "input_tokens", 0) or 0,
            "output":       getattr(usage, "output_tokens", 0) or 0,
            "cache_read":   getattr(usage, "cache_read_input_tokens", 0) or 0,
            "cache_create": getattr(usage, "cache_creation_input_tokens", 0) or 0,
        }

    def log_cache_stats(label: str, response):
        s = cache_stats(response)
        if s["cache_read"] > 0:
            print(f"[cache] {label}: HIT ({s['cache_read']} cached)")
        elif s["cache_create"] > 0:
            print(f"[cache] {label}: WRITE ({s['cache_create']} cached)")

# ── Singleton instances ───────────────────────────────────────────────────────
_client_instance = None
_async_client_instance = None

def get_client():
    global _client_instance
    if _client_instance is None:
        _client_instance = _ClientClass()
    return _client_instance

def get_async_client():
    global _async_client_instance
    if _async_client_instance is None:
        _async_client_instance = _AsyncClientClass()
    return _async_client_instance
