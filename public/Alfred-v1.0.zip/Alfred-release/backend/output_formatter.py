"""
output_formatter.py — Post-process raw LLM output into structured cards.

For research / multi-agent / file analysis results, takes a blob of prose
and (using a fast Haiku call) restructures it into:

    **Title**

    Quick answer or summary line

    Key points:
    • bullet 1
    • bullet 2
    • bullet 3

    Sources: domain1.com, domain2.com

Public:
    format_research(raw_text, query, client) -> str
    format_file_summary(raw_text, file_name, client) -> str
    needs_formatting(text) -> bool   (heuristic check)

Designed to be a no-op when the text is already short/structured.
"""
from __future__ import annotations
import re


FORMATTER_MODEL = "claude-haiku-4-5-20251001"


def needs_formatting(text: str) -> bool:
    """Return True if `text` is a long-ish blob that would benefit from
    being restructured into a titled bullet card."""
    if not text or len(text) < 200:
        return False
    # If it already has bold headers + bullets, it's structured enough
    has_headers = bool(re.search(r"^\*\*[^*]+\*\*", text, re.MULTILINE))
    has_bullets = bool(re.search(r"^\s*[•\-\*]\s+", text, re.MULTILINE))
    if has_headers and has_bullets:
        return False
    return True


def format_research(raw_text: str, query: str, client) -> str:
    """Restructure research output as a Title + Summary + Bullets + Sources card.

    If the raw text is already structured, returns it unchanged.
    On any error, returns the raw text rather than failing.
    """
    if not needs_formatting(raw_text):
        return raw_text

    prompt = (
        f"User's question: {query!r}\n\n"
        f"Raw research output:\n```\n{raw_text[:4000]}\n```\n\n"
        f"Restructure this as a concise card. Format EXACTLY like this:\n\n"
        f"**<Short title — what was asked>**\n\n"
        f"<one-sentence direct answer>\n\n"
        f"Key points:\n"
        f"• <fact 1>\n"
        f"• <fact 2>\n"
        f"• <fact 3>\n"
        f"• <fact 4 — optional>\n\n"
        f"Sources: <domain1.com>, <domain2.com>\n\n"
        f"Rules:\n"
        f"- Title in bold, max 8 words\n"
        f"- Direct answer first line — name, number, date the user asked for\n"
        f"- 3-5 bullets, each ≤15 words\n"
        f"- Sources line: just domain names, no full URLs\n"
        f"- If the raw text was already a clean answer, don't pad it — keep it tight\n"
        f"- Don't say 'Based on the research' or other filler\n"
        f"- Plain markdown, no code fences"
    )

    try:
        resp = client.messages.create(
            model=FORMATTER_MODEL,
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}],
        )
        formatted = resp.content[0].text.strip()
        # Strip any accidental code fences
        formatted = re.sub(r"^```\w*\s*|\s*```$", "", formatted, flags=re.MULTILINE)
        if len(formatted) > 50:
            return formatted
    except Exception as e:
        print(f"[fmt] formatter failed: {e}")
    return raw_text


def format_file_summary(raw_text: str, file_name: str, client) -> str:
    """Restructure a file summary as Title + Summary + Highlights card."""
    if not needs_formatting(raw_text):
        return raw_text

    prompt = (
        f"File: {file_name}\n\n"
        f"Raw analysis:\n```\n{raw_text[:4000]}\n```\n\n"
        f"Restructure this as a concise card. Format EXACTLY like:\n\n"
        f"**{file_name}**\n\n"
        f"<one-sentence summary>\n\n"
        f"Highlights:\n"
        f"• <key point 1>\n"
        f"• <key point 2>\n"
        f"• <key point 3>\n\n"
        f"Rules: max 5 bullets, each ≤15 words. Plain markdown, no code fences."
    )

    try:
        resp = client.messages.create(
            model=FORMATTER_MODEL,
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        formatted = resp.content[0].text.strip()
        formatted = re.sub(r"^```\w*\s*|\s*```$", "", formatted, flags=re.MULTILINE)
        if len(formatted) > 50:
            return formatted
    except Exception as e:
        print(f"[fmt] formatter failed: {e}")
    return raw_text
