"""
youtube_transcript.py — Fetch YouTube video transcripts.

Uses the `youtube-transcript-api` package which hits YouTube's public
transcript endpoint (the same one the browser uses when you click
"Show transcript"). No API key, no quotas.

Install: pip3 install youtube-transcript-api --break-system-packages

Public functions:
    extract_video_id(url) -> str | None
    fetch_transcript(video_id) -> dict {text, segments, lang} | None
    format_with_timestamps(segments) -> str
"""

import re
import urllib.parse


# Match the various YouTube URL formats we might see:
#   youtube.com/watch?v=VIDEOID
#   youtube.com/watch?v=VIDEOID&t=42s
#   youtu.be/VIDEOID
#   youtu.be/VIDEOID?t=42
#   youtube.com/shorts/VIDEOID
#   youtube.com/embed/VIDEOID
#   m.youtube.com/watch?v=VIDEOID
_VIDEO_ID_PATTERNS = [
    r"(?:youtube\.com|youtu\.be)/watch\?(?:[^&\s]*&)*v=([A-Za-z0-9_-]{11})",
    r"youtu\.be/([A-Za-z0-9_-]{11})",
    r"youtube\.com/shorts/([A-Za-z0-9_-]{11})",
    r"youtube\.com/embed/([A-Za-z0-9_-]{11})",
    r"youtube\.com/v/([A-Za-z0-9_-]{11})",
]


def extract_video_id(url: str) -> str | None:
    """Pull the 11-character YouTube video ID out of any YouTube URL form."""
    if not url: return None
    for pat in _VIDEO_ID_PATTERNS:
        m = re.search(pat, url)
        if m: return m.group(1)
    # Fallback: parse query string directly
    try:
        parsed = urllib.parse.urlparse(url)
        if "youtube" in parsed.netloc or "youtu.be" in parsed.netloc:
            qs = urllib.parse.parse_qs(parsed.query)
            if "v" in qs and len(qs["v"][0]) == 11:
                return qs["v"][0]
            # youtu.be path is the ID
            path = parsed.path.strip("/")
            if len(path) == 11 and re.match(r"^[A-Za-z0-9_-]{11}$", path):
                return path
    except Exception:
        pass
    return None


def fetch_transcript(video_id: str, prefer_lang: str = "en") -> dict | None:
    """
    Return {'text': '<full text>', 'segments': [...], 'lang': 'en'} or None.

    Tries the preferred language first (English by default), falls back to
    auto-generated, then to any available language.
    """
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
    except ImportError:
        print("[youtube] youtube-transcript-api not installed.")
        print("[youtube] Install: pip3 install youtube-transcript-api --break-system-packages")
        return None

    try:
        # Newer 1.x API: use instance method
        api = YouTubeTranscriptApi()
        # First: try preferred language manually-created or auto-generated
        try:
            fetched = api.fetch(video_id, languages=[prefer_lang])
        except Exception:
            # Fallback: any available language
            try:
                # list_transcripts to find what's available
                tlist = api.list(video_id)
                # Prefer manual over auto, English over others
                chosen = None
                for t in tlist:
                    if t.language_code.startswith("en"):
                        chosen = t; break
                if chosen is None:
                    # Just take the first one available
                    chosen = next(iter(tlist), None)
                if chosen is None:
                    return None
                fetched = chosen.fetch()
            except Exception as e:
                print(f"[youtube] no transcript available: {e}")
                return None

        # Newer API returns FetchedTranscript objects with .snippets
        # Older returns a list of dicts. Handle both.
        if hasattr(fetched, "snippets"):
            segments = [{"text": s.text, "start": s.start, "duration": s.duration}
                        for s in fetched.snippets]
            lang = getattr(fetched, "language_code", prefer_lang)
        else:
            segments = list(fetched)
            lang = prefer_lang

        full_text = " ".join(s["text"].replace("\n", " ").strip()
                             for s in segments
                             if s.get("text"))
        # Collapse multi-spaces
        full_text = re.sub(r"\s+", " ", full_text).strip()
        return {"text": full_text, "segments": segments, "lang": lang}

    except Exception as e:
        # Could be: video private, no captions, regional block, etc.
        msg = str(e)[:200]
        print(f"[youtube] transcript fetch failed: {msg}")
        return None


def format_with_timestamps(segments: list, max_marks: int = 8) -> str:
    """
    Pick ~N evenly-spaced segments and format as 'mm:ss — text' lines.
    Used for the 'Key timestamps' chip.
    """
    if not segments:
        return ""
    n = len(segments)
    if n <= max_marks:
        picks = segments
    else:
        # Even spacing
        step = n // max_marks
        picks = [segments[i] for i in range(0, n, step)][:max_marks]

    out = []
    for s in picks:
        start = int(s.get("start", 0))
        mm, ss = divmod(start, 60)
        text = s.get("text", "").replace("\n", " ").strip()
        if text:
            out.append(f"{mm}:{ss:02d} — {text[:80]}")
    return "\n".join(out)


def is_youtube_url(url: str) -> bool:
    """Quick check: is this a YouTube URL with an extractable video ID?"""
    return extract_video_id(url) is not None
