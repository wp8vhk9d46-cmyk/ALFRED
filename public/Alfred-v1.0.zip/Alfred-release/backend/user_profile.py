"""
user_profile.py — First-launch onboarding and persistent user profile for Alfred.

Profile lives at ~/.alfred/app/me.md and is injected into every system prompt.
Onboarding runs through the bar (no terminal needed) on first launch.
Passive extraction updates the profile from natural conversation over time.
"""
from __future__ import annotations
import re
from datetime import datetime
from pathlib import Path

PROFILE_PATH = Path(__file__).parent / "me.md"

# ── Onboarding ────────────────────────────────────────────────────────────────

_QUESTIONS = {
    "name":  "Hi, I'm Alfred. I don't know you yet — what should I call you?",
    "role":  "Nice to meet you, {name}! What do you do? (e.g. software engineer, designer, student)",
    "style": "Got it. Last one: do you prefer responses that are **brief and direct**, or **detailed and thorough**?",
    "done":  "Perfect. I'll remember all of this. You can always say things like \"call me X\" or \"keep it brief\" and I'll update my memory. What can I help you with?",
}

_STYLE_BRIEF    = re.compile(r"\b(brief|short|concise|terse|quick|minimal)\b", re.IGNORECASE)
_STYLE_DETAILED = re.compile(r"\b(detail|thorough|long|verbose|full|comprehensive)\b", re.IGNORECASE)


def needs_onboarding() -> bool:
    """True if me.md is missing or has no Name field."""
    if not PROFILE_PATH.exists():
        return True
    return "Name:" not in PROFILE_PATH.read_text(errors="replace")


def get_onboarding_step() -> str:
    """Return next onboarding step based on what me.md already has."""
    if not PROFILE_PATH.exists():
        return "name"
    content = PROFILE_PATH.read_text(errors="replace")
    if "Name:" not in content:
        return "name"
    if "Role:" not in content:
        return "role"
    if "Style:" not in content:
        return "style"
    return "done"


def get_question(step: str) -> str:
    name = get_field("Name") or "there"
    return _QUESTIONS.get(step, "").format(name=name)


def handle_onboarding_answer(step: str, answer: str) -> str:
    """
    Save the user's answer for the given step.
    Returns the next question (or done message).
    """
    answer = answer.strip()

    if step == "name":
        # Take first word/name from reply
        name = answer.split()[0].rstrip(".,!") if answer else answer
        name = name.title()
        set_field("Name", name)
        next_step = "role"

    elif step == "role":
        # Clean up articles
        role = re.sub(r"^(i'?m |i am |a |an )", "", answer, flags=re.IGNORECASE).strip()
        set_field("Role", role or answer)
        next_step = "style"

    elif step == "style":
        if _STYLE_BRIEF.search(answer):
            set_field("Style", "brief")
        elif _STYLE_DETAILED.search(answer):
            set_field("Style", "detailed")
        else:
            # Default to brief if unclear
            set_field("Style", "brief")
        next_step = "done"

    else:
        next_step = "done"

    return get_question(next_step)


# ── Profile I/O ───────────────────────────────────────────────────────────────

def get_field(key: str) -> str:
    """Read a single field from me.md."""
    if not PROFILE_PATH.exists():
        return ""
    for line in PROFILE_PATH.read_text(errors="replace").splitlines():
        if line.startswith(f"{key}:"):
            return line.split(":", 1)[1].strip()
    return ""


def set_field(key: str, value: str) -> None:
    """Write or update a field in me.md."""
    if PROFILE_PATH.exists():
        content = PROFILE_PATH.read_text(errors="replace")
    else:
        content = f"# Alfred User Profile\n# Created: {datetime.now().strftime('%Y-%m-%d')}\n\n"

    pattern = rf"^{re.escape(key)}:.*$"
    new_line = f"{key}: {value}"
    if re.search(pattern, content, re.MULTILINE):
        content = re.sub(pattern, new_line, content, flags=re.MULTILINE)
    else:
        content = content.rstrip() + f"\n{new_line}\n"

    PROFILE_PATH.write_text(content, encoding="utf-8")
    print(f"[profile] {key} = {value}")


def load_profile_text() -> str:
    """Return full me.md content for injection into system prompt."""
    if not PROFILE_PATH.exists():
        return ""
    return PROFILE_PATH.read_text(errors="replace").strip()


# ── Passive extraction ────────────────────────────────────────────────────────

_NAME_RE  = re.compile(
    r"\b(?:call me|my name is|i'?m called|i go by|just call me)\s+([A-Za-z][a-z]+(?:\s+[A-Z][a-z]+)?)",
    re.IGNORECASE,
)
_BRIEF_RE = re.compile(
    r"\b(?:keep it brief|be concise|shorter (?:responses?|answers?)|less verbose|stop rambling)\b",
    re.IGNORECASE,
)
_DETAIL_RE = re.compile(
    r"\b(?:more detail(?:s|ed)?|be (?:more )?thorough|longer (?:responses?|answers?)|explain (?:more|fully))\b",
    re.IGNORECASE,
)
_NOTE_RE = re.compile(
    r"\b(?:remember (?:that )?i|note that i|fyi[,:]? i|btw[,:]? i)\s+(.{10,80}?)(?:\.|$)",
    re.IGNORECASE,
)


def extract_and_update(user_msg: str) -> bool:
    """
    Passive learning from user messages.
    Updates me.md in place. Returns True if anything changed.
    """
    updated = False

    m = _NAME_RE.search(user_msg)
    if m:
        set_field("Name", m.group(1).title())
        updated = True

    if _BRIEF_RE.search(user_msg):
        set_field("Style", "brief")
        updated = True
    elif _DETAIL_RE.search(user_msg):
        set_field("Style", "detailed")
        updated = True

    m = _NOTE_RE.search(user_msg)
    if m:
        note = m.group(1).strip().rstrip(".,")
        _append_note(note)
        updated = True

    return updated


def _append_note(note: str) -> None:
    """Append a free-form note line to me.md."""
    if PROFILE_PATH.exists():
        content = PROFILE_PATH.read_text(errors="replace")
    else:
        content = f"# Alfred User Profile\n# Created: {datetime.now().strftime('%Y-%m-%d')}\n\n"

    if "Notes:" not in content:
        content = content.rstrip() + "\nNotes:\n"

    note_line = f"- {note}"
    if note_line not in content:
        lines = content.splitlines()
        try:
            idx = next(i for i, l in enumerate(lines) if l.strip() == "Notes:")
            lines.insert(idx + 1, note_line)
            content = "\n".join(lines) + "\n"
        except StopIteration:
            content = content.rstrip() + f"\n{note_line}\n"
        PROFILE_PATH.write_text(content, encoding="utf-8")
        print(f"[profile] note added: {note}")
