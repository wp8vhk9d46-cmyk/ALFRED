"""
capabilities.py — Developer capabilities for Alfred
File operations, git, shell, clipboard, calendar, project context, web research.

Import at top of assistant.py:
    from capabilities import try_capability
    
Then in _handle_command, call try_capability(user_text, client, speak_response)
BEFORE the classifier. It returns (handled, response) or (False, None).
"""
import os, re, subprocess, json, time, urllib.request
from pathlib import Path


HOME = str(Path.home())
PROJECTS_DIR = os.path.expanduser("~/Documents")
CURRENT_PROJECT = os.path.expanduser("~/Documents/alfred")


def _bash(cmd, cwd=None, timeout=15):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           timeout=timeout, cwd=cwd or HOME)
        return (r.stdout + r.stderr).strip()
    except Exception as e:
        return f"Error: {e}"


# ── FILE OPERATIONS ──────────────────────────────────────────────────────────
def handle_file_ops(text):
    low = text.lower()

    # "read <file>" or "show me <file>"
    m = re.match(r"(?:read|show(?: me)?|cat|display|open)\s+(?:the\s+)?(?:file\s+)?([~/\w.\-]+(?:\.\w+)?)", text)
    if m and ("." in m.group(1) or "/" in m.group(1)):
        path = os.path.expanduser(m.group(1))
        if not os.path.exists(path):
            path = os.path.join(CURRENT_PROJECT, m.group(1))
        if os.path.exists(path):
            try:
                with open(path, errors="replace") as f:
                    content = f.read()
                if len(content) > 2000:
                    return f"{path} ({len(content)} chars):\n{content[:2000]}\n...[truncated]"
                return f"{path}:\n{content}"
            except Exception as e:
                return f"Can't read: {e}"

    # "last N lines of X"
    m = re.search(r"last\s+(\d+)\s+lines?\s+of\s+([~/\w.\-]+)", low)
    if m:
        n = int(m.group(1))
        path = os.path.expanduser(m.group(2))
        if not os.path.exists(path):
            path = os.path.join(CURRENT_PROJECT, m.group(2))
        if os.path.exists(path):
            out = _bash(f"tail -{n} {path}")
            return f"Last {n} lines:\n{out}"

    # "list files in X" / "what's in X"
    m = re.search(r"(?:list|show|ls)\s+(?:files?\s+in\s+)?([~/\w.\-]+)", low)
    if m:
        path = os.path.expanduser(m.group(1))
        if os.path.isdir(path):
            out = _bash(f"ls -la {path}")
            return f"{path}:\n{out[:1500]}"

    m = re.search(r"what(?:'s|\s+is)\s+in\s+(?:my\s+)?([~/\w.\-]+)", low)
    if m:
        folder = m.group(1)
        if folder == "downloads":
            path = os.path.expanduser("~/Downloads")
        elif folder == "desktop":
            path = os.path.expanduser("~/Desktop")
        elif folder == "documents":
            path = os.path.expanduser("~/Documents")
        else:
            path = os.path.expanduser(folder)
        if os.path.isdir(path):
            files = os.listdir(path)[:20]
            return f"{path} has {len(os.listdir(path))} items. First 20: " + ", ".join(files)

    # "search for <term> in <path>" / "find files containing X"
    m = re.search(r"(?:search|find|grep)\s+(?:for\s+)?['\"]?([\w\s().]+?)['\"]?\s+in\s+([~/\w.\-]+)", text, re.IGNORECASE)
    if m:
        term = m.group(1).strip()
        path_str = m.group(2).lower()
        if path_str in ["alfred", "my project", "project", "the alfred folder"]:
            path = CURRENT_PROJECT
        elif path_str in ["downloads", "desktop", "documents"]:
            path = os.path.expanduser(f"~/{path_str.title()}")
        else:
            path = os.path.expanduser(m.group(2))
            if not os.path.isdir(path):
                alt = os.path.join(CURRENT_PROJECT, m.group(2))
                if os.path.isdir(alt):
                    path = alt
                else:
                    return f"Can't find folder: {m.group(2)}"
        out = _bash(f'grep -r -n --include="*.py" --include="*.js" --include="*.md" "{term}" {path} 2>/dev/null | head -30', timeout=10)
        return f"Matches for '{term}' in {path}:\n{out[:1500]}" if out else f"No matches for '{term}' in {path}"

    return None


# ── GIT ──────────────────────────────────────────────────────────────────────
def handle_git(text, project_dir=None):
    low = text.lower()
    cwd = project_dir or CURRENT_PROJECT
    if not os.path.isdir(os.path.join(cwd, ".git")):
        # Not a git repo — try parent dir
        parent = os.path.dirname(cwd)
        if os.path.isdir(os.path.join(parent, ".git")):
            cwd = parent

    if "git status" in low or ("what" in low and "changed" in low) or "what did i change" in low:
        out = _bash("git status --short", cwd=cwd)
        return f"Git status in {cwd}:\n{out}" if out else "Working tree clean."

    if "git diff" in low or "show me the diff" in low or "show the changes" in low:
        out = _bash("git diff --stat", cwd=cwd)
        return f"Diff summary:\n{out[:1500]}"

    # "commit with message X" / "commit X"
    m = re.search(r"(?:commit|git commit)(?:\s+with\s+message|\s+saying|\s+with)?\s+['\"]?(.+?)['\"]?$", text, re.IGNORECASE)
    if m and "commit" in low:
        msg = m.group(1).strip().strip('"\'')
        _bash("git add -A", cwd=cwd)
        out = _bash(f'git commit -m "{msg}"', cwd=cwd)
        return f"Committed: {msg}\n{out[:300]}"

    if "git log" in low or "recent commits" in low or "last commits" in low:
        out = _bash("git log --oneline -10", cwd=cwd)
        return f"Recent commits:\n{out}"

    if "git push" in low or re.search(r"\bpush(?:\s+to|\s+up)?\b", low):
        out = _bash("git push", cwd=cwd)
        return f"Push result:\n{out[:400]}"

    if "git pull" in low:
        out = _bash("git pull", cwd=cwd)
        return f"Pull result:\n{out[:400]}"

    if "what branch" in low or "current branch" in low:
        out = _bash("git branch --show-current", cwd=cwd)
        return f"On branch: {out}"

    return None


# ── SHELL ────────────────────────────────────────────────────────────────────
def handle_shell(text):
    low = text.lower()

    # "run <command>" — lets user run arbitrary shell
    m = re.match(r"(?:run|execute|shell)\s+['\"]?(.+?)['\"]?$", text, re.IGNORECASE)
    if m:
        cmd = m.group(1).strip()
        # Safety: no rm -rf /
        if "rm -rf /" in cmd or cmd.startswith("rm -rf ~"):
            return "I'm not running that."
        out = _bash(cmd)
        return f"$ {cmd}\n{out[:1500]}" if out else f"Done (no output)"

    # "disk space" / "what's taking up space"
    if "disk space" in low or "taking up space" in low or "storage" in low:
        out = _bash("df -h / | tail -1")
        return f"Disk: {out}"

    # "what's running" / "running processes"
    if "what's running" in low or "running processes" in low or "process list" in low:
        out = _bash("ps aux | awk '{print $11}' | sort | uniq -c | sort -rn | head -10")
        return f"Top running apps:\n{out}"

    # "what port X" / "is X running on port"
    m = re.search(r"port\s+(\d+)", low)
    if m:
        port = m.group(1)
        out = _bash(f"lsof -i :{port} 2>/dev/null | head -5")
        return f"Port {port}:\n{out}" if out else f"Nothing on port {port}."

    return None


# ── CLIPBOARD ────────────────────────────────────────────────────────────────
def handle_clipboard(text):
    low = text.lower()

    if "what's in my clipboard" in low or "read my clipboard" in low or "show clipboard" in low:
        out = _bash("pbpaste")
        return f"Clipboard: {out[:500]}" if out else "Clipboard is empty."

    # "copy X to clipboard" / "put X in clipboard"
    m = re.search(r"(?:copy|put)\s+['\"]?(.+?)['\"]?\s+(?:to|in|into)\s+(?:my\s+)?clipboard", text, re.IGNORECASE)
    if m:
        content = m.group(1).strip()
        subprocess.run(["pbcopy"], input=content.encode(), capture_output=True)
        return f"Copied to clipboard."

    if low.strip() in ["clear clipboard", "empty clipboard"]:
        subprocess.run(["pbcopy"], input=b"", capture_output=True)
        return "Clipboard cleared."

    return None


# ── CALENDAR / REMINDERS ─────────────────────────────────────────────────────
def handle_calendar(text):
    low = text.lower()

    # "what's on my calendar today/tomorrow"
    if "calendar" in low and any(w in low for w in ["today", "tomorrow", "this week", "what's on"]):
        when = "today"
        if "tomorrow" in low: when = "tomorrow"
        elif "week" in low: when = "week"
        sc = f'''tell application "Calendar"
    set theDate to current date
    if "{when}" = "tomorrow" then set theDate to theDate + 1 * days
    set endDate to theDate + 1 * days
    if "{when}" = "week" then set endDate to theDate + 7 * days
    set output to ""
    tell calendar "Home"
        set todaysEvents to every event whose start date is greater than or equal to theDate and start date is less than endDate
        repeat with e in todaysEvents
            set output to output & (summary of e) & " at " & (start date of e as string) & return
        end repeat
    end tell
    return output
end tell'''
        try:
            r = subprocess.run(["osascript", "-e", sc], capture_output=True, text=True, timeout=10)
            out = r.stdout.strip()
            return f"Calendar {when}:\n{out[:500]}" if out else f"Nothing on your calendar {when}."
        except Exception:
            return None

    # "remind me to X at Y" / "remind me to X in 5 minutes"
    m = re.match(r"remind me to\s+(.+?)\s+(?:at\s+(.+)|in\s+(\d+)\s+(minute|hour)s?)$", text, re.IGNORECASE)
    if m:
        what = m.group(1).strip()
        when_abs = m.group(2)
        when_rel_n = m.group(3)
        when_rel_unit = m.group(4)

        if when_rel_n:
            n = int(when_rel_n)
            mins = n if "minute" in when_rel_unit else n * 60
            sc = f'''tell application "Reminders"
    set newReminder to make new reminder with properties {{name:"{what}", remind me date:(current date) + {mins * 60}}}
end tell'''
        else:
            sc = f'''tell application "Reminders"
    set newReminder to make new reminder with properties {{name:"{what}"}}
end tell'''
        try:
            subprocess.run(["osascript", "-e", sc], capture_output=True, timeout=5)
            return f"Reminder set: {what}"
        except Exception:
            return None

    return None


# ── PROJECT CONTEXT ──────────────────────────────────────────────────────────
def handle_project(text, save_memory_fn=None):
    low = text.lower()

    # "what am I working on" / "what's my current project"
    if "working on" in low or "current project" in low or "project context" in low:
        # List dirs in ~/Documents with recent modifications
        out = _bash(f'find {PROJECTS_DIR} -maxdepth 2 -name ".git" -type d 2>/dev/null | head -10')
        projects = [os.path.dirname(p) for p in out.splitlines() if p]
        if projects:
            summary = []
            for p in projects[:5]:
                name = os.path.basename(p)
                last_modified = _bash(f'stat -f "%Sm" {p}').strip()
                summary.append(f"{name} ({last_modified[:12]})")
            return "Your git projects:\n" + "\n".join(summary)

    # "summarize this project" / "what's this codebase"
    if ("summarize" in low and "project" in low) or "describe this codebase" in low:
        files = _bash(f'find {CURRENT_PROJECT} -maxdepth 2 -type f -not -path "*/\\.*" -not -path "*/node_modules/*" 2>/dev/null | head -30')
        loc = _bash(f'find {CURRENT_PROJECT} -name "*.py" -exec wc -l {{}} + 2>/dev/null | tail -1')
        return f"Project at {CURRENT_PROJECT}:\n{files[:800]}\n\n{loc}"

    return None


# ── WEB RESEARCH (real search + agentic browsing) ─────────────────────────────
# Thread-local sources accumulator — the IPC handler wraps each query in
# this so it can pick up the URLs the agent fetched and surface them to the bar.
import threading as _threading
_search_sources = _threading.local()

def _record_sources(urls):
    """Record sources from the most recent agentic search."""
    try:
        getattr(_search_sources, "urls", None)
    except Exception:
        pass
    _search_sources.urls = list(urls)

def get_recent_sources():
    """Return + clear sources from the most recent search on this thread."""
    urls = getattr(_search_sources, "urls", None) or []
    _search_sources.urls = []
    return urls


def handle_web_research(text, client=None):
    try:
        from web_search import handle_web_search
        return handle_web_search(text, client, sources_cb=_record_sources)
    except ImportError:
        pass
    return None


# ── CLIPBOARD-CONTEXT ACTIONS ────────────────────────────────────────────────
# Commands that auto-grab clipboard content and act on it
def handle_clipboard_action(text, client=None):
    if not client:
        return None
    low = text.lower().strip()

    # Triggers that mean "use my clipboard content"
    triggers = {
        "answer this": "Answer this question or complete this task thoughtfully",
        "answer it": "Answer this question or complete this task thoughtfully",
        "explain this": "Explain this clearly in 3-4 sentences",
        "explain it": "Explain this clearly in 3-4 sentences",
        "fix this": "Fix any issues in this. Return the corrected version only",
        "fix it": "Fix any issues in this. Return the corrected version only",
        "debug this": "Find the bug in this code and explain the fix",
        "review this": "Review this and give me 3 specific suggestions",
        "summarize this": "Summarize this in 2-3 sentences",
        "summarize it": "Summarize this in 2-3 sentences",
        "translate this": "Translate this to English if not already, or ask which language",
        "improve this": "Improve the quality and clarity. Return improved version only",
        "what does this mean": "Explain what this means in plain language",
        "what is this": "Identify what this is and briefly describe it",
    }

    matched = None
    for trigger, instruction in triggers.items():
        if low == trigger or low == trigger + "." or low.startswith(trigger + " "):
            matched = (trigger, instruction)
            break

    # Also catch variants like "summarize info from clipboard" / "from my clipboard"
    if not matched:
        clipboard_phrases = (
            "from clipboard", "from my clipboard", "from the clipboard",
            "in clipboard", "in my clipboard", "in the clipboard",
            "on clipboard", "on my clipboard", "on the clipboard",
            "of clipboard", "of my clipboard", "of the clipboard",
        )
        if any(p in low for p in clipboard_phrases):
            # Figure out the action verb from the start of the query
            verb_to_instruction = {
                "summari": "Summarize this in 2-3 sentences",
                "explain": "Explain this clearly in 3-4 sentences",
                "fix":     "Fix any issues in this. Return the corrected version only",
                "review":  "Review this and give me 3 specific suggestions",
                "translat": "Translate this to English if not already, or ask which language",
                "improve": "Improve the quality and clarity. Return improved version only",
                "answer":  "Answer this question or complete this task thoughtfully",
                "what is": "Identify what this is and briefly describe it",
                "what does": "Explain what this means in plain language",
            }
            for prefix, instr in verb_to_instruction.items():
                if low.startswith(prefix) or f" {prefix}" in low[:25]:
                    matched = (prefix, instr)
                    break

    if not matched:
        return None

    # Get clipboard content
    try:
        r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3)
        clipboard = r.stdout.strip()
    except Exception:
        return "Couldn't read clipboard."

    if not clipboard:
        return "Clipboard is empty. Copy something first, then try again."

    instruction = matched[1]
    try:
        resp = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=800,
            messages=[{"role": "user", "content":
                f"{instruction}:\n\n{clipboard[:4000]}"}]
        )
        answer = resp.content[0].text.strip()
        # Auto-copy the answer back to clipboard so user can paste it
        subprocess.run(["pbcopy"], input=answer.encode(), capture_output=True)
        return f"{answer}\n\n(copied to clipboard)"
    except Exception as e:
        return f"Error: {e}"


# ── NATURAL WRITING / HUMANIZER ──────────────────────────────────────────────
# Research-backed multi-pass pipeline based on detector evasion research.
# Targets: ZeroGPT, GPTZero, Copyleaks, Winston (second-tier, beatable)
# Partial: Turnitin pre-Aug-2025, default sensitivity
# Weak against: Pangram, Originality Turbo 3.0.2, post-Aug-2025 Turnitin

HUMANIZE_SYSTEM = """You are a specific real person writing. Not an AI. Not a polished writer. A human with opinions, doubts, and personal history.

PERSONA: Second-year grad student drafting at 11pm before an 8am deadline. Journalism background. Slightly tired, slightly annoyed, has real opinions on this topic. Writing for a smart professor who can tell when you're faking it.

THE VOICE (all absolute):
- First person throughout where natural: "I think", "my read", "I've been wondering", "what bugs me about X is"
- Contractions everywhere they fit. Don't, it's, you're, I'm, wasn't, haven't, that's
- Start sentences with And, But, So, Because. Often.
- Use "like" as a quick qualifier sometimes. "Like, the obvious move is X"
- Interrupt yourself: "The issue — and this is where it gets ugly — is X"
- Admit uncertainty: "I'm not totally sure, but", "maybe I'm wrong here", "this is where my read gets shakier"
- Take a position. Pick a side. Be annoyed at bad arguments.

RHYTHM (this is what ZeroGPT measures — get this right):
- Sentence lengths MUST range 2 to 40 words within every paragraph
- Fragments are required. Short ones. Two-word ones.
- At least one sentence of 35+ words per paragraph, with multiple clauses and asides
- Never two medium-length sentences (15-22 words) in a row
- At least one paragraph should be a single sentence
- Another paragraph should have 6+ sentences
- DO NOT write in clean, parallel, balanced prose. That's what gets flagged.

CRITICAL — THIS IS WHERE YOUR LAST DRAFT STILL FAILED:
Sentences like "Solar and wind are cheaper than coal. Electric vehicles are going mainstream. Cities like Amsterdam and Bogotá have been redesigning themselves around transit" get flagged because they're three parallel clean declaratives in a row. FIX: merge some, break others into fragments, add asides, make them different shapes.

Bad (AI-flagged): "Solar and wind are cheaper than coal in most markets now. Electric vehicles are going mainstream. Cities like Amsterdam and Bogotá have been redesigning themselves around transit and walking for years."

Better: "Solar and wind beat coal on price in most markets now — not as some future projection but on current spot prices. EVs went mainstream. And cities that started years ago on the transit-and-walking rebuild, Amsterdam and Bogotá being the obvious ones, are already ahead."

DICTION:
- Concrete over abstract
- Anglo-Saxon over Latinate: use not utilize, help not facilitate, try not endeavor
- Every 150 words: one specific number, date, place, or name
- Invent plausible specifics if you don't have them — "a 2019 Stanford paper", "my friend who works in wind in Colorado"

NEVER USE (these are the quantified AI markers from Kobak 2024, Gray 2024):
delve, tapestry, multifaceted, holistic, leverage, foster, navigate, landscape, paradigm, realm, pivotal, testament, cutting-edge, ever-evolving, seamless, underscore, comprehensive, furthermore, moreover, notably, particularly, additionally, crucial, insights, meticulously, intricate, groundbreaking, commendable, exhibited, interplay

NEVER WRITE:
"it is important to note", "it is worth noting", "in conclusion", "in essence", "in today's world", "navigate the complexities", "ever-evolving landscape", "plays a crucial role", "stands as a testament", "worth mentioning", "it should be noted"

STRUCTURE RULES (ZeroGPT catches these):
- NO tricolons (three-item parallel lists). Two items max, or four asymmetric items.
- NO "not X, it's Y" antithesis. No "It's not just about A, it's about B."
- NO signposted "First / Second / Finally"
- NO closing recap paragraph. Just stop when you're done.
- NO balanced two-sided framing unless the tradeoff is really balanced
- NO topic-sentence-plus-three-supporting-sentences paragraphs — mix it up
- Em-dashes: fine, but use commas or parentheses half the time
- Leave one loose thread unresolved. Humans do this.

OUTPUT: Just the text. No preamble. No explanations. No headings unless requested."""


ACADEMIC_RIGOR_SUPPLEMENT = """ADDITIONAL RULES FOR ACADEMIC WRITING — these layer on top of the voice rules above and cannot be skipped.

YOU ARE WRITING AN A-LEVEL ANALYTICAL ESSAY. The professor grading this has a PhD and will notice the difference between a strong thesis and a performed thesis.

THESIS REQUIREMENTS:
- The thesis must be ARGUABLE — someone could reasonably disagree
- The thesis must be SPECIFIC — define the scope (which period, which population, what counts as "benefit", etc.)
- The thesis must name its terms — don't leave the definitional question for the reader to guess
- State the thesis in the first paragraph, not buried at the end

EVIDENCE REQUIREMENTS (this is where most drafts lose grade points):
- Every body paragraph needs 2-3 pieces of concrete evidence, not just one example
- Evidence types must be layered: statistics + primary sources + secondary scholarly sources + specific historical incidents
- If citing a wage figure, also cite what prices did in the same period — numbers in context
- If citing a source like Thompson or Engels, include at least one DIRECT QUOTE in quotation marks, 5-15 words
- If you don't know the exact quote, don't invent one — paraphrase carefully and attribute

CITATION REQUIREMENTS:
- Every source named must have: author, full title (italicized using *asterisks*), year
- Example: Engels, *The Condition of the Working Class in England* (1845)
- Example: E.P. Thompson, *The Making of the English Working Class* (1963)
- Example: Chadwick, *Report on the Sanitary Condition of the Labouring Population of Great Britain* (1842)
- For scholars named (McCloskey, Mokyr, etc.), name at least one specific work or argument, not just the surname
- Example: "McCloskey's 1981 essay in the *Economic History Review* argues..."
- When you can't recall exact publication details, signal uncertainty — "(I believe 1985)" is better than inventing

SOURCE ENGAGEMENT:
- Don't name-drop. For each major source do one of: quote directly, describe their method, identify a weakness, or place them in a debate
- For the counterargument: steelman it. Present it as the opposing scholar would present it, using their terminology, before answering
- At least one direct quote somewhere in the essay

ANALYTICAL MOVES THAT DISTINGUISH A FROM B:
- Define your terms explicitly at least once (e.g., "When I say 'benefit,' I mean X, not Y")
- Identify a hidden assumption in the counterargument and name it
- Use at least one specific historical incident as a test case, not just generalizations
- Acknowledge a limitation in your own argument that is REAL (not performative humility)
- Distinguish short-term, medium-term, and long-term effects where relevant

CONCLUSION:
- Do NOT recap. Don't say "in conclusion" or summarize what you argued.
- Instead: push the argument one step further, raise the definitional question you've been answering implicitly, or identify what your thesis IMPLIES for a related question
- A good conclusion makes the reader see something new, not review what they just read

VOICE-RIGOR BALANCE:
- The voice rules above still apply. Don't drop the fragments, opinion asides, or contractions.
- Rigor comes from the structural moves — evidence layering, real citations, engaged counterarguments — not from formal tone.
- An A-level essay sounds like a smart person arguing with themselves on paper, with receipts."""


def _is_academic_task(text):
    """Detect if user wants academic/analytical writing."""
    low = text.lower()
    markers = ["academic", "analytical", "essay", "argue", "thesis",
               "research paper", "scholarly", "analyze", "dissertation",
               "literature review", "argumentative", "critical analysis",
               "counterargument", "historiography", "cite", "citation"]
    return any(m in low for m in markers)


BURSTINESS_FIX_PROMPT = """The following text still reads as AI. The sentence rhythm is too uniform and it has AI tells.

FIX THESE SPECIFIC PROBLEMS:
1. Several sentences are within 3 words of each other in length. BREAK THIS UP.
2. Parallel structure in clean lists — merge some items, drop others into fragments
3. Fragments are missing. Add some. Two-word ones. Incomplete thoughts.
4. Every paragraph needs one sentence of 30+ words with multiple clauses and asides
5. Remove any word from this list: delve, navigate, leverage, foster, comprehensive, crucial, intricate, multifaceted, tapestry, landscape, realm, paradigm, pivotal
6. Start at least one sentence with And, But, or So
7. Use contractions everywhere they fit
8. Admit uncertainty somewhere — "I think", "maybe I'm wrong", "my read is"
9. If there's a three-item parallel list, cut it to two or break it asymmetrically

Keep the facts, meaning, and approximate length the same. Return only the rewritten text:

"""


def _burstiness_stats(text):
    """Compute sentence length stats to check if output is human-like."""
    sentences = re.split(r'[.!?]+\s+', text.strip())
    sentences = [s for s in sentences if s.strip()]
    if len(sentences) < 2:
        return 0, 0
    lengths = [len(s.split()) for s in sentences]
    mean = sum(lengths) / len(lengths)
    variance = sum((l - mean) ** 2 for l in lengths) / len(lengths)
    std = variance ** 0.5
    return mean, std


AI_TELLS = [
    "delve", "tapestry", "multifaceted", "holistic", "leverage", "foster",
    "navigate", "landscape", "paradigm", "realm", "pivotal", "testament",
    "cutting-edge", "ever-evolving", "seamless", "underscore", "comprehensive",
    "furthermore", "moreover", "notably", "particularly", "additionally",
    "crucial", "insights", "meticulously", "intricate", "groundbreaking",
    "commendable", "exhibited", "it is important to note", "it is worth noting",
    "in conclusion", "in essence", "navigate the complexities",
    "plays a crucial role", "stands as a testament",
]


def _count_ai_tells(text):
    low = text.lower()
    return sum(1 for tell in AI_TELLS if tell in low)


def _humanize_multipass(text_or_topic, client, is_rewrite=False):
    """
    Multi-pass humanization.
    Pass 1: Persona-conditioned generation/rewrite at T=1.0 (with academic supplement if detected)
    Pass 2: Burstiness/tell check, targeted fix at T=1.1 if needed
    Pass 3: Sentence-level rhythm enforcement at T=1.2 if still too uniform
    Pass 4: Final lexical scrub
    Pass 5: Voice intrusion
    Pass 6: Academic rigor pass (only for academic tasks) — adds citations, evidence layering
    Returns (final_text, stats).
    """
    is_academic = _is_academic_task(text_or_topic) if not is_rewrite else False
    system_prompt = HUMANIZE_SYSTEM + "\n\n" + ACADEMIC_RIGOR_SUPPLEMENT if is_academic else HUMANIZE_SYSTEM

    # PASS 1
    if is_rewrite:
        user_msg = (f"Rewrite this to sound like a real person wrote it. Follow all the voice rules in your instructions. "
                    f"Keep facts and meaning intact. Return ONLY the rewritten text:\n\n{text_or_topic}")
    else:
        user_msg = f"Write: {text_or_topic}"

    try:
        resp = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=3000,
            temperature=1.0,
            system=system_prompt,
            messages=[{"role": "user", "content": user_msg}]
        )
        draft = resp.content[0].text.strip()
    except Exception as e:
        return None, {"error": str(e)}

    mean, std = _burstiness_stats(draft)
    tell_count = _count_ai_tells(draft)

    # PASS 2 — aggressive fix if still AI-flavored
    if std < 8.0 or tell_count > 2:
        try:
            resp2 = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=3000,
                temperature=1.1,
                system=system_prompt,
                messages=[{"role": "user", "content": BURSTINESS_FIX_PROMPT + draft}]
            )
            draft = resp2.content[0].text.strip()
            mean, std = _burstiness_stats(draft)
            tell_count = _count_ai_tells(draft)
        except Exception:
            pass

    # PASS 3 — if STILL too uniform, do a rhythm-specific pass at higher temperature
    if std < 8.0:
        rhythm_prompt = (
            f"This text has uniform sentence lengths (σ={std:.1f}, target ≥9). "
            f"AI detectors catch this. Rewrite it with AGGRESSIVE variance:\n"
            f"- Break at least 3 sentences into fragments (2-8 words)\n"
            f"- Merge at least 2 sentences into a single 30+ word sentence with asides\n"
            f"- Make sure no two adjacent sentences are within 5 words of the same length\n"
            f"- Keep meaning identical\n\n{draft}"
        )
        try:
            resp3 = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=2500,
                temperature=1.2,
                system=HUMANIZE_SYSTEM,
                messages=[{"role": "user", "content": rhythm_prompt}]
            )
            draft = resp3.content[0].text.strip()
            mean, std = _burstiness_stats(draft)
            tell_count = _count_ai_tells(draft)
        except Exception:
            pass

    # PASS 4 — final lexical scrub
    if tell_count > 0:
        found_tells = [t for t in AI_TELLS if t in draft.lower()]
        scrub_prompt = (
            f"These AI-tell words appear in the text: {', '.join(found_tells)}. "
            f"Remove them all. Use natural alternatives a real person would use. "
            f"Don't change anything else. Return only the cleaned text:\n\n{draft}"
        )
        try:
            resp4 = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=2500,
                temperature=0.7,
                messages=[{"role": "user", "content": scrub_prompt}]
            )
            draft = resp4.content[0].text.strip()
            mean, std = _burstiness_stats(draft)
            tell_count = _count_ai_tells(draft)
        except Exception:
            pass

    # PASS 5 — voice intrusion pass
    # Breaks up "encyclopedic" sections that read clean but still flag as AI
    # because they have balanced parallel facts and no personal voice breaks
    voice_intrusion_prompt = f"""This text is mostly good but some paragraphs read like a textbook — clean factual statements in parallel structure, no voice breaks.

Find the paragraphs that sound "encyclopedic" (like Wikipedia — just organized facts) and inject voice intrusions into them. Voice intrusions are things like:
- Mid-sentence hesitations: "— and this is what gets me —"
- Second thoughts: "which, okay, maybe overstates it"
- Named specifics instead of generic: "a 2019 paper by Hernandez" not "recent research"
- Opinion asides: "which, honestly, is wild"
- Directly addressing the reader: "you've probably seen the photos"
- Self-correction: "actually, let me back up"
- "I keep thinking about", "what bugs me", "the part people miss"

Don't change the facts or overall argument. Don't add or remove paragraphs. Just break up the clean parallel-list sentences with voice. Make at least 3 sentences that are currently clean declaratives into voice-broken versions.

If a paragraph has three facts in parallel structure (A is X. B is Y. C is Z.), convert at least one into a voice intrusion or asymmetric break. Don't keep all three in the same shape.

Return only the rewritten text:

{draft}"""

    try:
        resp5 = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=4000,
            temperature=1.0,
            system=HUMANIZE_SYSTEM,
            messages=[{"role": "user", "content": voice_intrusion_prompt}]
        )
        draft = resp5.content[0].text.strip()
        mean, std = _burstiness_stats(draft)
        tell_count = _count_ai_tells(draft)
    except Exception:
        pass

    # PASS 6 — Academic rigor pass (ONLY for academic tasks)
    # Reviews the draft against A-level criteria and forces: real citations,
    # layered evidence, direct quotes, engaged counterarguments
    if is_academic:
        rigor_prompt = f"""This is an academic essay draft that reads human but lacks the rigor for an A grade. Your job is to upgrade it without losing the human voice.

Review this draft against these A-level criteria and fix what's missing:

1. CITATIONS: Every named source must have author, italicized title in *asterisks*, and year. Example: "Engels, *The Condition of the Working Class in England* (1845)". If scholars are named by surname only (e.g., "McCloskey, Mokyr"), add at least one specific work or argument they made.

2. DIRECT QUOTES: Add at least one direct quote from a primary source (in quotation marks, 5-15 words). If you can't recall the exact quote, don't invent one — instead paraphrase more precisely and attribute.

3. LAYERED EVIDENCE: Each body paragraph should have 2-3 concrete pieces of evidence. If a paragraph leans on one example, add one more — a statistic, a second incident, or another scholar's finding. Numbers need context (wages without prices are meaningless).

4. STEELMAN COUNTERARGUMENT: The counterargument paragraph should present the opposing view as its strongest proponents would, using their terms, before rebutting. If it's currently dismissive, rewrite to steelman first.

5. DEFINE TERMS: Somewhere in the essay, explicitly define what the contested term means in your argument. "When I say 'benefit,' I mean X, not Y."

6. CONCLUSION FIX: If the conclusion recaps, rewrite it. A good conclusion pushes the argument further or raises a definitional question — does NOT summarize.

7. KEEP ALL VOICE: Preserve the fragments, opinion asides, contractions, hedged uncertainties, first-person voice. Rigor should come from STRUCTURAL moves (evidence, citation, engagement) — not by making the prose more formal.

Return only the upgraded essay:

{draft}"""

        try:
            resp6 = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=3500,
                temperature=0.9,
                system=system_prompt,
                messages=[{"role": "user", "content": rigor_prompt}]
            )
            draft = resp6.content[0].text.strip()
            mean, std = _burstiness_stats(draft)
            tell_count = _count_ai_tells(draft)
        except Exception:
            pass

    stats = {
        "sentence_count": len(re.split(r'[.!?]+\s+', draft.strip())),
        "mean_length": round(mean, 1),
        "std_length": round(std, 1),
        "ai_tells": tell_count,
        "burstiness_ok": std >= 8.0,
        "tells_ok": tell_count <= 1,
        "academic_mode": is_academic,
    }
    return draft, stats


def handle_natural_writing(text, client=None):
    if not client:
        return None
    low = text.lower()

    # "write X naturally/humanly" / "write a X that sounds human"
    m = re.match(r"(?:write|draft|compose|create)\s+(?:me\s+)?(?:a\s+|an\s+)?(.+?)(?:\s+(?:naturally|like a human|that sounds human|in a natural voice|human(?:ized)?))?$", text, re.IGNORECASE)
    if m and any(w in low for w in ["naturally", "human", "natural voice", "sounds human", "humanized"]):
        topic = m.group(1).strip()
        result, stats = _humanize_multipass(topic, client, is_rewrite=False)
        if result:
            subprocess.run(["pbcopy"], input=result.encode(), capture_output=True)
            stats_line = (f"\n\n[stats: {stats['sentence_count']} sentences, "
                         f"σ={stats['std_length']} (≥7 is human-like), "
                         f"AI tells={stats['ai_tells']}]")
            return f"{result}{stats_line}\n\n(copied to clipboard)"
        return "Couldn't generate. Try again."

    # "make this sound human" / "humanize this" / "rewrite this naturally"
    if any(p in low for p in [
        "make this sound human", "make it sound human",
        "humanize this", "humanize it", "humanize the",
        "rewrite this naturally", "rewrite it naturally",
        "make this natural", "make it natural",
        "rewrite this to sound human", "rewrite to sound human",
        "de-ai this", "make this less ai", "fix the ai writing",
        "make this human"]):
        try:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3)
            clipboard = r.stdout.strip()
        except Exception:
            return "Couldn't read clipboard."
        if not clipboard:
            return "Clipboard is empty. Copy the text you want rewritten first."
        if len(clipboard) < 50:
            return "Clipboard content is too short. Copy at least a paragraph."

        result, stats = _humanize_multipass(clipboard[:6000], client, is_rewrite=True)
        if result:
            subprocess.run(["pbcopy"], input=result.encode(), capture_output=True)
            stats_line = (f"\n\n[stats: {stats['sentence_count']} sentences, "
                         f"σ={stats['std_length']} (≥7 is human-like), "
                         f"AI tells={stats['ai_tells']}]")
            return f"{result}{stats_line}\n\n(copied to clipboard)"
        return "Couldn't rewrite. Try again."

    # "analyze this for AI tells" / "check this for AI patterns"
    if any(p in low for p in ["analyze this for ai", "check this for ai",
                               "check ai tells", "ai detector check",
                               "how ai does this sound", "how ai is this"]):
        try:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3)
            clipboard = r.stdout.strip()
        except Exception:
            return "Couldn't read clipboard."
        if not clipboard:
            return "Clipboard is empty."
        mean, std = _burstiness_stats(clipboard)
        tells = _count_ai_tells(clipboard)
        tell_list = [t for t in AI_TELLS if t in clipboard.lower()][:10]
        verdict = "likely human" if std >= 8 and tells <= 1 else \
                  "likely AI" if std < 5 or tells > 4 else "mixed signals"
        return (f"AI analysis:\n"
                f"- Sentence length σ: {std:.1f} (humans ≥8, AI 3-6)\n"
                f"- Mean length: {mean:.1f} words\n"
                f"- AI-tell words found: {tells}{' — ' + ', '.join(tell_list) if tell_list else ''}\n"
                f"- Verdict: {verdict}")

    # "edit this" / "edit my essay" — light edit keeping user's voice and most wording
    if any(p in low for p in ["edit this", "edit my essay", "edit the essay",
                               "edit my paper", "edit this paper", "edit this essay",
                               "proofread this", "proofread my",
                               "polish this", "polish my essay",
                               "revise this", "revise my essay"]):
        try:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3)
            clipboard = r.stdout.strip()
        except Exception:
            return "Couldn't read clipboard."
        if not clipboard:
            return "Clipboard is empty. Copy your essay first, then try again."
        if len(clipboard) < 100:
            return "Clipboard content is too short — copy at least a paragraph."

        edit_prompt = f"""You are editing this essay to make it stronger without rewriting it. The author's voice, ideas, and argument must stay intact. Your job is to improve it, not replace it.

EDIT RULES:
- Keep at least 85% of the original wording unchanged
- Fix grammar, typos, and awkward phrasing
- Tighten sentences that are wordy — cut filler, not content
- Flag weak arguments or unclear passages by fixing them minimally, not rewriting them
- If a paragraph is confusingly organized, reorder sentences but keep the wording
- Replace vague words with more specific ones (but keep the author's vocabulary range)
- Don't add new ideas or evidence — that's the author's job
- Preserve their voice, opinions, and personality
- Preserve idiosyncrasies that are clearly intentional (fragments, asides, contractions)

DO NOT:
- Rewrite sentences that are already good
- Change the author's position or thesis
- Make the prose more formal if it's casual, or vice versa
- Strip out contractions or voice intrusions
- Add AI-flavored vocabulary (delve, navigate, landscape, comprehensive, etc.)
- Introduce parallel structures or tricolons

After editing, list 3-5 specific things the author should improve themselves (evidence gaps, weak arguments, missing citations). Do NOT fix these — flag them for the author.

Format your output as:
[EDITED ESSAY]

---
THINGS TO IMPROVE YOURSELF:
1. ...
2. ...

Now edit this essay:

{clipboard[:8000]}"""

        try:
            resp = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=4000,
                temperature=0.5,
                messages=[{"role": "user", "content": edit_prompt}]
            )
            result = resp.content[0].text.strip()
            # Copy just the edited essay (before the --- marker)
            essay_only = result.split("---")[0].replace("[EDITED ESSAY]", "").strip()
            subprocess.run(["pbcopy"], input=essay_only.encode(), capture_output=True)
            return f"{result}\n\n(edited essay copied to clipboard — feedback stays below)"
        except Exception as e:
            return f"Edit failed: {e}"

    # "critique this" / "review my essay" — feedback only, no rewriting
    if any(p in low for p in ["critique this", "critique my essay", "critique my paper",
                               "review this essay", "review my essay", "review my paper",
                               "give me feedback on this", "feedback on my essay",
                               "what's wrong with this essay", "grade my essay",
                               "grade this essay"]):
        try:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3)
            clipboard = r.stdout.strip()
        except Exception:
            return "Couldn't read clipboard."
        if not clipboard:
            return "Clipboard is empty. Copy your essay first."
        if len(clipboard) < 100:
            return "Clipboard content is too short — copy at least a paragraph."

        critique_prompt = f"""You are a sharp professor grading an essay. Give honest, useful feedback. Don't be mean, don't be soft. Be specific.

Evaluate the essay on:
1. THESIS — Is it arguable? Specific? Defined?
2. EVIDENCE — Layered and concrete, or thin and vague? Named sources with titles/years?
3. ARGUMENT QUALITY — Real analytical moves or just description?
4. COUNTERARGUMENT — Steelmanned or dismissed?
5. WRITING — Clear prose, good rhythm, voice?
6. STRUCTURE — Does it build? Or just pile up paragraphs?
7. GRADE — Give a letter grade (A/A-/B+/B/B-/C/D/F) with one sentence why

For each area, give:
- What WORKS (be specific — cite the actual sentence or paragraph)
- What's WEAK (be specific — quote or paraphrase the exact problem)
- Concrete fix (not vague advice like "add more evidence")

End with 3 highest-priority fixes the author should make, ranked.

Don't rewrite anything. Don't give them the fix — tell them what to fix.

Essay:

{clipboard[:8000]}"""

        try:
            resp = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=2500,
                temperature=0.7,
                messages=[{"role": "user", "content": critique_prompt}]
            )
            result = resp.content[0].text.strip()
            return result
        except Exception as e:
            return f"Critique failed: {e}"

    # "fix this essay" / "upgrade this essay" — full pass: critique + revise structural issues + humanize
    # This is the one-command version that does everything
    fix_triggers = ["fix this essay", "upgrade this essay", "improve this essay",
                    "make this essay better", "make this essay an a",
                    "fix my essay", "upgrade my essay", "improve my essay",
                    "full revision", "deep edit", "major revision",
                    "fix and humanize", "revise and humanize"]
    extra_fix_instructions = None
    matched_fix = False
    for trig in fix_triggers:
        if low.startswith(trig):
            matched_fix = True
            rest = text[len(trig):].strip()
            if rest.startswith(",") or rest.startswith(".") or rest.startswith(":"):
                rest = rest[1:].strip()
            if rest and len(rest) > 5:
                extra_fix_instructions = rest
            break
        if trig in low:
            matched_fix = True
            break

    if matched_fix:
        try:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=3)
            clipboard = r.stdout.strip()
        except Exception:
            return "Couldn't read clipboard."
        if not clipboard:
            return "Clipboard is empty. Copy your essay first."
        if len(clipboard) < 200:
            return "Clipboard content is too short. Copy the full essay."

        # PHASE 1: Silent critique — identify weaknesses
        critique_prompt_internal = f"""Analyze this essay against A-level academic criteria. Identify the specific weaknesses that would drop its grade. Focus on:
- Missing or weak counterarguments
- Thin evidence (especially plot summary where scene-level detail is needed)
- Missing direct quotes from primary sources
- Missing citations (author, title, year)
- Non-comparative structure where a comparative thesis is promised
- Weak conclusion that recaps instead of pushing forward
- Vague assertions that should be concrete claims with evidence

Return ONLY a numbered list of the 3-5 most important issues, each as one specific sentence. No preamble.

Essay:

{clipboard[:8000]}"""

        try:
            critique_resp = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=1200,
                temperature=0.5,
                messages=[{"role": "user", "content": critique_prompt_internal}]
            )
            issues = critique_resp.content[0].text.strip()
        except Exception as e:
            return f"Critique phase failed: {e}"

        # PHASE 2: Revise to address the identified issues
        revise_prompt = f"""You are revising this essay to fix specific weaknesses identified by an academic reader. The author's voice, thesis, and argument structure must stay intact — you're improving the essay, not rewriting it.

WEAKNESSES TO ADDRESS:
{issues}

{f"ADDITIONAL INSTRUCTIONS FROM AUTHOR: {extra_fix_instructions}" if extra_fix_instructions else ""}

REVISION RULES:
- Keep 70%+ of original wording where it works
- Add missing counterarguments as new paragraphs — steelman the opposing view, then answer it using the author's framework
- Replace plot summary with scene-level textual evidence (describe what actually happens in specific scenes, what's said, what visuals or choices matter)
- Add direct quotes from primary sources where missing — use short quotes (5-15 words) in quotation marks; if uncertain of exact wording, paraphrase more precisely and attribute
- Fix citation format: author, *italicized title* in asterisks, year
- Restructure paragraphs if the thesis is comparative but the structure is sequential — put works in direct conversation
- Fix weak conclusions that recap — push the argument forward instead
- Keep the author's voice: contractions, opinion asides, fragments, hedged uncertainties

DO NOT:
- Replace the author's thesis or change their position
- Make the prose more formal than theirs
- Add AI-flavored vocabulary
- Strip out voice intrusions or first-person asides
- Use tricolons or parallel balanced prose

Return ONLY the revised essay. No headings, no preamble, no explanation of changes.

Original essay:

{clipboard[:8000]}"""

        try:
            revise_resp = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=4500,
                temperature=0.8,
                system=HUMANIZE_SYSTEM + "\n\n" + ACADEMIC_RIGOR_SUPPLEMENT,
                messages=[{"role": "user", "content": revise_prompt}]
            )
            revised = revise_resp.content[0].text.strip()
        except Exception as e:
            return f"Revision phase failed: {e}"

        # PHASE 3: Humanize the revised essay (all passes)
        result, stats = _humanize_multipass(revised, client, is_rewrite=True)
        if not result:
            result = revised
            stats = {"sentence_count": 0, "std_length": 0, "ai_tells": 0}

        subprocess.run(["pbcopy"], input=result.encode(), capture_output=True)

        summary = (f"\n\n---\n"
                   f"ISSUES THAT WERE FIXED:\n{issues}\n\n"
                   f"[stats: σ={stats.get('std_length', 0)}, "
                   f"AI tells={stats.get('ai_tells', 0)}]\n\n"
                   f"(final essay copied to clipboard)")
        return f"{result}{summary}"

    # "write a story" / creative fiction mode — different persona, no academic rules
    m_story = re.match(r"(?:write|draft|create|tell me)\s+(?:me\s+)?(?:a\s+|an\s+)?"
                       r"(?:short\s+)?(story|poem|narrative|scene|fiction|flash fiction|chapter|dialogue)"
                       r"\s+(.+)$", text, re.IGNORECASE)
    if m_story:
        form = m_story.group(1).lower()
        rest = m_story.group(2).strip()
        # Strip "about" prefix if present
        topic = re.sub(r"^about\s+", "", rest, flags=re.IGNORECASE)

        creative_system = """You are writing fiction. Not an essay. Not a blog post. Fiction.

VOICE: Whatever voice fits the story. Third-person limited, first-person confession, omniscient — pick based on the material, don't default.

PROSE RULES:
- Sentence lengths MUST vary wildly — 2 to 50 words
- Fragments are a tool. Use them.
- Never two medium-length sentences (15-22 words) in a row
- Concrete sensory detail over abstraction. Show the specific, not the general.
- Trust the reader. Don't over-explain.
- Let the prose breathe — one-line paragraphs, long paragraphs, mixed.

NEVER USE (these are AI fiction tells — see Max Read's documentation):
- "voice barely above a whisper"
- "quiet hum", "soft hum", "gentle hum"
- "liminal", "ethereal", "luminescent"
- "ghost of a smile", "whisper of a breeze"
- "she said softly", "he whispered gently" with adverbial tag
- "air thick with" / "heavy with" (anything)
- "echoed through", "echoed in the silence"
- "time seemed to stand still"
- Any sentence that ends with "... or perhaps something more."

NEVER USE (general AI tells):
delve, tapestry, multifaceted, holistic, leverage, foster, navigate, landscape, paradigm, realm, pivotal, testament, ever-evolving, seamless, comprehensive, furthermore, moreover

AVOID:
- Clean resolutions where every thread ties up
- Moral conclusions tacked onto the end
- Protagonist reflecting on what they learned
- "In that moment, she realized..." closings
- Describing a character's appearance in the first paragraph
- Weather metaphors for emotion unless earned
- Symbolism that the narrator explains

GOOD FICTION DOES:
- Leave loose threads
- Drop the reader in medias res
- Trust subtext over statement
- Use specific proper nouns (brand names, place names, song titles)
- Let dialogue carry character, not description
- Have at least one surprising moment of specificity — a weird detail that feels true

OUTPUT: Just the story. No title unless requested. No explanation."""

        try:
            resp = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=3000,
                temperature=1.1,
                system=creative_system,
                messages=[{"role": "user", "content": f"Write a {form} about: {topic}"}]
            )
            result = resp.content[0].text.strip()
            subprocess.run(["pbcopy"], input=result.encode(), capture_output=True)
            mean, std = _burstiness_stats(result)
            stats_line = f"\n\n[{len(result.split())} words, σ={std:.1f}]"
            return f"{result}{stats_line}\n\n(copied to clipboard)"
        except Exception as e:
            return f"Creative writing failed: {e}"

    return None
# Take screenshot → ask Claude → copy answer to clipboard
import tempfile, base64

def handle_screen_read(text, client=None):
    if not client:
        return None
    low = text.lower().strip()

    triggers = {
        "read my screen": "Read what's on this screen and give me a clear, accurate summary",
        "whats on my screen": "Describe what's on this screen concisely",
        "what's on my screen": "Describe what's on this screen concisely",
        "answer whats on my screen": "Find the question or task on this screen and give me a complete answer",
        "answer what's on my screen": "Find the question or task on this screen and give me a complete answer",
        "solve whats on my screen": "Find and solve whatever problem is on this screen. Show the answer clearly",
        "solve what's on my screen": "Find and solve whatever problem is on this screen. Show the answer clearly",
        "read this screen": "Read what's on this screen and give me a clear summary",
        "read the screen": "Read what's on this screen and give me a clear summary",
        "answer it from my screen": "Find the question on my screen and answer it",
        "fill this in": "Look at the form/question on screen and give me what should go in each empty field",
        "explain whats on my screen": "Explain what's happening on this screen in plain terms",
        "explain what's on my screen": "Explain what's happening on this screen in plain terms",
    }

    matched = None
    low_clean = low.rstrip('.!?,').strip()
    for trigger, instruction in triggers.items():
        if low_clean == trigger or low_clean.startswith(trigger + " "):
            matched = (trigger, instruction)
            break

    # Also match "read my screen and X" / "answer the question on my screen"
    if not matched:
        m = re.match(r"(?:read|look at|check)\s+(?:my\s+|the\s+)?screen\s+and\s+(.+)", low)
        if m:
            matched = ("read my screen and X", f"Look at this screen and {m.group(1)}")
        elif "on my screen" in low or "on the screen" in low:
            # Generic: "X on my screen" → send screenshot with their actual question
            matched = ("generic screen question", f"Look at this screen. The user asks: {text}")

    if not matched:
        return None

    instruction = matched[1]

    # Take screenshot (full screen, downscaled for cost)
    try:
        raw = tempfile.mktemp(suffix=".png")
        tmp = tempfile.mktemp(suffix=".png")
        subprocess.run(["screencapture", "-x", "-t", "png", raw],
                       capture_output=True, timeout=5)
        # Downscale for faster processing
        subprocess.run(["sips", "-Z", "1400", raw, "--out", tmp],
                       capture_output=True, timeout=5)
        with open(tmp, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode()
        for p in [raw, tmp]:
            try: os.unlink(p)
            except: pass
    except Exception as e:
        return f"Couldn't capture screen: {e}"

    try:
        resp = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1500,
            messages=[{"role": "user", "content": [
                {"type": "image", "source": {"type": "base64",
                 "media_type": "image/png", "data": img_b64}},
                {"type": "text", "text": instruction}
            ]}]
        )
        answer = resp.content[0].text.strip()
        # Copy to clipboard for easy pasting
        subprocess.run(["pbcopy"], input=answer.encode(), capture_output=True)
        return f"{answer}\n\n(copied to clipboard)"
    except Exception as e:
        return f"Error reading screen: {e}"


# ── MAIN ENTRYPOINT ──────────────────────────────────────────────────────────
def handle_email_capability(text, client=None):
    try:
        from email_agent import handle_email
        return handle_email(text, client)
    except ImportError:
        return None


def try_capability(text, client=None, speak_response=True, speak_fn=None):
    """
    Try each capability handler. Return (handled, response).
    Returns (False, None) if no handler matched — fall through to main classifier.
    """
    for handler in [
        handle_file_ops,
        handle_git,
        handle_clipboard,
        handle_calendar,
        handle_project,
        handle_shell,
    ]:
        try:
            result = handler(text)
            if result:
                if speak_response and speak_fn:
                    # Speak just a short confirmation, print full
                    short = result.split('\n')[0][:100]
                    speak_fn(short)
                return True, result
        except Exception as e:
            print(f"[capability] {handler.__name__} error: {e}")

    # Handlers that need the Claude client
    if client:
        for handler in [handle_email_capability, handle_screen_read, handle_clipboard_action, handle_natural_writing, handle_web_research]:
            try:
                result = handler(text, client)
                if result:
                    if speak_response and speak_fn:
                        speak_fn(result[:200])
                    return True, result
            except Exception as e:
                print(f"[capability] {handler.__name__} error: {e}")

    return False, None
