"""
screen_watcher.py — Continuous screen awareness and habit learning for Alfred

Always watching (like Omi), always learning. Alfred observes what you're
working on, detects your routines and workflows, and uses that context to
give more personalized, anticipatory responses.

WHAT IT DOES:
  - Takes a screenshot every WATCH_INTERVAL seconds (default: 60s)
  - Claude Vision analyzes it into a structured activity record
  - Logs activity to SQLite (semantic summaries only — no raw pixels stored)
  - Runs pattern analysis every 30 min → detects habits and routines
  - Stores learned patterns to the memory graph for cross-session recall
  - Exposes get_context() for Alfred to inject into every response

PRIVACY:
  - Raw screenshots are NEVER stored — only semantic summaries
  - Skips analysis when screen is locked or during calls
  - If sensitive content detected (passwords, banking) → logs only app name
  - User can say "alfred stop watching" or "alfred forget my habits"

PUBLIC API:
  start(client, speak_fn)         — begin watching (background thread)
  stop()                          — pause watching
  get_context() -> str            — current activity + habits (for injection)
  get_habits_summary() -> str     — full readable habits report
  handle_watcher_command(text)    — returns str | None for commands
"""

from __future__ import annotations

import base64
import json
import os
import sqlite3
import subprocess
import tempfile
import threading
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import Callable, Optional

# ── Config ────────────────────────────────────────────────────────────────────
from config import WATCH_DB

WATCH_INTERVAL   = 60       # seconds between screen captures
PATTERN_INTERVAL = 300     # seconds between pattern learning runs (30 min)
MAX_DAYS_RAW     = 30       # keep raw activity this many days
MIN_DAYS_PATTERN = 1        # min days of data before detecting patterns
VISION_MODEL     = "claude-haiku-4-5-20251001"

# Tasks that indicate "deep work" — worth tracking for focus patterns
DEEP_WORK_TASKS = {"coding", "writing", "design", "spreadsheet", "reading"}

ANALYSIS_SYSTEM = (
    "You analyze screenshots to understand user activity. "
    "Return ONLY a JSON object — no markdown, no explanation."
)

ANALYSIS_PROMPT = """\
Look at this screenshot. Return exactly this JSON (fill in the values):
{
  "app": "<frontmost app name, or 'unknown'>",
  "task_type": "<one of: coding, writing, email, messaging, browsing, design, spreadsheet, video, reading, meeting, terminal, file_management, idle, other>",
  "task_summary": "<one sentence: what the user appears to be doing — specific but brief>",
  "focus_level": "<high | medium | low>",
  "window_title": "<best guess at document/tab title visible, or empty string>",
  "sensitive": <true if you see passwords, private messages, financial data, medical info — if so, set task_summary to just the app name>
}
Only the JSON. Nothing else."""


# ── Database ──────────────────────────────────────────────────────────────────

SCHEMA = """
CREATE TABLE IF NOT EXISTS activities (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           REAL NOT NULL,
    hour         INTEGER NOT NULL,
    dow          INTEGER NOT NULL,  -- 0=Mon 6=Sun
    app          TEXT NOT NULL,
    task_type    TEXT NOT NULL,
    task_summary TEXT NOT NULL,
    focus_level  TEXT NOT NULL,
    window_title TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_act_ts   ON activities(ts DESC);
CREATE INDEX IF NOT EXISTS idx_act_app  ON activities(app);
CREATE INDEX IF NOT EXISTS idx_act_type ON activities(task_type);

CREATE TABLE IF NOT EXISTS patterns (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_type TEXT NOT NULL,
    label        TEXT NOT NULL,
    description  TEXT NOT NULL,
    confidence   REAL NOT NULL,
    sample_count INTEGER NOT NULL,
    first_seen   REAL NOT NULL,
    last_seen    REAL NOT NULL,
    UNIQUE(pattern_type, label)
);

CREATE TABLE IF NOT EXISTS watcher_state (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(WATCH_DB)
    conn.row_factory = sqlite3.Row
    return conn


def _init_db():
    conn = _db()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


# ── Module state ──────────────────────────────────────────────────────────────

_state = {
    "running":         False,
    "paused":          False,
    "last_activity":   None,   # most recent activity dict
    "last_pattern_run": 0.0,
    "thread":          None,
    "pattern_thread":  None,
}

_client   = None
_speak_fn: Optional[Callable] = None
_lock     = threading.Lock()


# ── Screenshot + analysis ─────────────────────────────────────────────────────

def _capture_b64() -> Optional[str]:
    """Capture screen, downscale, return base64 PNG. Returns None on failure."""
    try:
        raw = tempfile.mktemp(suffix=".png")
        tmp = tempfile.mktemp(suffix=".png")
        subprocess.run(
            ["screencapture", "-x", "-t", "png", raw],
            capture_output=True, timeout=5
        )
        if not os.path.exists(raw):
            return None
        # Downscale to ~1024px wide — enough for vision, small for API
        subprocess.run(
            ["sips", "-Z", "1024", raw, "--out", tmp],
            capture_output=True, timeout=5
        )
        src = tmp if os.path.exists(tmp) else raw
        with open(src, "rb") as f:
            data = base64.b64encode(f.read()).decode()
        for p in [raw, tmp]:
            try:
                os.unlink(p)
            except Exception:
                pass
        return data
    except Exception as e:
        print(f"[watcher] screenshot failed: {e}")
        return None


def _analyze_screen(img_b64: str) -> Optional[dict]:
    """Send screenshot to Claude Vision, get structured activity dict."""
    if not _client:
        return None
    try:
        resp = _client.messages.create(
            model=VISION_MODEL,
            max_tokens=256,
            system=ANALYSIS_SYSTEM,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": img_b64,
                        },
                    },
                    {"type": "text", "text": ANALYSIS_PROMPT},
                ],
            }],
        )
        raw = resp.content[0].text.strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        return json.loads(raw)
    except Exception as e:
        print(f"[watcher] vision analysis failed: {e}")
        return None


def _is_screen_locked() -> bool:
    try:
        r = subprocess.run(
            ["python3", "-c",
             "from Quartz import CGSessionCopyCurrentDictionary; "
             "d=CGSessionCopyCurrentDictionary(); "
             "print(d.get('CGSSessionScreenIsLocked',0) if d else 0)"],
            capture_output=True, text=True, timeout=2
        )
        return r.stdout.strip() == "1"
    except Exception:
        return False


def _is_in_call() -> bool:
    try:
        r = subprocess.run(
            'osascript -e "tell application \\"System Events\\" to get name of every process"',
            shell=True, capture_output=True, text=True, timeout=3
        )
        return any(app in r.stdout for app in
                   ["zoom.us", "Zoom", "Teams", "Webex", "FaceTime", "Meet"])
    except Exception:
        return False


# ── Activity logging ──────────────────────────────────────────────────────────

def _log_activity(activity: dict):
    """Persist activity record to SQLite."""
    now = time.time()
    dt  = datetime.fromtimestamp(now)
    conn = _db()
    try:
        conn.execute(
            """INSERT INTO activities
               (ts, hour, dow, app, task_type, task_summary, focus_level, window_title)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                now,
                dt.hour,
                dt.weekday(),
                activity.get("app", "unknown")[:64],
                activity.get("task_type", "other"),
                activity.get("task_summary", "")[:256],
                activity.get("focus_level", "medium"),
                activity.get("window_title", "")[:128],
            )
        )
        conn.commit()
    finally:
        conn.close()

    # Prune old records
    cutoff = now - MAX_DAYS_RAW * 86400
    conn = _db()
    try:
        conn.execute("DELETE FROM activities WHERE ts < ?", (cutoff,))
        conn.commit()
    finally:
        conn.close()


def _get_recent_activities(limit: int = 20) -> list[dict]:
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT * FROM activities ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Pattern learning ──────────────────────────────────────────────────────────

def _days_of_data() -> int:
    """How many calendar days of activity data we have."""
    conn = _db()
    try:
        row = conn.execute(
            "SELECT MIN(ts), MAX(ts) FROM activities"
        ).fetchone()
        if not row or not row[0]:
            return 0
        return max(1, int((row[1] - row[0]) / 86400))
    finally:
        conn.close()


def _upsert_pattern(pattern_type: str, label: str, description: str,
                    confidence: float, sample_count: int):
    now = time.time()
    conn = _db()
    try:
        existing = conn.execute(
            "SELECT id, first_seen FROM patterns WHERE pattern_type=? AND label=?",
            (pattern_type, label)
        ).fetchone()
        if existing:
            conn.execute(
                """UPDATE patterns SET description=?, confidence=?,
                   sample_count=?, last_seen=? WHERE id=?""",
                (description, confidence, sample_count, now, existing["id"])
            )
        else:
            conn.execute(
                """INSERT INTO patterns
                   (pattern_type, label, description, confidence, sample_count, first_seen, last_seen)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (pattern_type, label, description, confidence, sample_count, now, now)
            )
        conn.commit()
    finally:
        conn.close()


def _learn_time_of_day_habits():
    """What task types dominate each hour of the day?"""
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT hour, task_type, COUNT(*) as cnt FROM activities GROUP BY hour, task_type"
        ).fetchall()
    finally:
        conn.close()

    # Aggregate: for each hour, find dominant task_type
    hour_counts: dict[int, Counter] = defaultdict(Counter)
    for r in rows:
        hour_counts[r["hour"]][r["task_type"]] += r["cnt"]

    for hour, counter in hour_counts.items():
        total = sum(counter.values())
        if total < 5:
            continue  # not enough data for this hour
        dominant, count = counter.most_common(1)[0]
        if dominant == "idle":
            continue
        confidence = count / total
        if confidence < 0.5:
            continue  # no clear pattern

        hour_str = datetime.now().replace(hour=hour, minute=0).strftime("%-I%p").lower()
        label = f"hour_{hour:02d}_{dominant}"
        description = (
            f"Around {hour_str} you're usually {dominant} "
            f"({int(confidence*100)}% of observations)"
        )
        _upsert_pattern("time_habit", label, description, confidence, count)


def _learn_app_sequences():
    """What apps do you tend to use together or in sequence?"""
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT app, ts FROM activities ORDER BY ts ASC"
        ).fetchall()
    finally:
        conn.close()

    if len(rows) < 20:
        return

    # Find app→app transitions within 5 minutes
    transitions: Counter = Counter()
    for i in range(len(rows) - 1):
        a, b = rows[i]["app"], rows[i+1]["app"]
        gap = rows[i+1]["ts"] - rows[i]["ts"]
        if a != b and gap < 300:
            transitions[(a, b)] += 1

    for (a, b), count in transitions.most_common(10):
        if count < 3:
            break
        label = f"seq_{a[:20]}_{b[:20]}"
        description = f"You often switch from {a} to {b} ({count} times observed)"
        confidence = min(0.99, count / max(1, len(rows) // 10))
        _upsert_pattern("app_sequence", label, description, confidence, count)


def _learn_morning_routine():
    """What's the first thing you do after 7am?"""
    conn = _db()
    try:
        rows = conn.execute(
            """SELECT date(ts, 'unixepoch', 'localtime') as day,
                      app, task_type, MIN(ts) as first_ts
               FROM activities WHERE hour >= 7 AND hour <= 10
               GROUP BY day, app
               ORDER BY day DESC, first_ts ASC"""
        ).fetchall()
    finally:
        conn.close()

    # Group by day, take first activity per day
    day_firsts: dict[str, str] = {}
    for r in rows:
        day = r["day"]
        if day not in day_firsts:
            day_firsts[day] = r["task_type"]

    if len(day_firsts) < MIN_DAYS_PATTERN:
        return

    task_counter = Counter(day_firsts.values())
    dominant, count = task_counter.most_common(1)[0]
    confidence = count / len(day_firsts)
    if confidence >= 0.5 and dominant != "idle":
        description = (
            f"Your morning usually starts with {dominant} "
            f"({int(confidence*100)}% of mornings observed)"
        )
        _upsert_pattern("morning_routine", f"morning_{dominant}", description,
                        confidence, count)


def _learn_focus_blocks():
    """Detect sustained deep-work sessions (30+ min in same task)."""
    conn = _db()
    try:
        rows = conn.execute(
            """SELECT task_type, hour, COUNT(*) as cnt
               FROM activities
               WHERE task_type IN ('coding','writing','design','reading','spreadsheet')
               GROUP BY task_type, hour
               HAVING cnt >= 3"""
        ).fetchall()
    finally:
        conn.close()

    for r in rows:
        hour_str = datetime.now().replace(hour=r["hour"], minute=0).strftime("%-I%p").lower()
        label = f"focus_{r['task_type']}_hour{r['hour']:02d}"
        description = (
            f"You often have focused {r['task_type']} sessions around {hour_str} "
            f"({r['cnt']} observations)"
        )
        confidence = min(0.95, r["cnt"] / 10)
        _upsert_pattern("focus_block", label, description, confidence, r["cnt"])


def run_pattern_learning():
    """Full pattern analysis pass. Runs every PATTERN_INTERVAL seconds."""
    if _days_of_data() < MIN_DAYS_PATTERN:
        print(f"[watcher] not enough data for pattern learning yet")
        return

    print("[watcher] running pattern learning...")
    try:
        _learn_time_of_day_habits()
        _learn_app_sequences()
        _learn_morning_routine()
        _learn_focus_blocks()
        _sync_patterns_to_memory_graph()
        print("[watcher] pattern learning complete")
    except Exception as e:
        print(f"[watcher] pattern learning error: {e}")

    _state["last_pattern_run"] = time.time()


def _sync_patterns_to_memory_graph():
    """Write high-confidence patterns as facts in the memory graph."""
    try:
        import memory_graph as mg
        conn = _db()
        try:
            rows = conn.execute(
                "SELECT * FROM patterns WHERE confidence >= 0.6 ORDER BY confidence DESC LIMIT 20"
            ).fetchall()
        finally:
            conn.close()

        for row in rows:
            mg.add_fact(
                subject="user",
                predicate=f"habit:{row['pattern_type']}",
                obj=row["description"],
                subject_type="person",
                source="screen_watcher",
                confidence=row["confidence"],
            )
    except Exception as e:
        print(f"[watcher] memory graph sync failed: {e}")


# ── Public API ────────────────────────────────────────────────────────────────

def get_context() -> str:
    """
    Returns a concise context string for injection into Alfred's prompts.
    Covers: current activity, recent activity arc, and relevant habits.
    """
    lines = []

    # Current / recent activity
    recent = _get_recent_activities(limit=8)
    if recent:
        current = recent[0]
        ago_s = int(time.time() - current["ts"])
        ago = f"{ago_s//60}m ago" if ago_s > 90 else "just now"
        lines.append(
            f"Current activity ({ago}): {current['task_summary']} "
            f"[{current['app']}, {current['focus_level']} focus]"
        )
        # Last ~5 distinct activities
        seen_apps = set()
        arc = []
        for act in recent[1:6]:
            if act["app"] not in seen_apps:
                seen_apps.add(act["app"])
                arc.append(act["app"])
        if arc:
            lines.append(f"Recent apps: {', '.join(arc)}")

    # Relevant habits for current time
    now_hour = datetime.now().hour
    conn = _db()
    try:
        relevant = conn.execute(
            """SELECT description FROM patterns
               WHERE confidence >= 0.6
                 AND (
                   (pattern_type='time_habit' AND label LIKE ?)
                   OR pattern_type='morning_routine'
                   OR pattern_type='focus_block'
                 )
               ORDER BY confidence DESC LIMIT 4""",
            (f"hour_{now_hour:02d}_%",)
        ).fetchall()
    finally:
        conn.close()

    if relevant:
        habits = [r["description"] for r in relevant]
        lines.append("Learned habits: " + " | ".join(habits))

    return "\n".join(lines) if lines else ""


def get_habits_summary() -> str:
    """Full human-readable summary of everything Alfred has learned."""
    days = _days_of_data()
    if days < 1:
        return "No activity data collected yet. I'll start building your profile as you work."

    conn = _db()
    try:
        patterns = conn.execute(
            "SELECT * FROM patterns ORDER BY pattern_type, confidence DESC"
        ).fetchall()
        activity_count = conn.execute("SELECT COUNT(*) FROM activities").fetchone()[0]
        app_counts = conn.execute(
            "SELECT app, COUNT(*) as cnt FROM activities GROUP BY app ORDER BY cnt DESC LIMIT 8"
        ).fetchall()
    finally:
        conn.close()

    sections = []
    sections.append(f"**Alfred has been watching for {days} day(s)** — {activity_count} activity snapshots.\n")

    # Top apps
    if app_counts:
        apps_str = ", ".join(f"{r['app']} ({r['cnt']})" for r in app_counts)
        sections.append(f"**Most-used apps:** {apps_str}\n")

    # Patterns by type
    by_type: dict[str, list] = defaultdict(list)
    for p in patterns:
        if p["confidence"] >= 0.5:
            by_type[p["pattern_type"]].append(p)

    type_labels = {
        "morning_routine": "Morning routine",
        "time_habit":      "Time-of-day habits",
        "focus_block":     "Deep work patterns",
        "app_sequence":    "Common workflows",
    }

    for ptype, label in type_labels.items():
        items = by_type.get(ptype, [])
        if not items:
            continue
        sections.append(f"**{label}:**")
        for p in items[:5]:
            bar = "█" * int(p["confidence"] * 10)
            sections.append(f"  • {p['description']} [{bar}]")
        sections.append("")

    if not any(by_type.values()):
        sections.append(f"Still learning — need {max(0, MIN_DAYS_PATTERN - days)} more day(s) of data to detect patterns.")

    return "\n".join(sections)


def get_todays_summary() -> str:
    """What the user has been doing today."""
    start_of_day = datetime.now().replace(hour=0, minute=0, second=0).timestamp()
    conn = _db()
    try:
        rows = conn.execute(
            """SELECT task_type, app, COUNT(*) as cnt
               FROM activities WHERE ts >= ?
               GROUP BY task_type, app
               ORDER BY cnt DESC LIMIT 10""",
            (start_of_day,)
        ).fetchall()
        total = conn.execute(
            "SELECT COUNT(*) FROM activities WHERE ts >= ?", (start_of_day,)
        ).fetchone()[0]
    finally:
        conn.close()

    if not rows:
        return "No activity recorded today yet."

    minutes = total * WATCH_INTERVAL // 60
    parts = []
    for r in rows:
        parts.append(f"{r['task_type']} in {r['app']} ({r['cnt']} snapshots)")

    return f"Today ({minutes}+ min tracked): " + ", ".join(parts[:5])


def clear_history():
    """Delete all activity data and learned patterns."""
    conn = _db()
    try:
        conn.execute("DELETE FROM activities")
        conn.execute("DELETE FROM patterns")
        conn.commit()
    finally:
        conn.close()
    return "Screen watch history and learned habits cleared."


# ── Watch loop ────────────────────────────────────────────────────────────────

def _watch_loop():
    print("[watcher] Screen watch started.")
    time.sleep(5)  # brief startup delay

    while _state["running"]:
        try:
            if _state["paused"]:
                time.sleep(WATCH_INTERVAL)
                continue

            if _is_screen_locked() or _is_in_call():
                time.sleep(WATCH_INTERVAL)
                continue

            img_b64 = _capture_b64()
            if img_b64:
                activity = _analyze_screen(img_b64)
                if activity:
                    _log_activity(activity)
                    with _lock:
                        _state["last_activity"] = activity
                    print(f"[watcher] {activity.get('task_type','?')} — {activity.get('task_summary','')[:60]}")

            # Pattern learning (throttled)
            if time.time() - _state["last_pattern_run"] > PATTERN_INTERVAL:
                t = threading.Thread(target=run_pattern_learning, daemon=True)
                t.start()

        except Exception as e:
            print(f"[watcher] loop error: {e}")

        time.sleep(WATCH_INTERVAL)

    print("[watcher] Screen watch stopped.")


# ── Command handler ───────────────────────────────────────────────────────────

def handle_watcher_command(text: str) -> Optional[str]:
    """Returns response string if this is a watcher command, else None."""
    low = text.lower().strip()

    # Status / what have you learned
    if any(p in low for p in [
        "what have you learned about me",
        "what do you know about my habits",
        "show my habits", "show habits",
        "my routine", "what's my routine",
        "what have you noticed",
        "screen watch report", "activity report",
        "what have you been watching",
    ]):
        return get_habits_summary()

    if any(p in low for p in [
        "what did i do today", "what have i been doing",
        "today's activity", "my activity today",
        "what have you seen today",
    ]):
        return get_todays_summary()

    # Stop watching
    if any(p in low for p in [
        "stop watching", "stop screen watch", "pause watching",
        "stop watching my screen", "don't watch my screen",
        "turn off screen watch", "disable screen watch",
    ]):
        _state["paused"] = True
        return "Screen watching paused. Say 'start watching' to resume."

    # Resume
    if any(p in low for p in [
        "start watching", "resume watching", "watch my screen",
        "enable screen watch", "turn on screen watch",
    ]):
        _state["paused"] = False
        return "Screen watching resumed. I'll keep learning your habits."

    # Forget history
    if any(p in low for p in [
        "forget my habits", "forget my history", "clear my habits",
        "delete my activity", "reset screen watch", "forget what you've learned",
        "forget everything you've learned about me",
    ]):
        result = clear_history()
        return result

    # Run pattern analysis now
    if any(p in low for p in [
        "analyze my habits now", "learn my habits now",
        "run pattern analysis", "update my profile",
    ]):
        threading.Thread(target=run_pattern_learning, daemon=True).start()
        return "Running habit analysis now — will update your profile shortly."

    return None


# ── Startup / shutdown ────────────────────────────────────────────────────────

def start(client, speak_fn: Optional[Callable] = None):
    """Start the screen watcher background thread."""
    global _client, _speak_fn

    _init_db()
    _client   = client
    _speak_fn = speak_fn

    _state["running"] = True
    _state["paused"]  = False

    t = threading.Thread(target=_watch_loop, daemon=True, name="alfred.watcher")
    t.start()
    _state["thread"] = t
    print("[watcher] Started.")


def stop():
    """Stop the screen watcher."""
    _state["running"] = False
    print("[watcher] Stopping...")
