"""
config.py — Single source of truth for Alfred paths, directories, and env vars.

All other modules should import from here instead of calling os.environ directly
or constructing paths relative to __file__.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

# ── Application root ──────────────────────────────────────────────────────────
# All runtime data lives under ~/.alfred; the source tree is read-only from
# Alfred's perspective (no more db/log files scattered next to .py files).
APP_DIR = Path.home() / ".alfred"

# ── Sub-directories ───────────────────────────────────────────────────────────
LOG_DIR    = APP_DIR / "logs"
DB_DIR     = APP_DIR / "db"
VAULT_DIR  = APP_DIR / "vault"   # built-in Obsidian vault

# ── Config / secrets ─────────────────────────────────────────────────────────
ENV_FILE = APP_DIR / ".env"

# Load once, centrally. override=False so shell env always wins over .env file.
load_dotenv(ENV_FILE, override=False)

# ── Database files ────────────────────────────────────────────────────────────
MEMORY_DB       = DB_DIR / "memory.db"
MEMORY_GRAPH_DB = DB_DIR / "memory_graph.db"
ROLLBACK_DB     = DB_DIR / "rollback.db"
WATCH_DB        = DB_DIR / "watch_activity.db"

# ── IPC / inter-process files ─────────────────────────────────────────────────
SOCKET_PATH     = APP_DIR / "alfred.sock"
IPC_TRIGGER     = APP_DIR / "alfred_bar_trigger"
IPC_RESPONSE    = APP_DIR / "alfred_text_response.txt"
HUD_JSON        = APP_DIR / "alfred_hud.json"

# ── Log files ─────────────────────────────────────────────────────────────────
BACKEND_LOG   = LOG_DIR / "assistant.log"
LAUNCHER_LOG  = LOG_DIR / "launcher.log"
LAUNCHER_ERR  = LOG_DIR / "launcher.err"

# ── User filesystem conventions (macOS) ──────────────────────────────────────
# These are not Alfred data dirs — just well-known user locations.
SCREENSHOT_DIR = Path.home() / "Desktop"
PROJECTS_DIR   = Path.home() / "Documents"

# ── API keys ──────────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY  = os.environ.get("ANTHROPIC_API_KEY", "")
DEEPGRAM_API_KEY   = os.environ.get("DEEPGRAM_API_KEY", "")
BRAVE_API_KEY      = os.environ.get("BRAVE_API_KEY", "")
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
DEEPSEEK_API_KEY   = os.environ.get("DEEPSEEK_API_KEY", "")
KIMI_API_KEY       = os.environ.get("KIMI_API_KEY", "")
OPENAI_API_KEY     = os.environ.get("OPENAI_API_KEY", "")
OWNER_NAME         = os.environ.get("ALFRED_OWNER_NAME", "")

# ── Backend / model selection ─────────────────────────────────────────────────
ALFRED_BACKEND = os.environ.get("ALFRED_BACKEND", "anthropic").lower()
USE_OLLAMA     = os.environ.get("USE_OLLAMA", "0") == "1"

# Anthropic model tiers
MODEL              = "claude-sonnet-4-6"           # full reasoning
FAST_MODEL         = "claude-haiku-4-5-20251001"   # classification / cheap calls
VISION_MODEL       = "claude-haiku-4-5-20251001"
VISION_MODEL_DENSE = "claude-sonnet-4-6"           # charts, dense screenshots

# Alternative backends
OPENROUTER_MODEL = os.environ.get("OPENROUTER_MODEL", "deepseek/deepseek-chat-v3-0324:free")
OLLAMA_BASE_URL  = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL     = os.environ.get("OLLAMA_MODEL", "qwen2.5-coder:7b")
AMD_SGLANG_URL   = os.environ.get("AMD_SGLANG_URL", "")
AMD_SGLANG_KEY   = os.environ.get("AMD_SGLANG_KEY", "")
AMD_SGLANG_MODEL = os.environ.get("AMD_SGLANG_MODEL", "alfred-fast")


# ── Directory bootstrap ───────────────────────────────────────────────────────
def ensure_dirs() -> None:
    """Create all runtime directories that Alfred needs. Safe to call on every startup."""
    for d in (APP_DIR, LOG_DIR, DB_DIR, VAULT_DIR):
        d.mkdir(parents=True, exist_ok=True)
