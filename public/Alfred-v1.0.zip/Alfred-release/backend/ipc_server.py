"""
ipc_server.py — Unix domain socket IPC for the Alfred bar.

REPLACES: /tmp/alfred_trigger + /tmp/alfred_text_response.txt file polling.
The bar was polling every 500ms (~250ms average overhead), and Python wrote
the full response only after generation. With UDS streaming:
  - <1ms round-trip (vs 250ms file polling)
  - Tokens stream live as Claude generates them
  - Bidirectional: bar can send cancel signals, brain can push status events

PROTOCOL: length-prefixed JSON frames.
  [4 bytes big-endian length][JSON payload]

MESSAGE TYPES (Python → Swift):
  {"type": "delta",     "text": "..."}        — token chunk for streaming display
  {"type": "status",    "label": "thinking..."} — status indicator update
  {"type": "tool_call", "name": "...", "args": {...}} — tool invocation card
  {"type": "tool_done", "name": "...", "result": "..."} — tool result
  {"type": "done",      "final": "...", "usage": {...}} — generation complete
  {"type": "error",     "message": "..."}     — error to display

MESSAGE TYPES (Swift → Python):
  {"type": "query",     "text": "..."}        — user input
  {"type": "cancel"}                          — abort current generation
  {"type": "ping"}                            — keepalive
"""

import asyncio
import json
import os
import struct
import time
from pathlib import Path
from typing import Callable, Awaitable, Optional

from config import SOCKET_PATH


# ── Frame I/O ─────────────────────────────────────────────────────────────────

async def read_frame(reader: asyncio.StreamReader) -> Optional[dict]:
    """Read one length-prefixed JSON frame. Returns None on EOF."""
    try:
        header = await reader.readexactly(4)
    except (asyncio.IncompleteReadError, ConnectionError):
        return None
    n = struct.unpack(">I", header)[0]
    if n == 0 or n > 10_000_000:  # sanity: 10MB cap
        return None
    try:
        body = await reader.readexactly(n)
    except (asyncio.IncompleteReadError, ConnectionError):
        return None
    try:
        return json.loads(body.decode("utf-8"))
    except json.JSONDecodeError:
        return None


async def write_frame(writer: asyncio.StreamWriter, msg: dict) -> bool:
    """Write one length-prefixed JSON frame. Returns False on broken pipe."""
    try:
        data = json.dumps(msg, ensure_ascii=False).encode("utf-8")
        writer.write(struct.pack(">I", len(data)) + data)
        await writer.drain()
        return True
    except (ConnectionError, BrokenPipeError, OSError):
        return False


# ── Server ────────────────────────────────────────────────────────────────────

class IPCServer:
    """
    Async UDS server. Accepts one client at a time (the Swift bar).
    Routes incoming queries to a handler that yields response events.
    """

    def __init__(self, query_handler: Callable[[str, "Channel"], Awaitable[None]],
                 socket_path: str = SOCKET_PATH,
                 apply_handler: Optional[Callable] = None,
                 bg_status_handler: Optional[Callable] = None,
                 on_connect: Optional[Callable[["Channel"], Awaitable[None]]] = None):
        self.handler = query_handler
        self.apply_handler = apply_handler
        self.bg_status_handler = bg_status_handler
        self.on_connect = on_connect
        self.socket_path = socket_path
        self.server: Optional[asyncio.AbstractServer] = None
        self._client_writer: Optional[asyncio.StreamWriter] = None
        self._cancel_flag = False

    async def start(self):
        # Remove stale socket
        try:
            if os.path.exists(self.socket_path):
                os.unlink(self.socket_path)
        except OSError:
            pass

        self.server = await asyncio.start_unix_server(
            self._handle_client, path=self.socket_path
        )
        # Make socket world-readable (only the user runs both processes anyway)
        try:
            os.chmod(self.socket_path, 0o666)
        except OSError:
            pass
        print(f"[ipc] listening on {self.socket_path}")

    async def stop(self):
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        try:
            if os.path.exists(self.socket_path):
                os.unlink(self.socket_path)
        except OSError:
            pass

    async def _handle_client(self, reader: asyncio.StreamReader,
                             writer: asyncio.StreamWriter):
        peer = writer.get_extra_info("peername") or "<bar>"
        print(f"[ipc] client connected: {peer}")
        self._client_writer = writer
        channel = Channel(writer, self)

        if self.on_connect:
            try:
                await self.on_connect(channel)
            except Exception as e:
                print(f"[ipc] on_connect error: {e}")

        try:
            while True:
                msg = await read_frame(reader)
                if msg is None:
                    break
                msg_type = msg.get("type", "")
                if msg_type == "query":
                    text = (msg.get("text") or "").strip()
                    context = msg.get("context") or {}
                    attachments = msg.get("attachments") or []
                    if text:
                        self._cancel_flag = False
                        try:
                            await self.handler(text, channel, context, attachments)
                        except Exception as e:
                            await channel.error(f"Handler crashed: {e}")
                            import traceback; traceback.print_exc()
                elif msg_type == "cancel":
                    self._cancel_flag = True
                elif msg_type == "ping":
                    await write_frame(writer, {"type": "pong"})
                elif msg_type == "bg_status":
                    # Bar wants to know how many bg tasks are running/unread
                    if self.bg_status_handler:
                        try:
                            status = await self.bg_status_handler()
                            await write_frame(writer, {
                                "type": "bg_status_reply", **status,
                            })
                        except Exception as e:
                            print(f"[ipc] bg_status error: {e}")
                            await write_frame(writer, {"type": "bg_status_reply", "running": 0, "unread": 0, "tasks": []})
                elif msg_type == "apply_code":
                    # Paste a code block into the target app
                    code = msg.get("code") or ""
                    target_pid = msg.get("target_pid") or 0
                    target_app = msg.get("target_app") or ""
                    if code and self.apply_handler:
                        try:
                            await self.apply_handler(code, target_pid, target_app)
                        except Exception as e:
                            print(f"[ipc] apply_code handler error: {e}")
                elif msg_type == "history":
                    # Bar requesting conversation history for display
                    from assistant import conversation_history
                    # Send last 20 messages as simple text pairs
                    msgs = conversation_history[-20:]
                    pairs = []
                    for m in msgs:
                        if isinstance(m, dict) and m.get("role") in ("user", "assistant"):
                            pairs.append({
                                "role": m["role"],
                                "content": (m.get("content") or "")[:500]
                            })
                    await write_frame(writer, {"type": "history_reply", "messages": pairs})
                # ignore unknown messages
        finally:
            self._client_writer = None
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            print(f"[ipc] client disconnected")

    @property
    def cancelled(self) -> bool:
        return self._cancel_flag

    async def push_event(self, msg: dict) -> bool:
        """Push an unsolicited event to the bar (e.g. proactive nudge).
        No-op if bar isn't connected."""
        if self._client_writer is None:
            return False
        return await write_frame(self._client_writer, msg)


# ── Channel: the per-query response writer the brain uses ────────────────────

class Channel:
    """
    The brain writes response events through this. Wraps the StreamWriter
    so the brain doesn't need to know about framing or asyncio types.
    """

    def __init__(self, writer: asyncio.StreamWriter, server: "IPCServer"):
        self._w = writer
        self._server = server
        self._t0 = time.time()
        self._delta_count = 0

    @property
    def cancelled(self) -> bool:
        return self._server.cancelled

    @property
    def elapsed(self) -> float:
        return time.time() - self._t0

    async def status(self, label: str):
        await write_frame(self._w, {"type": "status", "label": label,
                                     "elapsed": round(self.elapsed, 2)})

    async def delta(self, text: str):
        self._delta_count += 1
        await write_frame(self._w, {"type": "delta", "text": text})

    async def tool_call(self, name: str, args: Optional[dict] = None):
        await write_frame(self._w, {"type": "tool_call", "name": name,
                                     "args": args or {}})

    async def tool_done(self, name: str, result: str = "", duration_s: float = 0.0):
        await write_frame(self._w, {
            "type": "tool_done", "name": name,
            "result": result[:500] if result else "",
            "duration": round(duration_s, 2)
        })

    async def done(self, final_text: str = "", usage: Optional[dict] = None,
                   model: str = ""):
        await write_frame(self._w, {
            "type": "done",
            "final": final_text,
            "usage": usage or {},
            "model": model,
            "elapsed": round(self.elapsed, 2),
        })

    async def error(self, message: str):
        await write_frame(self._w, {"type": "error", "message": message})

    async def info(self, message: str):
        """Non-streamed info line (for short, complete responses)."""
        await write_frame(self._w, {"type": "delta", "text": message})
        await self.done(final_text=message)

    async def followups(self, chips: list):
        """Send suggested next-action chips to display below the response.
        chips: list of {label, query} dicts."""
        await write_frame(self._w, {"type": "followups", "chips": chips})

    async def sources(self, urls: list):
        """Send the list of sources/URLs that were consulted for this answer."""
        await write_frame(self._w, {"type": "sources", "urls": urls})
