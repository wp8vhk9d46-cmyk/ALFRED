"""
proactive.py — Proactive context awareness for Alfred

Runs as a background thread, quietly watching what the user is doing.
Speaks up unprompted when something is genuinely worth surfacing.

WHAT IT WATCHES:
  - Frontmost app (what you're working in right now)
  - Upcoming calendar events (warns 10 min before)
  - Time of day (morning briefing at startup, end-of-day wrap)
  - Unread email count changes (new important mail arrived)
  - System state (low battery, disk space)

PRINCIPLES:
  - Never interrupt more than once every 5 minutes
  - Only speak if confidence the user would actually want to know
  - Stay silent during calls/screen sharing
  - Learn which app transitions the user cares about
  - Single short sentence, not a paragraph
"""

import os
import re
import subprocess
import threading
import time
from datetime import datetime, timedelta
from typing import Optional, Callable


# ── Config ────────────────────────────────────────────────────────────────────
CHECK_INTERVAL     = 30       # seconds between context checks
MIN_SPEAK_INTERVAL = 300      # minimum 5 min between proactive messages
MORNING_HOUR       = 9        # hour to deliver morning briefing (24h)
EVENING_HOUR       = 18       # hour to deliver end-of-day wrap
EVENT_WARN_MINS    = 10       # warn this many minutes before calendar events
BATTERY_WARN_PCT   = 15       # warn when battery drops below this

MEETING_NOTIFY_SECS = 90 * 60   # 90 minutes in a video call → notification
CODING_NOTIFY_SECS  = 2 * 3600  # 2 hours coding continuously → notification

# ── State ─────────────────────────────────────────────────────────────────────
_state = {
    "last_spoke":          0.0,       # timestamp of last proactive message
    "last_app":            "",        # frontmost app last check
    "warned_events":       set(),     # event titles already warned about
    "morning_done":        False,     # morning briefing delivered today
    "evening_done":        False,     # evening wrap delivered today
    "last_email_count":    -1,        # unread count last check
    "last_battery_warned": 0.0,       # timestamp of last battery warning
    "date_today":          "",        # track day rollovers
    "muted":               False,     # user said "be quiet" / in a call
    "busy":                False,     # user has an active query in flight
    "busy_until":          0.0,       # don't nudge until this timestamp
    "running":             False,
}


def set_busy(busy: bool):
    """Tell proactive to shut up while the user has an active query."""
    _state["busy"] = busy
    if not busy:
        # Add a 5s grace period after a query completes — let the user read
        _state["busy_until"] = time.time() + 5

_speak_fn:  Optional[Callable] = None
_client     = None
_thread:    Optional[threading.Thread] = None

# ── Duration tracking ─────────────────────────────────────────────────────────
# Maps a state label → unix timestamp when that state began.
# Labels: "meeting", "coding"
_state_start_times: dict = {}

# Tracks which duration notifications have already fired this state block,
# so we don't spam the user every cycle once the threshold is crossed.
_duration_notified: dict = {}   # label → bool


def _notify(title: str, body: str) -> None:
    """Fire a macOS system notification (non-blocking)."""
    try:
        subprocess.run(
            [
                "osascript", "-e",
                f'display notification "{body}" with title "{title}" sound name "Submarine"',
            ],
            capture_output=True,
            timeout=5,
        )
    except Exception as e:
        print(f"[proactive] notify failed: {e}")


# ── macOS helpers ─────────────────────────────────────────────────────────────

def _run(cmd: str, timeout: int = 5) -> str:
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True,
                           text=True, timeout=timeout)
        return r.stdout.strip()
    except Exception:
        return ""


def get_frontmost_app() -> str:
    return _run(
        'osascript -e "tell application \\"System Events\\" to get name of first process whose frontmost is true"'
    )


def get_upcoming_events(within_minutes: int = 15) -> list[dict]:
    script = f'''tell application "Calendar"
    set now to current date
    set soon to now + {within_minutes * 60}
    set output to ""
    repeat with cal in calendars
        set evts to (every event of cal whose start date >= now and start date <= soon)
        repeat with e in evts
            set output to output & (summary of e) & "|" & (start date of e as string) & return
        end repeat
    end repeat
    return output
end tell'''
    try:
        r = subprocess.run(["osascript", "-e", script],
                           capture_output=True, text=True, timeout=8)
        out = r.stdout.strip()
        if not out:
            return []
        events = []
        for line in out.splitlines():
            if "|" in line:
                parts = line.split("|", 1)
                events.append({"title": parts[0].strip(), "time": parts[1].strip()})
        return events
    except Exception:
        return []


def get_unread_email_count() -> int:
    script = 'tell application "Mail" to return count (messages of inbox whose read status is false)'
    try:
        r = subprocess.run(["osascript", "-e", script],
                           capture_output=True, text=True, timeout=5)
        return int(r.stdout.strip())
    except Exception:
        return -1


def get_battery_percent() -> int:
    out = _run("pmset -g batt | grep -o '[0-9]*%' | head -1")
    try:
        return int(out.replace("%", ""))
    except Exception:
        return 100


def is_screen_sharing() -> bool:
    out = _run('osascript -e "tell application \\"System Events\\" to get name of every process"')
    return any(app in out for app in ["zoom.us", "Zoom", "Teams", "Meet", "Webex", "FaceTime"])


def get_app_context(app: str) -> str:
    """Return a short description of what the user is likely doing."""
    contexts = {
        "Xcode":          "coding",
        "Visual Studio Code": "coding",
        "PyCharm":        "coding",
        "Terminal":       "terminal work",
        "Safari":         "browsing",
        "Google Chrome":  "browsing",
        "Firefox":        "browsing",
        "Mail":           "reading email",
        "Messages":       "messaging",
        "Slack":          "messaging",
        "Discord":        "messaging",
        "Notion":         "writing/notes",
        "Obsidian":       "writing/notes",
        "Word":           "writing",
        "Pages":          "writing",
        "Figma":          "designing",
        "Sketch":         "designing",
        "Finder":         "managing files",
        "Calendar":       "checking schedule",
        "Spotify":        "listening to music",
        "zoom.us":        "on a call",
        "FaceTime":       "on a call",
        "Teams":          "on a call",
    }
    return contexts.get(app, "")


# ── Proactive triggers ────────────────────────────────────────────────────────

def _can_speak() -> bool:
    """Check if enough time has passed and we're not in a call."""
    if _state["muted"]:
        return False
    if _state.get("busy"):
        return False
    if time.time() < _state.get("busy_until", 0):
        return False
    if is_screen_sharing():
        return False
    return time.time() - _state["last_spoke"] >= MIN_SPEAK_INTERVAL


def _speak(message: str):
    """Deliver a proactive message."""
    if not _speak_fn or not message:
        return
    _state["last_spoke"] = time.time()
    print(f"[proactive] → {message}")
    _speak_fn(message)


def _is_meeting_app(app: str) -> bool:
    """Return True if the frontmost app is a video-call application."""
    return app in {"zoom.us", "Zoom", "Teams", "Meet", "Google Meet", "Webex", "FaceTime"}


def _is_coding_app(app: str) -> bool:
    """Return True if the frontmost app is a code editor."""
    return app in {"Xcode", "Visual Studio Code", "PyCharm", "IntelliJ IDEA",
                   "Android Studio", "Sublime Text", "Emacs", "vim", "nvim",
                   "Cursor", "Zed"}


def _update_state_start(label: str, active: bool) -> None:
    """Record when a state begins or ends."""
    if active:
        if label not in _state_start_times:
            _state_start_times[label] = time.time()
            _duration_notified[label] = False
    else:
        _state_start_times.pop(label, None)
        _duration_notified[label] = False


def check_duration_notifications():
    """Fire macOS notifications when the user has been in a long state."""
    current_app = get_frontmost_app() or ""

    in_meeting = _is_meeting_app(current_app)
    in_coding  = _is_coding_app(current_app)

    _update_state_start("meeting", in_meeting)
    _update_state_start("coding",  in_coding)

    now = time.time()

    # Meeting duration check
    if in_meeting and not _duration_notified.get("meeting", False):
        started = _state_start_times.get("meeting", now)
        elapsed = now - started
        if elapsed >= MEETING_NOTIFY_SECS:
            mins = int(elapsed / 60)
            _notify("Alfred", f"You've been in a meeting {mins} min. Want a summary?")
            _duration_notified["meeting"] = True
            print(f"[proactive] meeting duration notification fired ({mins}m)")

    # Coding focus block check
    if in_coding and not _duration_notified.get("coding", False):
        started = _state_start_times.get("coding", now)
        elapsed = now - started
        if elapsed >= CODING_NOTIFY_SECS:
            hrs = int(elapsed / 3600)
            _notify("Alfred", f"{hrs}hr focus block. Time for a break?")
            _duration_notified["coding"] = True
            print(f"[proactive] coding duration notification fired ({hrs}h)")


def check_calendar_events():
    """Warn about upcoming events."""
    if not _can_speak():
        return
    events = get_upcoming_events(within_minutes=EVENT_WARN_MINS)
    for event in events:
        title = event["title"]
        if title in _state["warned_events"]:
            continue
        _state["warned_events"].add(title)
        # Calculate minutes until event
        try:
            # Parse the time string - AppleScript returns locale-specific format
            event_time = event["time"]
            _speak(f"Heads up — {title} in about {EVENT_WARN_MINS} minutes.")
            return  # one at a time
        except Exception:
            _speak(f"Heads up — {title} is coming up soon.")
            return


_meeting_prep_fired: set = set()

def check_meeting_prep():
    """Fire a notification 30 min before any calendar event (once per event)."""
    try:
        script = """
tell application "Calendar"
    set now to current date
    set t1 to now + (25 * minutes)
    set t2 to now + (35 * minutes)
    set hits to {}
    repeat with cal in calendars
        repeat with ev in (every event of cal whose start date >= t1 and start date <= t2)
            set end of hits to (summary of ev) & "|" & ((start date of ev) as string)
        end repeat
    end repeat
    return hits
end tell
"""
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=5
        )
        raw = result.stdout.strip()
        if not raw:
            return
        for item in raw.split(", "):
            item = item.strip()
            if "|" not in item:
                continue
            title, start_str = item.split("|", 1)
            key = f"{title.strip()}|{start_str.strip()}"
            if key in _meeting_prep_fired:
                continue
            _meeting_prep_fired.add(key)
            _notify("📅 Meeting in 30 min", f"{title.strip()} — tap Alfred to prepare")
    except Exception as e:
        pass  # Calendar not available or script error


def check_morning_briefing():
    """Deliver morning briefing once per day at MORNING_HOUR."""
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")

    # Reset daily flags on new day
    if _state["date_today"] != today:
        _state["date_today"]   = today
        _state["morning_done"] = False
        _state["evening_done"] = False
        _state["warned_events"].clear()

    if _state["morning_done"]:
        return
    if now.hour != MORNING_HOUR:
        return
    if not _can_speak():
        return

    _state["morning_done"] = True

    if _client:
        try:
            from multi_agent import morning_briefing
            briefing = morning_briefing(_client)
            if briefing:
                _speak(briefing[:600])
                return
        except ImportError:
            pass
    _speak("Good morning. Say 'morning briefing' for your daily rundown.")


def check_app_switch():
    """Notice when user switches to a relevant app and surface context."""
    if not _can_speak():
        return

    current_app = get_frontmost_app()
    if not current_app or current_app == _state["last_app"]:
        return

    prev_app = _state["last_app"]
    _state["last_app"] = current_app

    # Don't comment on every switch — only meaningful transitions
    context = get_app_context(current_app)
    if not context:
        return

    # Opening email — check for important unread
    if current_app == "Mail" and _client:
        count = get_unread_email_count()
        if count > 0 and count != _state["last_email_count"]:
            _state["last_email_count"] = count
            if count >= 5:
                _speak(f"You've got {count} unread emails. Want a briefing?")
            return

    # Opening calendar — mention next event
    if current_app == "Calendar":
        events = get_upcoming_events(within_minutes=60 * 8)  # today's events
        if events:
            next_event = events[0]
            _speak(f"Next up: {next_event['title']}.")
        return

    # Switching to code editor — remind of upcoming meeting if within 30 min
    if context == "coding":
        events = get_upcoming_events(within_minutes=30)
        if events:
            title = events[0]["title"]
            if title not in _state["warned_events"]:
                _speak(f"Just so you know, {title} is in under 30 minutes.")
        return


def check_new_email():
    """Detect when important new email arrives."""
    if not _can_speak() or not _client:
        return

    count = get_unread_email_count()
    if count < 0:
        return

    prev = _state["last_email_count"]
    _state["last_email_count"] = count

    # Skip first check (establishing baseline)
    if prev < 0:
        return

    # New emails arrived
    new_count = count - prev
    if new_count <= 0:
        return

    # Only speak up if significant or user is idle (not actively typing)
    current_app = get_frontmost_app()
    if current_app in ["Mail"]:
        return  # they're already in mail

    if new_count >= 3:
        _speak(f"{new_count} new emails just arrived.")
    elif new_count == 1:
        # Fetch the email and check if it looks important
        try:
            from email_agent import get_unread_emails
            emails = get_unread_emails(limit=1)
            if emails:
                e = emails[0]
                subject = e.get("subject", "")
                sender  = e.get("from", "")
                # Simple importance heuristic
                important_words = ["urgent", "asap", "important", "invoice",
                                   "deadline", "action required", "reminder"]
                if any(w in subject.lower() for w in important_words):
                    _speak(f"New email from {sender.split('<')[0].strip()}: {subject}")
        except Exception:
            pass


def check_battery():
    """Warn about low battery."""
    if not _can_speak():
        return
    # Don't warn more than once per hour
    if time.time() - _state["last_battery_warned"] < 3600:
        return

    pct = get_battery_percent()
    if pct <= BATTERY_WARN_PCT:
        _state["last_battery_warned"] = time.time()
        _speak(f"Battery at {pct}%. Might want to plug in.")


def check_evening_wrap():
    """End of day summary."""
    now = datetime.now()
    if _state["evening_done"]:
        return
    if now.hour != EVENING_HOUR:
        return
    if not _can_speak():
        return

    _state["evening_done"] = True
    _speak("Wrapping up for the day. Say 'catch me up' if you want a quick summary before you finish.")


# ── Main loop ─────────────────────────────────────────────────────────────────

def _is_screen_locked() -> bool:
    """Return True if the screensaver is on or screen is locked. ~5ms."""
    try:
        # CGSSessionScreenIsLocked is the canonical check on macOS
        import subprocess
        r = subprocess.run(
            ["python3", "-c",
             "from Quartz import CGSessionCopyCurrentDictionary; "
             "d = CGSessionCopyCurrentDictionary(); "
             "print(d.get('CGSSessionScreenIsLocked', 0) if d else 0)"],
            capture_output=True, text=True, timeout=1
        )
        return r.stdout.strip() == "1"
    except Exception:
        return False


def _context_loop():
    """Background thread — runs checks every CHECK_INTERVAL seconds.

    Heavily gated to control cost. Skips entirely when:
      - Screen is locked (no user to nudge)
      - Frontmost app + window title haven't changed AND we've checked
        recently (avoids redundant calendar/email polls)
      - The user has an active query in flight (set_busy(True))
    """
    print("[proactive] Context awareness started.")
    # Stagger initial checks so we don't hammer everything at once
    time.sleep(10)

    check_counter = 0
    last_app_signature = ""
    skipped_in_a_row = 0

    while _state["running"]:
        try:
            # Gate 1: skip if user has an active query in flight
            if _state.get("busy") or time.time() < _state.get("busy_until", 0):
                time.sleep(CHECK_INTERVAL)
                continue

            # Gate 2: skip if screen locked
            if _is_screen_locked():
                time.sleep(CHECK_INTERVAL)
                continue

            # Gate 3: skip if nothing has changed AND we've already checked
            # this state recently. Lets the high-frequency checks throttle
            # themselves naturally when the user is idle.
            current_app = get_frontmost_app() or ""
            app_sig = current_app
            unchanged = (app_sig == last_app_signature)
            if unchanged and skipped_in_a_row < 4:
                # Skip 4 consecutive cycles (~2 minutes idle), then resume
                # at half cadence so we still catch calendar/battery events.
                skipped_in_a_row += 1
                time.sleep(CHECK_INTERVAL)
                continue
            last_app_signature = app_sig
            skipped_in_a_row = 0

            check_counter += 1

            # Every cycle: app switch, calendar events, duration tracking
            check_app_switch()
            check_calendar_events()
            check_duration_notifications()

            # Every 2 cycles (~1 min): new email + meeting prep
            if check_counter % 2 == 0:
                check_new_email()
                check_meeting_prep()

            # Every 4 cycles (~2 min): battery
            if check_counter % 4 == 0:
                check_battery()

            # Every 6 cycles (~3 min): time-based checks
            if check_counter % 6 == 0:
                check_morning_briefing()
                check_evening_wrap()

        except Exception as e:
            print(f"[proactive] Error in context loop: {e}")

        time.sleep(CHECK_INTERVAL)


# ── Public API ────────────────────────────────────────────────────────────────

def start(speak_fn: Callable, client, muted: bool = False):
    """Start the proactive context awareness background thread."""
    global _speak_fn, _client, _thread
    _speak_fn        = speak_fn
    _client          = client
    _state["muted"]  = muted
    _state["running"] = True
    _state["last_email_count"] = get_unread_email_count()  # baseline
    _state["last_app"] = get_frontmost_app()               # baseline

    _thread = threading.Thread(target=_context_loop, daemon=True)
    _thread.start()
    print("[proactive] Started.")


def stop():
    """Stop the background thread."""
    _state["running"] = False
    print("[proactive] Stopped.")


def mute(duration_minutes: int = 30):
    """Silence proactive messages for a while."""
    _state["muted"] = True
    def _unmute():
        time.sleep(duration_minutes * 60)
        _state["muted"] = False
        print("[proactive] Unmuted.")
    threading.Thread(target=_unmute, daemon=True).start()
    return f"I'll stay quiet for {duration_minutes} minutes."


def unmute():
    _state["muted"] = False
    return "Back to normal."


def set_min_interval(seconds: int):
    """How often proactive messages can fire."""
    global MIN_SPEAK_INTERVAL
    MIN_SPEAK_INTERVAL = seconds
