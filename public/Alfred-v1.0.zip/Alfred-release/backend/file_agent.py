"""
file_agent.py — Find, read, and create files on the user's Mac.

Public API:
    find_files(query, limit=20) -> list[dict]
        Find files by name/type/recency across standard user locations.

    read_file(path) -> dict {ok, text, kind, error}
        Read text from PDF, DOCX, TXT, MD, CSV, JSON, XLSX.
        Auto-detects format from extension.

    write_xlsx(path, rows, sheet_name="Sheet1") -> dict {ok, path, error}
        Write rows of data to an Excel file.

    write_csv(path, rows) -> dict {ok, path, error}
        Write rows of data to a CSV file.

    open_file(path) -> bool
        Open a file in its default app.

Designed to be safe (read-only file search, never deletes), fast (caches
import attempts), and graceful (returns ok=False with error message on
any failure rather than throwing).
"""
from __future__ import annotations
import os
import re
import csv
import json
import time
import glob
import subprocess
from pathlib import Path
from typing import Optional


# Search roots — standard user locations
HOME = Path.home()
DEFAULT_ROOTS = [
    HOME / "Downloads",
    HOME / "Documents",
    HOME / "Desktop",
]

# Extension → kind mapping
EXT_KIND = {
    ".pdf":  "pdf",
    ".docx": "docx", ".doc": "doc",
    ".xlsx": "xlsx", ".xls": "xls",
    ".csv":  "csv",
    ".txt":  "text", ".md": "markdown",
    ".json": "json",
    ".py":   "code", ".js": "code", ".ts": "code", ".html": "code",
    ".rtf":  "rtf",
    ".png":  "image", ".jpg": "image", ".jpeg": "image", ".gif": "image",
    ".mp4":  "video", ".mov": "video", ".m4v": "video",
    ".mp3":  "audio", ".wav": "audio", ".m4a": "audio",
    ".zip":  "archive",
}


# ── Find ──────────────────────────────────────────────────────────────────────

def find_files(query: str = "", limit: int = 20,
               kind: Optional[str] = None,
               since_days: Optional[int] = None,
               roots: Optional[list[Path]] = None) -> list[dict]:
    """
    Find files matching `query` (substring of filename, case-insensitive).
    Returns list of dicts: {path, name, kind, size, mtime, mtime_str}.

    Args:
        query: substring to match in filename (e.g. "tax 2024", "resume")
        limit: max results
        kind: optional filter by file kind ("pdf", "docx", "xlsx", etc.)
        since_days: optional, only return files modified within N days
        roots: search roots; defaults to Downloads/Documents/Desktop
    """
    if roots is None:
        roots = DEFAULT_ROOTS
    q = (query or "").lower().strip()

    # Strip common stop words from the query that don't help match filenames
    stop_words = {"the", "a", "an", "in", "my", "to", "of", "and", "is",
                  "this", "that", "file", "files", "doc", "document"}
    q_tokens = [t for t in re.split(r"\W+", q) if t and t not in stop_words]

    cutoff = None
    if since_days:
        cutoff = time.time() - since_days * 86400

    results = []
    for root in roots:
        if not root.exists():
            continue
        try:
            for dirpath, dirnames, filenames in os.walk(root):
                # Skip hidden dirs and Trash, node_modules, etc.
                dirnames[:] = [d for d in dirnames
                               if not d.startswith(".")
                               and d not in {"node_modules", "__pycache__",
                                             ".Trash", "Library"}]
                for fn in filenames:
                    if fn.startswith("."):
                        continue
                    fpath = Path(dirpath) / fn
                    try:
                        stat = fpath.stat()
                    except OSError:
                        continue
                    if cutoff and stat.st_mtime < cutoff:
                        continue
                    ext = fpath.suffix.lower()
                    file_kind = EXT_KIND.get(ext, "other")
                    if kind and file_kind != kind:
                        continue
                    name_low = fn.lower()
                    # Match: all query tokens must appear in filename
                    if q_tokens and not all(t in name_low for t in q_tokens):
                        continue
                    results.append({
                        "path": str(fpath),
                        "name": fn,
                        "kind": file_kind,
                        "ext":  ext,
                        "size": stat.st_size,
                        "mtime": stat.st_mtime,
                        "mtime_str": time.strftime(
                            "%Y-%m-%d %H:%M",
                            time.localtime(stat.st_mtime),
                        ),
                    })
        except Exception as e:
            print(f"[file_agent] walk error in {root}: {e}")

    # Sort by mtime desc (most recent first), then by name length
    results.sort(key=lambda r: (-r["mtime"], len(r["name"])))
    return results[:limit]


# ── Read ──────────────────────────────────────────────────────────────────────

def read_file(path: str, max_chars: int = 200_000) -> dict:
    """
    Read text from a file. Returns {ok, text, kind, path, error}.
    Supports: pdf, docx, txt, md, json, csv, xlsx, code files, html.
    """
    if not os.path.isfile(path):
        return {"ok": False, "text": "", "kind": "", "path": path,
                "error": "File not found"}

    ext = os.path.splitext(path)[1].lower()
    kind = EXT_KIND.get(ext, "other")

    try:
        if kind == "pdf":
            text = _read_pdf(path)
        elif kind == "docx":
            text = _read_docx(path)
        elif kind == "xlsx":
            text = _read_xlsx(path)
        elif kind == "csv":
            text = _read_csv(path)
        elif kind in ("text", "markdown", "json", "code"):
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        elif ext == ".html":
            text = _read_html(path)
        else:
            return {"ok": False, "text": "", "kind": kind, "path": path,
                    "error": f"Cannot read files of type {ext}"}

        if len(text) > max_chars:
            text = text[:max_chars] + f"\n\n[... truncated, file is {len(text):,} chars total ...]"

        return {"ok": True, "text": text, "kind": kind, "path": path,
                "error": ""}

    except ImportError as e:
        return {"ok": False, "text": "", "kind": kind, "path": path,
                "error": f"Missing dependency: {e}. Install with pip3 "
                         f"install pypdf python-docx openpyxl --break-system-packages"}
    except Exception as e:
        return {"ok": False, "text": "", "kind": kind, "path": path,
                "error": f"Read failed: {e}"}


def _read_pdf(path: str) -> str:
    """Extract text from PDF using pypdf."""
    from pypdf import PdfReader
    reader = PdfReader(path)
    parts = []
    for i, page in enumerate(reader.pages):
        try:
            t = page.extract_text() or ""
        except Exception:
            t = ""
        if t.strip():
            parts.append(f"--- Page {i+1} ---\n{t}")
    return "\n\n".join(parts) if parts else "[PDF appears to have no extractable text]"


def _read_docx(path: str) -> str:
    """Extract text from a .docx using python-docx."""
    import docx
    doc = docx.Document(path)
    parts = []
    for para in doc.paragraphs:
        if para.text.strip():
            parts.append(para.text)
    # Also pull text from tables
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(c.text.strip() for c in row.cells)
            if row_text.strip():
                parts.append(row_text)
    return "\n".join(parts)


def _read_xlsx(path: str) -> str:
    """Read xlsx as plain text — sheet name + tab-separated rows."""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    parts = []
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        parts.append(f"=== Sheet: {sheet_name} ===")
        for row in ws.iter_rows(values_only=True):
            cells = [str(c) if c is not None else "" for c in row]
            if any(cells):
                parts.append("\t".join(cells))
    return "\n".join(parts)


def _read_csv(path: str) -> str:
    """Read CSV as plain text."""
    parts = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        for row in reader:
            parts.append("\t".join(row))
    return "\n".join(parts)


def _read_html(path: str) -> str:
    """Extract visible text from HTML."""
    try:
        from bs4 import BeautifulSoup
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            soup = BeautifulSoup(f.read(), "html.parser")
        # Strip script/style
        for s in soup(["script", "style"]):
            s.decompose()
        return soup.get_text(separator="\n", strip=True)
    except ImportError:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()


# ── Write ─────────────────────────────────────────────────────────────────────

def write_xlsx(path: str, rows: list, sheet_name: str = "Sheet1") -> dict:
    """
    Write rows to an .xlsx file. `rows` is a list of lists (row of cells).
    First row is treated as headers and bolded.
    Returns {ok, path, error}.
    """
    if not path.endswith(".xlsx"):
        path = path + ".xlsx"
    # Resolve to absolute Downloads path if user gave a bare filename
    if not os.path.isabs(path):
        path = str(HOME / "Downloads" / os.path.basename(path))

    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = sheet_name[:31]  # Excel sheet name limit

        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                cell = ws.cell(row=i+1, column=j+1, value=val)
                if i == 0:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill("solid", fgColor="E8E8E8")

        # Auto-width columns (estimate)
        if rows:
            for j in range(len(rows[0])):
                col_letter = openpyxl.utils.get_column_letter(j + 1)
                max_len = max(
                    (len(str(row[j])) for row in rows if j < len(row)),
                    default=10,
                )
                ws.column_dimensions[col_letter].width = min(max_len + 2, 50)

        # Make sure parent dir exists
        os.makedirs(os.path.dirname(path), exist_ok=True)
        wb.save(path)
        return {"ok": True, "path": path, "error": ""}

    except ImportError:
        return {"ok": False, "path": "", "error":
                "openpyxl not installed. Run: pip3 install openpyxl --break-system-packages"}
    except Exception as e:
        return {"ok": False, "path": "", "error": f"Write failed: {e}"}


def write_csv(path: str, rows: list) -> dict:
    """Write rows to a CSV. Returns {ok, path, error}."""
    if not path.endswith(".csv"):
        path = path + ".csv"
    if not os.path.isabs(path):
        path = str(HOME / "Downloads" / os.path.basename(path))
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            for row in rows:
                w.writerow(row)
        return {"ok": True, "path": path, "error": ""}
    except Exception as e:
        return {"ok": False, "path": "", "error": f"Write failed: {e}"}


# ── Open ──────────────────────────────────────────────────────────────────────

def open_file(path: str) -> bool:
    """Open a file in its default macOS app."""
    if not os.path.exists(path):
        return False
    try:
        subprocess.run(["open", path], capture_output=True, timeout=3)
        return True
    except Exception:
        return False


# ── Helpers for query parsing ────────────────────────────────────────────────

def looks_like_file_query(text: str) -> bool:
    """Quick heuristic: does this query reference a file or folder?"""
    t = text.lower()
    triggers = [
        " in my downloads", " in downloads", " in my documents",
        " in documents", " in desktop", " in my desktop",
        "find the", "find a ", "find my", "find file",
        "open the", "open file",
        "the pdf", "a pdf", "the docx", "the doc ", "the spreadsheet",
        "the xlsx", "the csv ", "this pdf", "this doc", "this file",
        "make a spreadsheet", "create a spreadsheet", "save as xlsx",
        "save as csv", "make a csv", "export to excel", "export to csv",
    ]
    return any(t.startswith(s.strip()) or s in t for s in triggers)
