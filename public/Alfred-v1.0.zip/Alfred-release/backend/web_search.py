"""
web_search.py — Real agentic web search for Alfred

Replaces the fake handle_web_research that just asked Claude what it knew.

HOW IT WORKS:
  1. Search  — DuckDuckGo (no API key needed) or Brave Search (optional, better)
  2. Fetch   — Download and extract readable text from result pages
  3. Reason  — Claude reads the content and decides if more browsing is needed
  4. Synthesize — Return a grounded answer with sources

AGENTIC MODE (triggered by "find", "browse", "research"):
  The agent can chain up to MAX_STEPS search+fetch cycles, following its own
  reasoning — e.g. search → find a promising page → fetch it → realize it needs
  more detail → search again with refined query → synthesize final answer.

OPTIONAL: Set BRAVE_API_KEY env var for better search results.
  Get a free key (2000 queries/month) at https://api.search.brave.com
"""

import re
import json
import time
import urllib.request
import urllib.parse
import urllib.error
import html
from typing import Optional

from config import BRAVE_API_KEY
MAX_STEPS     = 4      # max search+fetch cycles in agentic mode
MAX_PAGE_CHARS = 6000  # truncate fetched pages to save tokens
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


# ── Search backends ───────────────────────────────────────────────────────────

def _ddg_instant_answer(query: str) -> Optional[str]:
    """
    DuckDuckGo Instant Answer API — returns a direct fact when available.
    Faster than searching + synthesizing because no Claude call is needed.
    Returns None if no instant answer exists for this query.
    """
    url = (f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}"
           f"&format=json&no_html=1&skip_disambig=1")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode())
        # Try fields in order of usefulness
        for key in ("Answer", "AbstractText", "Definition"):
            v = data.get(key)
            if v and 5 < len(v) < 600:
                # Tack on the source if abstract source is set
                src = data.get("AbstractSource") or "DuckDuckGo"
                return f"{v} (Source: {src})"
        return None
    except Exception:
        return None


def _search_brave(query: str, num: int = 5) -> list[dict]:
    """Brave Search API — better quality, needs free API key."""
    url = f"https://api.search.brave.com/res/v1/web/search?q={urllib.parse.quote(query)}&count={num}"
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "X-Subscription-Token": BRAVE_API_KEY,
    })
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())
        results = []
        for r in data.get("web", {}).get("results", [])[:num]:
            results.append({
                "title":   r.get("title", ""),
                "url":     r.get("url", ""),
                "snippet": r.get("description", ""),
            })
        return results
    except Exception as e:
        print(f"[search] Brave failed: {e}")
        return []


def _search_duckduckgo(query: str, num: int = 5) -> list[dict]:
    """DuckDuckGo HTML scrape — no API key needed, always available."""
    url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept-Language": "en-US,en;q=0.9",
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", errors="replace")

        results = []
        # Parse result blocks from DDG HTML
        blocks = re.findall(
            r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>.*?'
            r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
            body, re.DOTALL
        )
        for href, title_html, snippet_html in blocks[:num]:
            # DDG uses redirect URLs — extract the real URL
            real_url = href
            uddg_match = re.search(r"uddg=([^&]+)", href)
            if uddg_match:
                real_url = urllib.parse.unquote(uddg_match.group(1))
            title   = html.unescape(re.sub(r"<[^>]+>", "", title_html)).strip()
            snippet = html.unescape(re.sub(r"<[^>]+>", "", snippet_html)).strip()
            if real_url and title:
                results.append({"title": title, "url": real_url, "snippet": snippet})

        return results
    except Exception as e:
        print(f"[search] DDG failed: {e}")
        return []


def search(query: str, num: int = 5) -> list[dict]:
    """Search the web. Uses Brave if API key set, otherwise DuckDuckGo."""
    print(f"[search] '{query}'")
    if BRAVE_API_KEY:
        results = _search_brave(query, num)
        if results:
            return results
    return _search_duckduckgo(query, num)


# ── Page fetcher ──────────────────────────────────────────────────────────────

def fetch_page(url: str, max_chars: int = MAX_PAGE_CHARS) -> str:
    """Fetch a URL and return clean readable text."""
    print(f"[fetch] {url[:80]}")
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "en-US,en;q=0.9",
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            # Only process HTML
            content_type = resp.headers.get("Content-Type", "")
            if "html" not in content_type and "text" not in content_type:
                return ""
            raw = resp.read(500_000).decode("utf-8", errors="replace")

        # Strip scripts, styles, nav boilerplate
        raw = re.sub(r"<script[^>]*>.*?</script>", " ", raw, flags=re.DOTALL | re.IGNORECASE)
        raw = re.sub(r"<style[^>]*>.*?</style>",  " ", raw, flags=re.DOTALL | re.IGNORECASE)
        raw = re.sub(r"<nav[^>]*>.*?</nav>",       " ", raw, flags=re.DOTALL | re.IGNORECASE)
        raw = re.sub(r"<footer[^>]*>.*?</footer>", " ", raw, flags=re.DOTALL | re.IGNORECASE)
        raw = re.sub(r"<header[^>]*>.*?</header>", " ", raw, flags=re.DOTALL | re.IGNORECASE)
        # Strip remaining tags
        text = re.sub(r"<[^>]+>", " ", raw)
        # Clean whitespace
        text = html.unescape(text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:max_chars]

    except Exception as e:
        print(f"[fetch] Error: {e}")
        return ""


def format_results_for_prompt(results: list[dict]) -> str:
    lines = []
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['title']}\n   URL: {r['url']}\n   {r['snippet']}")
    return "\n\n".join(lines)


# ── Single-shot search (quick answer) ────────────────────────────────────────

def quick_search(query: str, client) -> str:
    """
    Fast path: search → top snippets → Claude synthesizes a SHORT answer.
    No page fetching. Good for simple factual questions.
    """
    # In-memory cache check (5-minute TTL)
    cached = _cache_get(query)
    if cached:
        print(f"[search] cache hit")
        return cached

    # Even faster path: DDG Instant Answer (returns a direct fact, no Claude needed)
    ia = _ddg_instant_answer(query)
    if ia:
        print(f"[search] DDG instant answer hit")
        _cache_put(query, ia)
        return ia

    results = search(query, num=5)
    if not results:
        return f"Couldn't find anything for '{query}'."

    prompt = (
        f"Q: {query}\n\n"
        f"Search results:\n{format_results_for_prompt(results)}\n\n"
        "Answer in 1-2 SHORT sentences. Plain text only — NO markdown, NO headers, "
        "NO bullets, NO emojis. Lead with the direct fact (number, name, date). "
        "If the results don't contain the answer, say so in one sentence. "
        "The user is HEARING this, not reading it."
    )
    try:
        resp = client.messages.create(
            model="claude-haiku-4-5-20251001",   # use Haiku — 3x faster for short answers
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}]
        )
        answer = resp.content[0].text.strip()
        # Single source line, no bullets
        top_source = results[0]
        full = f"{answer} (Source: {top_source['url']})"
        _cache_put(query, full)
        return full
    except Exception as e:
        return f"Search error: {e}"


# ── Tiny query cache (5 min TTL) ─────────────────────────────────────────────
import time as _time
_search_cache: dict[str, tuple[float, str]] = {}
_CACHE_TTL = 300  # 5 minutes

def _cache_get(query: str) -> Optional[str]:
    key = query.lower().strip()
    if key in _search_cache:
        ts, value = _search_cache[key]
        if _time.time() - ts < _CACHE_TTL:
            return value
        del _search_cache[key]
    return None

def _cache_put(query: str, value: str):
    key = query.lower().strip()
    _search_cache[key] = (_time.time(), value)
    # Cap size at 50 entries
    if len(_search_cache) > 50:
        oldest_key = min(_search_cache, key=lambda k: _search_cache[k][0])
        del _search_cache[oldest_key]


# ── Agentic search (multi-step browsing) ─────────────────────────────────────

AGENT_SYSTEM = """You are a research agent. You have two tools: search and fetch_page.

Decide what to do next:
- Search: {"action": "search", "query": "your query"}
- Read a page: {"action": "fetch", "url": "https://..."}
- Done: {"action": "done", "answer": "1-2 sentence answer in plain text, NO markdown"}

Rules:
- Today's date is {today}. ALWAYS reflect this in search queries — say "{today_year}" when looking up "latest" or "current" anything. Don't assume older dates.
- Be specific with searches — refine if results aren't useful
- Only fetch pages that look genuinely relevant
- The final answer must be 1-2 SHORT sentences, plain text, no markdown/bullets/headers
- Lead with the direct fact (number, name, date) the user asked for
- For live data (weather, prices, scores), fetch the actual page — don't trust snippets
- Respond with ONLY valid JSON, nothing else"""


def agentic_search(goal: str, client, status_cb=None) -> tuple:
    """
    Multi-step agentic search. The model decides whether to search,
    fetch pages, or synthesize — up to MAX_STEPS iterations.

    Returns (answer, sources) where sources is a list of URLs consulted.

    `status_cb` is an optional sync callable(message: str) called at each
    step transition so the caller can push live progress to the user.
    """
    print(f"[agent] Goal: {goal}")
    from datetime import date
    today = date.today()
    today_str = today.strftime("%B %d, %Y")
    system_prompt = (AGENT_SYSTEM
                     .replace("{today}", today_str)
                     .replace("{today_year}", str(today.year)))
    messages = [{
        "role": "user",
        "content": f"Research goal: {goal}\n\n(Today is {today_str}.) Start by deciding what to search for."
    }]
    steps_taken = []
    sources_consulted = []

    def _emit(msg: str):
        if status_cb:
            try: status_cb(msg)
            except Exception: pass

    _emit("planning research...")

    for step in range(MAX_STEPS):
        try:
            resp = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=600,
                system=system_prompt,
                messages=messages
            )
            raw = resp.content[0].text.strip()
            # Strip markdown fences if present
            raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.MULTILINE).strip()

            try:
                action = json.loads(raw)
            except json.JSONDecodeError:
                # Model gave a text answer instead of JSON — treat as done
                return raw, sources_consulted

            act = action.get("action", "done")
            print(f"[agent] Step {step+1}: {act}")

            if act == "search":
                query   = action.get("query", goal)
                _emit(f"searching: {query[:50]}")
                results = search(query)
                steps_taken.append(f"Searched: {query}")
                tool_result = f"Search results for '{query}':\n{format_results_for_prompt(results)}"
                messages.append({"role": "assistant", "content": raw})
                messages.append({"role": "user",      "content": tool_result})

            elif act == "fetch":
                url     = action.get("url", "")
                # Surface a friendly domain in the status message
                try:
                    from urllib.parse import urlparse
                    domain = urlparse(url).netloc.replace("www.", "")
                except Exception:
                    domain = url[:40]
                _emit(f"reading: {domain}")
                content = fetch_page(url)
                steps_taken.append(f"Read: {url[:60]}")
                sources_consulted.append(url)
                if content:
                    tool_result = f"Page content from {url}:\n{content}"
                else:
                    tool_result = f"Couldn't load {url}."
                messages.append({"role": "assistant", "content": raw})
                messages.append({"role": "user",      "content": tool_result})

            elif act == "done":
                answer = action.get("answer", "")
                if steps_taken:
                    print(f"[agent] Done in {step+1} steps: {steps_taken}")
                _emit("synthesizing answer...")
                return (answer or "Couldn't find a clear answer."), sources_consulted

            else:
                break

        except Exception as e:
            print(f"[agent] Step {step+1} error: {e}")
            break

    # Fallback: ask Claude to synthesize from conversation so far
    messages.append({
        "role": "user",
        "content": "Synthesize everything you've found into a final answer now."
    })
    try:
        resp = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=600,
            messages=messages
        )
        return resp.content[0].text.strip(), sources_consulted
    except Exception:
        return "Research incomplete — try a more specific question.", sources_consulted


# ── Intent classifier ─────────────────────────────────────────────────────────

# Triggers that warrant AGENTIC multi-step browsing
AGENTIC_TRIGGERS = [
    "find me", "find the", "find a", "browse for", "browse and",
    "research", "look into", "investigate", "compare", "which is better",
    "best way to", "how do i", "what's the best", "recommend",
    "alternatives to", "pros and cons", "review of",
    # Historical / time-bounded queries — need real data
    "history of", "in 2024", "in 2025", "in 2026", "in 2027",
    "since last", "over the past", "year over year", "yoy",
    "highest and lowest", "all time high", "all time low", "ath",
]

# Live-data triggers — these need actual page content, not just snippets
LIVE_DATA_TRIGGERS = [
    "weather in", "weather for", "temperature in", "forecast for",
    "stock price", "stock for", "price of", "how much is",
    "score", "game tonight", "scores today",
    "what time is it in", "time in",
    "latest news", "news today", "breaking news",
    "exchange rate", "currency",
    # bare forms — no location/subject required
    "what's the weather", "whats the weather", "the weather",
    "weather today", "weather right now", "weather outside",
    "what's the news", "whats the news", "any news",
    # Crypto / market / price patterns — common patterns missed before
    "bitcoin price", "btc price", "ethereum price", "eth price",
    "price history", "price chart", "price of",
    "market cap", "trading at", "trading volume",
]

# Triggers for quick single-shot search
QUICK_TRIGGERS = [
    "look up", "search for", "google", "what is", "who is",
    "when did", "where is", "tell me about", "find out about",
    # Show patterns — usually want data
    "show me the", "show bitcoin", "show me bitcoin",
]


def should_use_agentic(text: str) -> bool:
    low = text.lower()
    if any(t in low for t in AGENTIC_TRIGGERS):
        return True
    if any(t in low for t in LIVE_DATA_TRIGGERS):
        return True
    return False


def extract_query(text: str) -> Optional[str]:
    """Pull the search query out of the user's request."""
    low = text.lower()
    patterns = [
        r"(?:find me|find the|find a|browse for|research|look into|investigate)\s+(.+)",
        r"(?:look up|search for|google|find out about|tell me about)\s+(.+)",
        r"(?:what is|who is|when did|where is|news about)\s+(.+)",
        r"(?:which is better|compare)\s+(.+)",
        r"(?:what's the best|best way to)\s+(.+)",
        # Live-data patterns — capture the subject after the trigger
        r"(?:weather in|weather for|temperature in|forecast for)\s+(.+)",
        r"(?:price of|stock price of?|how much is)\s+(.+)",
        r"(?:what time is it in|time in)\s+(.+)",
        r"(?:exchange rate|currency)\s+(.+)",
    ]
    for p in patterns:
        m = re.search(p, low)
        if m:
            return m.group(1).strip().rstrip("?.")
    # Fallback: use the whole text as query
    return text.strip()


# ── Main entrypoint (called from capabilities.py) ─────────────────────────────

def handle_web_search(text: str, client=None, status_cb=None,
                       sources_cb=None) -> Optional[str]:
    """
    Drop-in replacement for handle_web_research in capabilities.py.
    Returns a string answer or None if the text isn't a search request.

    `status_cb(msg)` is called with progress updates ("searching: X", "reading: Y").
    `sources_cb(urls)` is called once with the list of sources fetched.
    """
    if not client:
        return None

    low = text.lower().strip()

    # Personal/context questions should go to Claude, not web search
    personal_patterns = [
        r"what should i", r"what am i", r"what are you", r"what should we",
        r"how am i doing", r"how should i", r"what do i", r"what's my",
        r"whats my", r"what is my", r"should i focus", r"what to focus",
        r"what's on my", r"whats on my", r"tell me about my", r"how is my",
        r"what have i", r"what did i", r"what was i",
    ]
    if any(re.search(p, low) for p in personal_patterns):
        return None

    # Check if this looks like a web search request
    all_triggers = AGENTIC_TRIGGERS + QUICK_TRIGGERS + LIVE_DATA_TRIGGERS
    if not any(t in low for t in all_triggers):
        # Also catch "what's X", "who's X" patterns
        if not re.match(r"(what|who|where|when|how|why|which|is|are|does|did|can)\s", low):
            return None

    # Route to agentic or quick depending on complexity
    if should_use_agentic(text):
        # For agentic mode, keep the FULL question so context isn't lost.
        # "weather in nyc" → search "weather in nyc" not just "nyc".
        agentic_query = text.strip()
        # Strip just leading filler words
        agentic_query = re.sub(r"^(?:can you |please |hey |alfred,? )+", "", agentic_query, flags=re.IGNORECASE)

        # Bare-weather queries — default to a real city since we don't have
        # geolocation. NYC is a sensible default; if the user wants somewhere
        # else they'll say "weather in tokyo".
        bare_weather = ["what's the weather", "whats the weather", "the weather",
                        "weather today", "weather right now", "weather outside"]
        q_norm = agentic_query.lower().strip(" ?.")
        if q_norm in bare_weather or any(q_norm.endswith(w) for w in bare_weather):
            agentic_query = "current weather in New York City right now today"

        print(f"[search] Agentic mode for: {agentic_query}")
        result = agentic_search(agentic_query, client, status_cb=status_cb)
        # agentic_search now returns (answer, sources)
        if isinstance(result, tuple):
            answer, sources = result
            if sources_cb and sources:
                try: sources_cb(sources)
                except Exception: pass
            return answer
        return result
    else:
        # Quick mode can use the trimmed query
        query = extract_query(text)
        if not query:
            return None
        print(f"[search] Quick mode for: {query}")
        return quick_search(query, client)
