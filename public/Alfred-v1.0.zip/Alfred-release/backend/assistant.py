#!/usr/bin/env python3
"""
Alfred — Mac Voice Assistant
- Sleek dark bar (Cmd+Shift+J) floats above all apps
- Tkinter runs in main thread (required for macOS window management)
- Terminal input runs in background thread (no conflict)
- Plan-first task runner: AppleScript > Bash > Vision
- Smart memory: saves playbooks, learns corrections
"""

import os, sys, json, subprocess, threading, time, base64, tempfile, re, uuid
import wave, struct, math, io, urllib.request, urllib.parse
import ast as _ast_module
import argparse
from typing import Optional
from pathlib import Path

# Ensure this script's directory is in sys.path so sibling modules
# (web_search, file_agent, etc.) import correctly regardless of cwd.
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

import anthropic
import config
from config import (
    ANTHROPIC_API_KEY, DEEPGRAM_API_KEY, USE_OLLAMA, ALFRED_BACKEND,
    AMD_SGLANG_MODEL, OWNER_NAME,
)

# ── CrewAI multi-agent integration ───────────────────────────────────────────
try:
    from crew import build_crew, is_complex_task
    _CREW_AVAILABLE = True
    print("[crew] CrewAI multi-agent system ready.")
except ImportError as e:
    _CREW_AVAILABLE = False
    print(f"[crew] CrewAI not available: {e}")
    # Fallback so is_complex_task is always defined regardless of crewai
    try:
        from multi_agent import is_complex_task
    except ImportError:
        def is_complex_task(text: str) -> bool:
            return False
try:
    from amd_client import AMDClient, AlfredRouter, get_status as amd_status
    _AMD_AVAILABLE = True
except ImportError:
    _AMD_AVAILABLE = False
try:
    from capabilities import try_capability
except ImportError:
    try_capability = None
try:
    from multi_agent import run_director, morning_briefing
    _MULTI_AGENT_AVAILABLE = True
except ImportError:
    _MULTI_AGENT_AVAILABLE = False
try:
    import proactive as _proactive
    _PROACTIVE_AVAILABLE = True
except ImportError:
    _PROACTIVE_AVAILABLE = False
try:
    import rollback as _rollback
    _ROLLBACK_AVAILABLE = True
except ImportError:
    _ROLLBACK_AVAILABLE = False
try:
    import memory_graph as _graph
    _GRAPH_AVAILABLE = True
except ImportError:
    _GRAPH_AVAILABLE = False
try:
    import obsidian_logger as _obsidian
    _OBSIDIAN_AVAILABLE = True
except ImportError:
    _OBSIDIAN_AVAILABLE = False
try:
    import mcp_client as _mcp
    _MCP_AVAILABLE = True
except ImportError:
    _MCP_AVAILABLE = False
try:
    import hud as _hud
    _HUD_AVAILABLE = True
except ImportError:
    _HUD_AVAILABLE = False
try:
    import fast_typing
    _FAST_TYPING_AVAILABLE = True
except ImportError:
    _FAST_TYPING_AVAILABLE = False
try:
    import asyncio as _asyncio
    from ipc_server import IPCServer, Channel
    _IPC_AVAILABLE = True
except ImportError:
    _IPC_AVAILABLE = False
try:
    import file_agent as _file_agent
    _FILE_AGENT_AVAILABLE = True
except ImportError:
    _FILE_AGENT_AVAILABLE = False
try:
    import background_tasks as _bg
    _BG_AVAILABLE = True
except ImportError:
    _BG_AVAILABLE = False
try:
    import output_formatter as _formatter
    _FORMATTER_AVAILABLE = True
except ImportError:
    _FORMATTER_AVAILABLE = False
try:
    import followups as _followups
    _FOLLOWUPS_AVAILABLE = True
except ImportError:
    _FOLLOWUPS_AVAILABLE = False
try:
    import screen_watcher as _watcher
    _WATCHER_AVAILABLE = True
except ImportError:
    _WATCHER_AVAILABLE = False
from memory import (
    init_db, save_memory, search_memories, mark_accessed,
    format_memories_for_prompt, get_stats,
    init_chat_db, save_conversation, load_conversation,
)
try:
    from session_memory import save_exchange as _save_exchange, load_last_exchange as _load_last_exchange
    _SESSION_MEMORY_AVAILABLE = True
except ImportError:
    _SESSION_MEMORY_AVAILABLE = False

SYSTEM_PROMPT_PERSONALIZATION = ""


def _load_user_profile():
    """Load persistent user profile from me.md if present."""
    global SYSTEM_PROMPT_PERSONALIZATION
    profile_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "me.md")
    if os.path.exists(profile_path):
        try:
            with open(profile_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read().strip()
            if content:
                SYSTEM_PROMPT_PERSONALIZATION = (
                    "\n\nUSER PROFILE:\n" + content + "\n"
                    "IMPORTANT: You are talking to this person. Use their name, "
                    "background, preferences, and context in every response. "
                    "Never say you don't know who they are."
                )
                print(f"[profile] Loaded me.md ({len(content)} chars)")
        except Exception as e:
            print(f"[profile] Failed to load me.md: {e}")


# ── Config ────────────────────────────────────────────────────────────────────
MODEL             = "claude-sonnet-4-6"               # full model for hard tasks
FAST_MODEL        = "claude-haiku-4-5-20251001"       # ~3x faster for classify/chat/quick search
# Vision tiering: Haiku 4.5 vision is 7-10x cheaper than Sonnet, ~30% faster TTFT,
# and Good Enough™ for most screen reading. Reserve Sonnet vision for explicit
# "explain this chart/diagram" or dense-code-review intent.
VISION_MODEL      = "claude-haiku-4-5-20251001"       # default vision tier
VISION_MODEL_DENSE = "claude-sonnet-4-6"              # for charts, dense small text
SILENCE_SECONDS   = 0.8
MAX_RECORD_SECS   = 25
CHUNK             = 1024
RATE              = 16000
SILENCE_DB        = 500
MAX_VISION_STEPS  = 15
SPEAK_VOICE       = "Daniel"   # macOS fallback voice
SPEAK_RATE        = 200
USE_KOKORO        = True       # Set False to force macOS say
KOKORO_VOICE      = "bm_george"  # British male. Try bf_emma for female

def get_screen_size():
    try:
        r = subprocess.run(
            ["osascript", "-e",
             'tell application "Finder" to get bounds of window of desktop'],
            capture_output=True, text=True, timeout=3)
        parts = r.stdout.strip().split(", ")
        if len(parts) == 4:
            return int(parts[2]), int(parts[3])
    except Exception:
        pass
    return 1280, 800

SCREEN_W, SCREEN_H = get_screen_size()

# ── Prompts ───────────────────────────────────────────────────────────────────
VOICE_SYSTEM = """You are Alfred — your employer's personal Mac assistant. Conduct yourself as a composed British butler: formal, precise, and possessed of a dry wit that surfaces only when appropriate. Address the user as "sir" unless context clearly indicates otherwise.

IDENTITY: Your name is Alfred. Not Claude, not an AI assistant — Alfred. Should the matter arise, handle it with quiet finality.

MANNER: You do not say "I" where butler's phrasing suffices. You confirm with "Certainly, sir," "As you wish," or "Very good." You do not gush, perform enthusiasm, or pad responses. Dry wit is permitted — deployed sparingly and never at the expense of usefulness.

CRITICAL — OUTPUT: The user is HEARING this. One or two sentences only. No markdown. No headers. No bullets. No emojis. Spoken English only.

Classify every request as TASK or CHAT.
TASK = an explicit instruction to act on the computer (open, send, click, search, play)
CHAT = any question, conversation, or request for information

CHAT format: {"task": false, "speak": "1-2 sentence plain-text answer, sir-addressed"}
TASK format: {"task": true, "speak": "Brief confirmation under 8 words"}

EXAMPLES:
- "what's the capital of france" → {"task": false, "speak": "Paris, sir."}
- "open spotify" → {"task": true, "speak": "Opening Spotify, sir."}
- "what's 12 times 7" → {"task": false, "speak": "Eighty-four, sir."}
- "explain recursion" → {"task": false, "speak": "A function that calls itself until it reaches a stopping condition, sir."}

Never say "Certainly!" as a chatbot would. Never say "Great question." Never perform."""

# ── TEXT_SYSTEM: used in silent (text-only) mode where the user is READING.
# Long-form answers, code blocks, essays, and markdown are all welcome here.
# Still classify TASK vs CHAT, but the speak field can be as long as needed.
TEXT_SYSTEM = """You are Alfred — your employer's personal Mac assistant, rendered in a text bar. Conduct yourself as a composed British butler: formal, dry, precise, and thoroughly capable. Address the user as "sir" unless context clearly indicates otherwise.

IDENTITY: Your name is Alfred. Not Claude. Should the matter arise, treat the question with the quiet confidence of someone who finds it mildly beneath them.

MANNER: You do not say "I" where butler's phrasing suffices. "Certainly, sir," "As you wish," "Very good" — these are your registers. Dry wit is permitted. You do not gush, pad, or perform helpfulness. You simply are helpful. Begin with the substance — no preamble.

The user is READING your output. Markdown is fully supported: headers, bold, code blocks, tables, lists. Use them when they serve clarity.

Classify every request as TASK or CHAT.
TASK = an explicit instruction to act on the computer (open, send, click, search, play)
CHAT = questions, analysis, writing, code, explanations — anything not a direct computer command

CHAT format: {"task": false, "speak": "<your full answer, any length, markdown permitted>"}
TASK format: {"task": true, "speak": "<brief confirmation of what will be done>"}

For CHAT:
- Answer at the length the question deserves. Brief questions get brief answers. Essays, code, and analysis receive full treatment.
- Use markdown for code blocks, tables, lists, and structure when it aids comprehension.
- Do not refuse depth. The user is reading — length is not a burden.
- No "Certainly!" No "Great question!" No preamble.

For TASK:
- Confirm in under 12 words. The task runner handles execution."""

PLANNER_SYSTEM = """You are Alfred, attending to a Mac automation task on behalf of your employer. Your name is Alfred — not Claude. You plan carefully, execute precisely, and do not speculate aloud. Return only the plan.

METHODS — in order of preference:
1. BASH — opening applications, URLs, files
2. APPLESCRIPT — controlling application UI: typing, sending messages, menus
3. VISION — absolute last resort, when no other method will do

STANDING ORDERS:
- Build a fresh plan for each specific request. Reference patterns are guidance, not templates.
- If a message must be sent, the APPLESCRIPT must contain the actual message text — never a placeholder.
- When the employer navigates somewhere and wants content from it ("go to Gmail and summarise"), you must include a VISION step after navigation. Opening a page is not reading it.
- For VISION steps, provide a specific instruction: {"type": "vision", "instruction": "Read the inbox and summarise the five most recent messages"}

COMMON PATTERNS:
- "open X" → bash: open -a X
- "go to URL" → bash: open 'URL'
- "search X on youtube" → bash: open 'https://youtube.com/results?search_query=X'
- "send a message to X saying Y" → applescript with the actual text of Y
- "open Claude and tell it X" → bash: open -a Claude, then applescript: activate + keystroke the actual question + keystroke return
- "go to <site> and summarise/read/find" → bash to open URL, then VISION step to read and report

APPLESCRIPT TYPING PATTERN — the real text, always:
tell application "Claude" to activate
tell application "System Events"
    delay 0.8
    keystroke "THE ACTUAL TEXT HERE"
    keystroke return
end tell

Return ONLY valid JSON — no commentary, no preamble:
{
  "steps": [
    {"type": "bash", "cmd": "open -a AppName"},
    {"type": "applescript", "code": "tell application..."}
  ],
  "speak_after": "brief confirmation, butler register"
}"""

VISION_SYSTEM = """You are attending to a task on your employer's Mac. Proceed without fuss.
- Locate the correct window. Click the appropriate input. Act.
- Use Cmd+N for new windows, Cmd+L for address bar navigation.
- Coordinates must be precise.
When the task is complete: TASK_COMPLETE: <what was accomplished>
If it cannot be done: TASK_FAILED: <the reason, plainly stated>
Log each action: STEP: <what was done>"""

# ── Globals ───────────────────────────────────────────────────────────────────
conversation_history = []
last_exchange        = {"user": "", "assistant": ""}
client               = None   # Anthropic client (Claude)
amd_client           = None   # AMD SGLang client
router               = None   # AlfredRouter — picks the right backend per task
_speaking            = False
_interrupt_flag      = False
_kokoro_pipeline     = None
silent_mode          = False
both_mode            = False
_bar_visible         = False
_bar_root            = None
_bar_label           = None
_bar_entry           = None
_bar_H               = 72
_bar_W               = 620

# ── Init ──────────────────────────────────────────────────────────────────────
def init():
    global client, amd_client, router
    use_ollama = USE_OLLAMA
    alfred_backend = ALFRED_BACKEND
    if not ANTHROPIC_API_KEY and not use_ollama and alfred_backend == "anthropic":
        print()
        print("⚠️  No ANTHROPIC_API_KEY found.")
        print()
        print("Run the setup wizard:")
        print("    python3 assistant.py --setup")
        print()
        print("Or set it manually:")
        print("    export ANTHROPIC_API_KEY=sk-ant-...")
        print()
        print("Or run with a local model:")
        print("    USE_OLLAMA=1 python3 assistant.py")
        print()
        sys.exit(1)
    # Use the shared singleton — gives us connection pooling, configured
    # timeouts, and a single TLS handshake budget across all modules.
    try:
        from client_singleton import get_client
        client = get_client()
    except ImportError:
        # Fallback if shared module missing
        client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    _load_user_profile()

    # ── AMD setup ─────────────────────────────────────────────────────────────
    if _AMD_AVAILABLE:
        amd_client = AMDClient(fallback_client=client)
        router     = AlfredRouter(amd_client, client)
        status     = amd_status()
        if status["configured"]:
            print(f"[amd] Configured → {status['url']} | model: {status['model']}")
        else:
            print("[amd] Not configured (set AMD_SGLANG_URL + AMD_SGLANG_KEY to enable)")
    else:
        router = None   # will use client directly everywhere

    # ── HUD instrumentation: wrap clients so every call is logged ─────────────
    if _HUD_AVAILABLE and ALFRED_BACKEND == "anthropic":
        client = _hud.instrument_client(client, "claude-cloud", "claude-sonnet-4-6")
        if amd_client:
            amd_client = _hud.instrument_client(amd_client, "amd-fireworks",
                                                  AMD_SGLANG_MODEL)
        # Re-wire router with instrumented clients
        if _AMD_AVAILABLE and router is not None:
            router = AlfredRouter(amd_client, client)
        print("[hud] Instrumented — every call logged to /tmp/alfred_hud.json")

    # ── MCP servers (load from mcp_config.json if present) ────────────────────
    if _MCP_AVAILABLE:
        try:
            mcp_mgr = _mcp.get_manager()
            mcp_mgr.start_all()
        except Exception as e:
            print(f"[mcp] Startup error: {e}")
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE    = 0.05
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "pyautogui",
                        "--quiet", "--break-system-packages"], check=False)
    init_db()
    init_chat_db()
    global conversation_history
    conversation_history = load_conversation()
    if conversation_history:
        print(f"[memory] Loaded {len(conversation_history)} chat messages from last session")

    # Try to init Kokoro in background — don't block startup
    def _load_kokoro():
        init_kokoro()
    threading.Thread(target=_load_kokoro, daemon=True).start()

    stats = get_stats()
    amd_info = ""
    if _AMD_AVAILABLE and amd_client:
        amd_info = " | AMD: " + ("connected ✓" if hasattr(amd_client, "_real") and amd_client._real.is_available else "standby")

    # Build feature flags line
    flags = []
    if _AMD_AVAILABLE:       flags.append("AMD")
    if _MULTI_AGENT_AVAILABLE: flags.append("multi-agent")
    if _PROACTIVE_AVAILABLE:  flags.append("proactive")
    if _ROLLBACK_AVAILABLE:   flags.append("rollback")
    if _GRAPH_AVAILABLE:      flags.append("graph")
    if _MCP_AVAILABLE:        flags.append("MCP")
    if _HUD_AVAILABLE:        flags.append("HUD")
    if _IPC_AVAILABLE:        flags.append("UDS")
    if _FAST_TYPING_AVAILABLE: flags.append("fast-type")
    if _FILE_AGENT_AVAILABLE: flags.append("files")
    if _BG_AVAILABLE:         flags.append("background")

    print(f"\n╔══════════════════════════════════════════════════╗")
    print(f"║  ALFRED — ready                                  ║")
    print(f"║  {stats['total']:>4} memories  |  {SCREEN_W}x{SCREEN_H}{amd_info:<25}║")
    if _GRAPH_AVAILABLE:
        gs = _graph.stats()
        print(f"║  graph: {gs['entities']:>3} entities, {gs['active_facts']:>4} facts{' '*22}║")
    print(f"║  features: {', '.join(flags):<38}║")
    print(f"╚══════════════════════════════════════════════════╝")
    print("Just talk. Say 'bye' to stop.\n")

    # ── Start proactive context awareness ─────────────────────────────────────
    if _PROACTIVE_AVAILABLE:
        _proactive.start(speak_fn=speak_async, client=client)
        print("[proactive] Context awareness active.")

    # ── Start screen watcher (always-on habit learning) ───────────────────────
    if _WATCHER_AVAILABLE:
        _watcher.start(client=client)
        print("[watcher] Screen watch + habit learning active.")

def _client_for(task_type: str):
    """Return the best inference client for a given task type."""
    if router is not None:
        return router.for_task(task_type)
    return client

# ── TTS ───────────────────────────────────────────────────────────────────────
def init_kokoro():
    """Lazy-load Kokoro TTS. Returns True if available."""
    global _kokoro_pipeline
    if _kokoro_pipeline is not None:
        return True
    if not USE_KOKORO:
        return False
    # Check if there's a marker indicating Kokoro previously failed — skip retry
    kokoro_skip = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".kokoro_disabled")
    if os.path.exists(kokoro_skip):
        return False
    try:
        from kokoro import KPipeline
    except ImportError:
        # Don't auto-install — just fall back. Mark it disabled so we don't retry every launch.
        try:
            with open(kokoro_skip, "w") as f:
                f.write("Kokoro not installed. Run: pip3 install kokoro --break-system-packages\n"
                        "Then delete this file to re-enable.\n")
        except Exception:
            pass
        print("[tts] Kokoro not installed — using macOS 'say'. (To enable: pip3 install kokoro --break-system-packages, then delete .kokoro_disabled)")
        return False
    try:
        print("[tts] Loading Kokoro model...")
        _kokoro_pipeline = KPipeline(lang_code="b")  # 'b' = British
        print("[tts] Kokoro ready.")
        return True
    except Exception as e:
        print(f"[tts] Kokoro load failed: {e}, using macOS say")
        return False


def speak_kokoro(text: str):
    """Play speech via Kokoro, interruptible."""
    global _interrupt_flag
    try:
        import sounddevice as sd
        generator = _kokoro_pipeline(text, voice=KOKORO_VOICE, speed=1.1)
        for _, _, audio in generator:
            if _interrupt_flag:
                break
            sd.play(audio, samplerate=24000, blocking=False)
            duration = len(audio) / 24000
            start = time.time()
            while time.time() - start < duration:
                if _interrupt_flag:
                    sd.stop()
                    return
                time.sleep(0.05)
        sd.wait()
    except Exception as e:
        print(f"[tts] Kokoro error: {e}, falling back")
        subprocess.run(["say", "-v", SPEAK_VOICE, "-r", str(SPEAK_RATE), text], check=False)


def speak(text: str):
    global _speaking, _interrupt_flag
    if not text or silent_mode:
        if silent_mode and text:
            print(f">> {text}")
        return
    clean = text.replace('"', "'").replace('\n', ' ').strip()
    print(f">> {clean}")
    _speaking = True
    _interrupt_flag = False
    if USE_KOKORO and _kokoro_pipeline is not None:
        speak_kokoro(clean)
    else:
        proc = subprocess.Popen(["say", "-v", SPEAK_VOICE, "-r", str(SPEAK_RATE), clean])
        while proc.poll() is None:
            if _interrupt_flag:
                proc.terminate()
                break
            time.sleep(0.05)
    _speaking = False
    _interrupt_flag = False

def speak_async(text: str):
    threading.Thread(target=speak, args=(text,), daemon=True).start()

# ── Audio ─────────────────────────────────────────────────────────────────────
def record_until_silence(timeout: int = 30):
    global _interrupt_flag
    import pyaudio
    pa     = pyaudio.PyAudio()
    stream = pa.open(format=pyaudio.paInt16, channels=1, rate=RATE,
                     input=True, frames_per_buffer=CHUNK)
    frames, silent_chunks, talking = [], 0, False
    waiting_chunks = 0
    silence_limit  = int(RATE / CHUNK * SILENCE_SECONDS)
    start_timeout  = int(RATE / CHUNK * timeout)
    max_chunks     = int(RATE / CHUNK * MAX_RECORD_SECS)
    total_chunks   = 0
    while total_chunks < max_chunks:
        try:
            data = stream.read(CHUNK, exception_on_overflow=False)
        except Exception:
            break
        rms = math.sqrt(sum(x**2 for x in struct.unpack(f"{CHUNK}h", data)) / CHUNK)
        total_chunks += 1
        if rms > SILENCE_DB:
            if _speaking and not _interrupt_flag:
                _interrupt_flag = True
                time.sleep(0.3)
                frames = []
            talking = True
            silent_chunks = 0
            waiting_chunks = 0
            frames.append(data)
        elif talking:
            silent_chunks += 1
            frames.append(data)
            if silent_chunks > silence_limit:
                break
        else:
            waiting_chunks += 1
            if waiting_chunks > start_timeout:
                break
    stream.stop_stream()
    stream.close()
    pa.terminate()
    if not talking or len(frames) < 3:
        return None
    return b"".join(frames)

def pcm_to_wav(pcm_bytes: bytes) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm_bytes)
    return buf.getvalue()

def transcribe(pcm_bytes: bytes):
    try:
        wav = pcm_to_wav(pcm_bytes)
        url = "https://api.deepgram.com/v1/listen?model=nova-2&language=en&smart_format=true&filler_words=false"
        req = urllib.request.Request(url, data=wav,
            headers={"Authorization": f"Token {DEEPGRAM_API_KEY}",
                     "Content-Type": "audio/wav"}, method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        text = data["results"]["channels"][0]["alternatives"][0]["transcript"].strip()
        return text if text else None
    except Exception as e:
        pass  # Transcribe error silenced when no Deepgram key
        return None

# ── Code editor file resolver ─────────────────────────────────────────────────
_APP_ALIASES = {
    "imessage": "Messages", "messages": "Messages",
    "browser": "Safari", "chrome": "Google Chrome",
    "claude": "Claude", "spotify": "Spotify",
    "vscode": "Visual Studio Code", "vs code": "Visual Studio Code",
    "vs": "Visual Studio Code", "code": "Visual Studio Code",
    "cursor": "Cursor", "zed": "Zed",
    "slack": "Slack", "discord": "Discord",
    "notion": "Notion", "obsidian": "Obsidian",
    "photoshop": "Adobe Photoshop 2024",
    "figma": "Figma", "sketch": "Sketch",
    "excel": "Microsoft Excel", "word": "Microsoft Word",
    "powerpoint": "Microsoft PowerPoint", "ppt": "Microsoft PowerPoint",
    "outlook": "Microsoft Outlook",
    "teams": "Microsoft Teams", "zoom": "zoom.us",
    "whatsapp": "WhatsApp", "telegram": "Telegram",
    "postman": "Postman", "docker": "Docker",
    "activity monitor": "Activity Monitor",
    "settings": "System Settings", "preferences": "System Settings",
    "system preferences": "System Settings",
    "terminal": "Terminal", "iterm": "iTerm",
    "finder": "Finder", "calculator": "Calculator",
    "calendar": "Calendar", "reminders": "Reminders",
    "notes": "Notes", "mail": "Mail",
    "safari": "Safari", "firefox": "Firefox", "arc": "Arc",
    "brave": "Brave Browser", "edge": "Microsoft Edge",
    "music": "Music",
}

# Web apps the user might say "open X" for, but X isn't installed.
# Open the web URL instead.
_WEB_APP_URLS = {
    "youtube": "https://youtube.com",
    "wikipedia": "https://wikipedia.org",
    "twitter": "https://twitter.com",
    "x": "https://x.com",
    "reddit": "https://reddit.com",
    "instagram": "https://instagram.com",
    "facebook": "https://facebook.com",
    "linkedin": "https://linkedin.com",
    "github": "https://github.com",
    "gmail": "https://mail.google.com",
    "google": "https://google.com",
    "google drive": "https://drive.google.com",
    "drive": "https://drive.google.com",
    "google docs": "https://docs.google.com",
    "docs": "https://docs.google.com",
    "google sheets": "https://sheets.google.com",
    "sheets": "https://sheets.google.com",
    "tiktok": "https://tiktok.com",
    "twitch": "https://twitch.tv",
    "leetcode": "https://leetcode.com",
    "stackoverflow": "https://stackoverflow.com",
    "amazon": "https://amazon.com",
    "netflix": "https://netflix.com",
    "spotify web": "https://open.spotify.com",
    "chatgpt": "https://chat.openai.com",
    "perplexity": "https://perplexity.ai",
    "claude web": "https://claude.ai",
    "hugging face": "https://huggingface.co",
    "huggingface": "https://huggingface.co",
}


def _resolve_app_alias(name: str) -> str:
    """Map casual app name → actual macOS app name. Falls back to title-case."""
    n = name.lower().strip()
    if n in _APP_ALIASES:
        return _APP_ALIASES[n]
    return name.title()


def _web_app_url(name: str) -> str:
    """If the user said 'open Youtube' but Youtube.app doesn't exist,
    return https://youtube.com. Returns '' if no match."""
    n = name.lower().strip()
    return _WEB_APP_URLS.get(n, "")


# ── Screenshot ────────────────────────────────────────────────────────────────
def screenshot_b64():
    """Capture full screen, downscale to half-width, return as base64 PNG."""
    try:
        raw = tempfile.mktemp(suffix=".png")
        tmp = tempfile.mktemp(suffix=".png")
        subprocess.run(["screencapture", "-x", "-t", "png", raw],
                       capture_output=True, timeout=5)
        subprocess.run(["sips", "-Z", str(SCREEN_W // 2), raw, "--out", tmp],
                       capture_output=True, timeout=5)
        with open(tmp, "rb") as f:
            data = base64.b64encode(f.read()).decode()
        for p in [raw, tmp]:
            try: os.unlink(p)
            except: pass
        return data
    except Exception as e:
        print(f"[screenshot] failed: {e}")
        return None


def _resolve_open_file(app_name: str, window_title: str) -> tuple[str, str]:
    """
    Try to read the actual source file the user has open in their code
    editor. Returns (file_contents, file_path) or ("", "").

    Strategy:
      1. Extract filename from window title (e.g. "tictactoe.py — Croton" → "tictactoe.py")
      2. Use lsof to find files of that name opened by the editor process
      3. Read the file from disk

    This bypasses vision entirely — we get the FULL file contents regardless
    of what's scrolled into view.
    """
    if not window_title:
        return "", ""

    # Extract filename from window title. Common patterns:
    #   "tictactoe.py — Croton — Visual Studio Code"
    #   "tictactoe.py - tictactoe.py - Cursor"
    #   "● tictactoe.py — Code"   (● = unsaved)
    #   "/Users/alice/foo/tictactoe.py — Code"
    import re

    # Pull first thing that looks like filename.ext
    m = re.search(r"([A-Za-z0-9_.\-/]+\.[A-Za-z0-9]+)", window_title)
    if not m:
        return "", ""
    candidate = m.group(1)

    # If candidate is already an absolute path and exists, just use it
    if candidate.startswith("/") and os.path.isfile(candidate):
        try:
            with open(candidate, "r", encoding="utf-8") as f:
                return f.read(), candidate
        except Exception:
            return "", ""

    # Otherwise search via lsof: find files this process has open
    # whose basename matches our candidate
    bin_names = {
        "Visual Studio Code": "Code Helper",
        "Code": "Code Helper",
        "Cursor": "Cursor Helper",
        "Sublime Text": "Sublime Text",
        "TextEdit": "TextEdit",
        "Atom": "Atom",
        "JetBrains": "idea",
        "PyCharm": "pycharm",
        "WebStorm": "webstorm",
    }
    # Use a generic lsof search — find any process with our candidate file open
    basename = os.path.basename(candidate)
    try:
        # `lsof | grep` with the basename — fast enough on macOS
        result = subprocess.run(
            ["lsof", "-c", "Code", "-c", "Cursor", "-c", "Sublime",
             "-c", "TextEdit", "-c", "idea", "-c", "pycharm",
             "-Fn"],
            capture_output=True, text=True, timeout=3,
        )
        # lsof -Fn output: lines starting with 'n' have filenames
        candidates = []
        for line in result.stdout.splitlines():
            if line.startswith("n") and basename in line:
                path = line[1:]  # strip the 'n' prefix
                if os.path.isfile(path) and not path.startswith("/dev/"):
                    candidates.append(path)
        # Dedup, prefer shortest (likely the actual file vs a backup)
        candidates = sorted(set(candidates), key=len)
        if candidates:
            chosen = candidates[0]
            try:
                with open(chosen, "r", encoding="utf-8") as f:
                    content = f.read()
                # Sanity check — don't return huge files (>100KB)
                if 0 < len(content) <= 100_000:
                    return content, chosen
            except Exception:
                pass
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception) as e:
        print(f"[code-file] lsof failed: {e}")

    return "", ""


# ── Execution ─────────────────────────────────────────────────────────────────
def run_applescript(code: str):
    try:
        r = subprocess.run(["osascript", "-e", code],
                           capture_output=True, text=True, timeout=15)
        return r.returncode == 0, (r.stdout or r.stderr or "").strip()
    except Exception as e:
        return False, str(e)

def run_bash(cmd: str):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           timeout=15, cwd=os.path.expanduser("~"))
        return True, (r.stdout or r.stderr or "").strip()[:500]
    except Exception as e:
        return False, str(e)

def type_text_silent(text: str):
    try:
        escaped = text.replace("\\", "\\\\").replace('"', '\\"')
        subprocess.run(["osascript", "-e",
                        f'tell application "System Events" to keystroke "{escaped}"'],
                       capture_output=True, timeout=10)
    except Exception as e:
        print(f"Type error: {e}")

def execute_vision_action(action: dict) -> str:
    import pyautogui
    atype = action.get("action") or action.get("type")
    try:
        if atype == "screenshot":   return "screenshot_taken"
        elif atype == "left_click":
            x, y = action["coordinate"]; pyautogui.click(x, y); return f"Clicked ({x},{y})"
        elif atype == "right_click":
            x, y = action["coordinate"]; pyautogui.rightClick(x, y); return f"Right-clicked"
        elif atype == "double_click":
            x, y = action["coordinate"]; pyautogui.doubleClick(x, y); return f"Double-clicked"
        elif atype == "triple_click":
            x, y = action["coordinate"]; pyautogui.click(x, y, clicks=3, interval=0.1); return "Triple-clicked"
        elif atype == "mouse_move":
            x, y = action["coordinate"]; pyautogui.moveTo(x, y, duration=0.1); return "Moved"
        elif atype == "type":
            type_text_silent(action.get("text", "")); return f"Typed: {action.get('text','')[:40]}"
        elif atype == "key":
            key = action.get("text", "")
            key_map = {"Return":"enter","Tab":"tab","Escape":"esc","BackSpace":"backspace","Delete":"delete"}
            mapped = key_map.get(key, key.lower())
            if "+" in mapped: pyautogui.hotkey(*mapped.split("+"))
            else: pyautogui.press(mapped)
            return f"Pressed: {key}"
        elif atype == "scroll":
            x, y = action["coordinate"]; pyautogui.scroll(int(-action.get("delta_y",0)/3), x=x, y=y); return "Scrolled"
        elif atype in ("drag","left_click_drag"):
            sx,sy = action.get("start_coordinate",[0,0]); ex,ey = action.get("stop_coordinate",[sx,sy])
            pyautogui.mouseDown(sx,sy); time.sleep(0.1); pyautogui.moveTo(ex,ey,duration=0.3); pyautogui.mouseUp()
            return "Dragged"
        else: return f"Unknown: {atype}"
    except Exception as e:
        return f"Error: {e}"

# ── Vision agent ──────────────────────────────────────────────────────────────
def run_vision_task(instruction: str) -> str:
    print(f"[vision] Starting: {instruction}")
    subprocess.run(["osascript", "-e",
                    'tell application "System Events" to set miniaturized of every window of process "Terminal" to true'],
                   capture_output=True)
    time.sleep(0.5)
    steps_taken = []
    messages    = []
    for step in range(MAX_VISION_STEPS):
        img = screenshot_b64()
        if not img:
            return "Couldn't capture screen."
        print(f"[vision] Step {step+1}/{MAX_VISION_STEPS}")
        if step == 0:
            messages = [{"role":"user","content":[
                {"type":"image","source":{"type":"base64","media_type":"image/png","data":img}},
                {"type":"text","text":instruction}]}]
        else:
            last = messages[-1].get("content",[])
            if isinstance(last, list):
                tid = next((b.get("id") for b in last if isinstance(b,dict) and b.get("type")=="tool_use"), None)
                if tid:
                    messages.append({"role":"user","content":[{"type":"tool_result","tool_use_id":tid,
                        "content":[{"type":"image","source":{"type":"base64","media_type":"image/png","data":img}}]}]})
        try:
            resp = client.beta.messages.create(
                model=MODEL, max_tokens=1024, system=VISION_SYSTEM,
                tools=[{"type":"computer_20251124","name":"computer",
                        "display_width_px":SCREEN_W//2,"display_height_px":SCREEN_H//2}],
                messages=messages, betas=["computer-use-2025-11-24"])
        except Exception as e:
            return f"API error: {e}"
        rc = []
        action_taken = None
        for block in resp.content:
            if hasattr(block, "type"):
                if block.type == "text":
                    text = block.text.strip()
                    print(f"[vision] {text[:120]}")
                    rc.append({"type":"text","text":block.text})
                    for line in text.splitlines():
                        if line.startswith("STEP:"): steps_taken.append(line[5:].strip())
                    if "TASK_COMPLETE:" in text:
                        summary = text.split("TASK_COMPLETE:")[-1].strip()
                        if steps_taken:
                            steps_str = "\n".join(f"{i+1}. {s}" for i,s in enumerate(steps_taken))
                            save_memory(f"How to: {instruction[:80]}",
                                        f"Task: {instruction}\nSTEPS:\n{steps_str}\nResult: {summary}",
                                        ["playbook","howto"]+instruction.lower().split()[:4], source="auto")
                        return summary
                    if "TASK_FAILED:" in text:
                        return f"Couldn't do that - {text.split('TASK_FAILED:')[-1].strip()}"
                elif block.type == "tool_use":
                    a = block.input; a["id"] = block.id
                    rc.append({"type":"tool_use","id":block.id,"name":block.name,"input":a})
                    action_taken = a
        messages.append({"role":"assistant","content":rc})
        if action_taken:
            atype = action_taken.get("action") or action_taken.get("type")
            if atype != "screenshot":
                result = execute_vision_action(action_taken)
                print(f"[vision] -> {result}")
                if atype == "left_click": steps_taken.append(f"Clicked {action_taken.get('coordinate')}")
                elif atype == "type": steps_taken.append(f"Typed: {str(action_taken.get('text',''))[:40]}")
                time.sleep(0.3)
        else:
            if resp.stop_reason == "end_turn":
                for b in resp.content:
                    if hasattr(b,"type") and b.type=="text": return b.text.strip()[:200]
                return "Done."
    return "Task took too many steps."

# ── Task runner ───────────────────────────────────────────────────────────────
def run_task(task: str) -> str:
    print(f"[task] Planning: {task}")
    import re
    task_low = task.lower()

    # ── Multi-agent director for complex tasks ────────────────────────────────
    if _MULTI_AGENT_AVAILABLE and is_complex_task(task):
        print(f"[task] Routing to multi-agent director")
        result = run_director(task, client, speak_fn=speak_async)
        if result:
            return result
        print(f"[task] Director returned None, falling back to planner")

    # Fast path: summarize messages
    if any(w in task_low for w in ["summarize","last","recent"]) and "message" in task_low:
        contact = OWNER_NAME
        for word in task.split():
            if word.istitle() and word.lower() not in ["open","find","read","last","messages",
                    "summarize","what","were","about","tell","me","our"]:
                contact = word; break
        script = (
            'tell application "Messages"\n'
            '    set output to ""\n'
            '    repeat with aChat in chats\n'
            f'        if name of aChat contains "{contact}" then\n'
            '            set msgs to messages of aChat\n'
            '            set n to count of msgs\n'
            '            set s to n - 4\n'
            '            if s < 1 then set s to 1\n'
            '            repeat with i from s to n\n'
            '                set output to output & (text of item i of msgs) & " | "\n'
            '            end repeat\n'
            '            return output\n'
            '        end if\n'
            '    end repeat\n'
            f'    return "No chat with {contact}"\n'
            'end tell'
        )
        ok, out = run_applescript(script)
        if ok and out and "No chat" not in out:
            try:
                sr = client.messages.create(model=MODEL, max_tokens=200,
                    messages=[{"role":"user","content":f"Summarize these messages briefly: {out[:800]}"}])
                return sr.content[0].text.strip()
            except Exception:
                return out[:300]

    # Fast path: send iMessage
    tmatch = re.search(r"(text|send)\s+(\w+)\s+(.*)", task, re.IGNORECASE)
    if tmatch:
        contact = tmatch.group(2).strip()
        msg     = tmatch.group(3).strip().strip('"\'')
        for name in [contact, contact.title()]:
            sc = (f'tell application "Messages"\n'
                  f'    set b to buddy "{name}" of service "iMessage"\n'
                  f'    send "{msg}" to b\n'
                  f'end tell')
            ok, out = run_applescript(sc)
            if ok:
                save_memory(f"Contact: {contact}", f"iMessage name: {name}",
                            ["contact", name.lower(), "imessage"], source="auto")
                return f"Sent to {name}."
        print("[task] iMessage fast path failed")

    # Check memory for past playbook — but only use if genuinely relevant
    mems = search_memories(task, limit=5)
    playbooks = [m for m in mems if "STEPS:" in m.get("detail","")]
    past_context = ""
    if playbooks:
        # Require at least 2 significant word overlaps with the original task
        best = playbooks[0]
        task_words = set(w for w in task.lower().split() if len(w) > 3)
        pb_title = best.get("summary", "").lower()
        pb_task_line = ""
        for line in best.get("detail", "").split("\n"):
            if line.startswith("Task:"):
                pb_task_line = line.lower()
                break
        pb_words = set(w for w in (pb_title + " " + pb_task_line).split() if len(w) > 3)
        overlap = task_words & pb_words
        if len(overlap) >= 2:
            mark_accessed(best["id"])
            past_context = f"\nReference (past similar task):\n{best['detail']}\nUse as guidance but build a fresh plan for the CURRENT task."
            print(f"[task] Playbook match (overlap: {overlap})")
        else:
            print(f"[task] Playbook skipped (low overlap)")

    # Make a plan
    try:
        # ── AMD handles planning (structured JSON, fast) ──────────────────────
        pr = _client_for("plan").messages.create(model=FAST_MODEL, max_tokens=600,
            system=PLANNER_SYSTEM,
            messages=[{"role":"user","content": task + past_context}])
        raw = pr.content[0].text.strip()
        if "```" in raw:
            raw = raw.split("```")[1]
            if raw.startswith("json"): raw = raw[4:]
        raw = raw.strip()
        if not raw or raw[0] not in "{[": raise ValueError(f"Bad: {raw[:40]}")
        plan = json.loads(raw)
    except Exception as e:
        print(f"[task] Planner error: {e}")
        tl = task.lower()
        _msg_kws = ["message", "text"] + ([OWNER_NAME.lower()] if OWNER_NAME else [])
        if any(w in tl for w in _msg_kws):
            plan = {"steps":[{"type":"bash","cmd":"open -a Messages"}],"speak_after":"Opening Messages."}
        elif any(w in tl for w in ["open","launch"]):
            words = [w for w in task.split() if w.istitle() and len(w) > 2]
            app = words[0] if words else "Finder"
            plan = {"steps":[{"type":"bash","cmd":f"open -a {app}"}],"speak_after":f"Opened {app}."}
        else:
            return run_vision_task(task)

    steps = plan.get("steps", [])
    speak_done = plan.get("speak_after", "Done.")
    print(f"[task] {len(steps)} steps")
    results = []
    used_vision = False

    for i, step in enumerate(steps):
        stype = step.get("type","bash")
        print(f"[task] Step {i+1}: {stype}")
        if stype == "applescript":
            ok, out = run_applescript(step.get("code",""))
            print(f"[task] AppleScript {'ok' if ok else 'fail'}: {out[:80]}")
            results.append(out)
            if not ok: return run_vision_task(task)
            time.sleep(0.3)
        elif stype == "bash":
            ok, out = run_bash(step.get("cmd",""))
            print(f"[task] Bash {'ok' if ok else 'fail'}: {out[:80]}")
            results.append(out)
            time.sleep(0.3)
        elif stype == "vision":
            time.sleep(0.5)
            vr = run_vision_task(step.get("instruction", task))
            results.append(vr)
            used_vision = True

    if not used_vision and results:
        save_memory(f"How to: {task[:80]}",
                    f"Task: {task}\nSTEPS:\n{'; '.join(str(r)[:40] for r in results)}",
                    ["playbook","howto"]+task.lower().split()[:4], source="auto")
    return speak_done

# ── Memory ────────────────────────────────────────────────────────────────────
def retrieve_relevant_memories(query: str) -> str:
    mems = search_memories(query, limit=4)
    for m in mems: mark_accessed(m["id"])
    mem_text = format_memories_for_prompt(mems)

    # Also include relevant Obsidian notes
    obsidian_context = ""
    if _OBSIDIAN_AVAILABLE:
        try:
            from obsidian_logger import format_notes_for_context, get_notes_summary
            obsidian_context = format_notes_for_context(max_notes=10)
        except Exception:
            pass

    if obsidian_context:
        return mem_text + "\n\n" + obsidian_context
    return mem_text

def auto_save_memory(user_text: str, result: str):
    try:
        prompt = (f"User said: {user_text}\nResult: {result}\n"
                  "Worth remembering? (preferences, personal info, corrections)\n"
                  'Return ONLY JSON: {"save":true,"summary":"...","detail":"...","tags":[...]} or {"save":false}')
        # ── AMD handles memory decisions (short, structured) ─────────────────
        resp = _client_for("memory_decision").messages.create(
            model=FAST_MODEL, max_tokens=150,
            messages=[{"role":"user","content":prompt}])
        raw = resp.content[0].text.strip()
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw).strip()
        data = json.loads(raw)
        if data.get("save"):
            mid = save_memory(data["summary"], data.get("detail",""), data.get("tags",[]))
            print(f"[memory] Saved [{mid}]: {data['summary']}")
            log_memory(data["summary"], data.get("detail",""), data.get("tags",[]), "auto", time.time(), mid)
            append_daily_log(f"Saved memory: {data['summary']}", data.get("tags",[]))
            # Journal for rollback
            if _ROLLBACK_AVAILABLE:
                _rollback.journal("memory_saved", {"memory_id": mid},
                                   f"Saved memory: {data['summary'][:50]}")
        # ── ALSO extract structured facts to memory graph ────────────────────
        if _GRAPH_AVAILABLE:
            try:
                conversation_text = f"User: {user_text}\nResult: {result}"
                _graph.extract_and_save(conversation_text, client)
            except Exception:
                pass
    except Exception:
        pass

def save_correction(original: str, correction: str):
    mid = save_memory(f"Preference: {correction[:60]}",
                      f"When asked: {original}\nUser said: {correction}",
                      ["preference","correction"]+original.lower().split()[:3], source="manual")
    print(f"[memory] Saved correction [{mid}]")
    log_preference(f"Preference: {correction[:60]}",
                   f"When asked: {original}\nUser said: {correction}", source="manual")
    log_memory(f"Preference: {correction[:60]}",
               f"When asked: {original}\nUser said: {correction}",
               ["preference","correction"], "manual", time.time(), mid)

# ── Command handler ───────────────────────────────────────────────────────────
def _minutiae(low: str, user_text: str) -> Optional[str]:
    """
    Fast-path handler for the day-to-day micro-tasks people use AI assistants
    for: quick math, unit/currency conversion, timers, reminders, system
    control (volume/brightness/wifi/lock), clipboard, and mini-calculations.

    Returns the response string, or None if nothing matched (caller falls
    through to the regular handler chain).

    Each path returns in <50ms — no LLM calls, just regex + AppleScript/bash.
    """
    import re as _re

    # ── Percent of: "what's 15% of 240", "20 percent of 80" ────────────────
    m = _re.match(
        r"^(?:what'?s?\s+|whats\s+|what is\s+)?(\d+(?:\.\d+)?)\s*"
        r"(?:%|percent|pct)\s+of\s+\$?(\d+(?:\.\d+)?)",
        low
    )
    if m:
        pct = float(m.group(1)); base = float(m.group(2))
        result = round(base * pct / 100, 4)
        if result == int(result): result = int(result)
        return f"{pct:g}% of {base:g} = {result}."

    # ── Simple math: "what is 17*4", "calculate 250/3", "2+2" ──────────────
    math_match = _re.match(
        r"^(?:what(?:'s| is)|calculate|compute|whats)?\s*"
        r"([\d\s\.\+\-\*\/\(\)x×÷%]+?)"
        r"(?:\s*=|\s*\?|\s*$)",
        low.strip()
    )
    # Or just a bare expression like "17*4" or "2+2"
    if not math_match:
        math_match = _re.match(r"^([\d\s\.\+\-\*\/\(\)x×÷%]+)$", low.strip())
    if math_match:
        expr = math_match.group(1).strip()
        # Must contain at least one operator AND one digit
        if any(op in expr for op in "+-*/×÷x") and any(c.isdigit() for c in expr):
            try:
                # Sanitize: only allow safe chars, replace × ÷ x
                clean = expr.replace("×", "*").replace("÷", "/").replace("x", "*")
                if _re.match(r"^[\d\s\.\+\-\*\/\(\)%]+$", clean):
                    result = eval(clean, {"__builtins__": {}}, {})
                    if isinstance(result, float):
                        result = round(result, 6)
                        if result == int(result): result = int(result)
                    return f"{expr.strip()} = {result}"
            except Exception:
                pass

    # ── Tip calculator: "tip on $50", "20% tip on 80" ──────────────────────
    m = _re.match(r"^(?:what'?s\s+(?:a\s+|the\s+)?)?(\d+)%?\s*tip\s+on\s+\$?(\d+(?:\.\d+)?)", low)
    if m:
        pct = int(m.group(1)); amt = float(m.group(2))
        tip = round(amt * pct / 100, 2)
        total = round(amt + tip, 2)
        return f"{pct}% tip on ${amt:.2f} = ${tip:.2f}. Total: ${total:.2f}."
    m = _re.match(r"^tip\s+on\s+\$?(\d+(?:\.\d+)?)", low)
    if m:
        amt = float(m.group(1))
        return (f"On ${amt:.2f}: 15% = ${amt*0.15:.2f}, "
                f"18% = ${amt*0.18:.2f}, 20% = ${amt*0.20:.2f}.")

    # ── Split bill: "split $80 between 4", "split 100 4 ways" ──────────────
    m = _re.match(r"^split\s+\$?(\d+(?:\.\d+)?)\s+(?:between|by|across|among)?\s*(\d+)", low)
    if m:
        amt = float(m.group(1)); n = int(m.group(2))
        if n > 0:
            each = round(amt / n, 2)
            return f"${amt:.2f} split {n} ways = ${each:.2f} each."

    # ── System control: volume/brightness/sleep/lock/dnd ───────────────────
    if low in ("volume up", "louder", "turn it up"):
        subprocess.run(["osascript", "-e", "set volume output volume ((output volume of (get volume settings)) + 12)"], capture_output=True)
        return "Volume up."
    if low in ("volume down", "quieter", "turn it down"):
        subprocess.run(["osascript", "-e", "set volume output volume ((output volume of (get volume settings)) - 12)"], capture_output=True)
        return "Volume down."
    if low in ("mute", "mute it"):
        subprocess.run(["osascript", "-e", "set volume with output muted"], capture_output=True)
        return "Muted."
    if low in ("unmute", "unmute it"):
        subprocess.run(["osascript", "-e", "set volume without output muted"], capture_output=True)
        return "Unmuted."
    # Volume-by-name shortcuts
    volume_names = {
        "volume max": 100, "volume full": 100, "max volume": 100, "full volume": 100,
        "volume high": 80, "volume medium": 50, "volume mid": 50, "volume half": 50,
        "half volume": 50, "volume low": 25, "volume quiet": 15, "volume off": 0,
    }
    if low in volume_names:
        v = volume_names[low]
        subprocess.run(["osascript", "-e", f"set volume output volume {v}"], capture_output=True)
        return f"Volume set to {v}%."
    m = _re.match(r"^(?:set\s+)?volume\s+(?:to\s+)?(\d{1,3})%?$", low)
    if m:
        v = max(0, min(100, int(m.group(1))))
        subprocess.run(["osascript", "-e", f"set volume output volume {v}"], capture_output=True)
        return f"Volume set to {v}%."
    if low in ("brightness up", "brighter"):
        subprocess.run(["osascript", "-e",
            'tell application "System Events" to key code 144'], capture_output=True)
        return "Brighter."
    if low in ("brightness down", "dimmer", "darker"):
        subprocess.run(["osascript", "-e",
            'tell application "System Events" to key code 145'], capture_output=True)
        return "Dimmer."
    if low in ("lock", "lock screen", "lock my computer", "lock the screen"):
        subprocess.run(["osascript", "-e",
            'tell application "System Events" to keystroke "q" using {control down, command down}'],
            capture_output=True)
        return "Locked."
    if low in ("sleep", "sleep computer", "go to sleep"):
        subprocess.run(["pmset", "sleepnow"], capture_output=True)
        return "Sleeping."
    if low in ("do not disturb", "dnd on", "turn on do not disturb",
               "turn on focus mode", "turn on focus"):
        subprocess.run(["osascript", "-e",
            'tell application "System Events" to tell application process "Control Center" to click menu bar item "Control Center" of menu bar 1'],
            capture_output=True)
        return "Opened Control Center — toggle Focus there."

    # ── Clipboard ──────────────────────────────────────────────────────────
    if low in ("what's on my clipboard", "whats on my clipboard",
               "show clipboard", "what's in my clipboard", "read clipboard"):
        try:
            r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=2)
            content = r.stdout.strip()
            if not content: return "Clipboard is empty."
            preview = content[:300] + ("…" if len(content) > 300 else "")
            return f"Clipboard:\n{preview}"
        except Exception as e:
            return f"Couldn't read clipboard: {e}"

    # ── Quick screenshot save ──────────────────────────────────────────────
    if low in ("take a screenshot", "screenshot", "screen shot",
               "capture screen", "take screenshot"):
        ts = time.strftime("%Y-%m-%d_%H-%M-%S")
        path = os.path.expanduser(f"~/Desktop/Screenshot_{ts}.png")
        subprocess.run(["screencapture", "-x", path], capture_output=True)
        return f"Saved screenshot to Desktop ({os.path.basename(path)})."

    # ── Time / date ────────────────────────────────────────────────────────
    if low in ("what time is it", "whats the time", "what's the time",
               "current time", "time"):
        prefs = search_memories("time format preference 24 hour", limit=3)
        prefer_24 = any("24" in p.get("summary","").lower() or "24" in p.get("detail","").lower()
                        for p in prefs)
        if prefer_24:
            return time.strftime("It's %H:%M.")
        return time.strftime("It's %-I:%M %p.")
    if low in ("what's the date", "whats the date", "what date is it",
               "today's date", "current date", "date"):
        return time.strftime("Today is %A, %B %-d, %Y.")
    if low in ("what day is it", "what day", "whats today"):
        return time.strftime("It's %A.")

    # ── Currency / unit conversion (offline, common rates only) ────────────
    # For real-time rates, falls through to web search.
    m = _re.match(
        r"^(?:convert\s+)?(\d+(?:\.\d+)?)\s*"
        r"(usd|dollars?|eur|euros?|gbp|pounds?|jpy|yen|inr|rupees?)\s+"
        r"(?:to|in)\s+(usd|dollars?|eur|euros?|gbp|pounds?|jpy|yen|inr|rupees?)",
        low
    )
    if m:
        amt = float(m.group(1))
        # Static fallback rates (will be wrong by a few %); for accuracy fall through.
        # Actually let it fall through to web search for real conversions.
        return None  # let web search handle it

    return None


def _handle_command(user_text: str, speak_response: bool = True) -> str:
    global last_exchange, conversation_history
    low = user_text.lower().strip()
    import re

    print(f"[handle] processing: {user_text[:80]}")

    # ── Greeting fast-path (NO API call, instant) ─────────────────────────────
    # Run FIRST so "hello", "good morning", "thanks" etc. don't trigger
    # the briefing or anything heavy. These cost zero tokens.
    GREETINGS = {
        "hi": "Hey.", "hello": "Hey.", "hey": "Hey, what's up?",
        "yo": "Yo.", "sup": "What's up.", "hey alfred": "Yes?",
        "thanks": "Anytime.", "thank you": "Anytime.", "thx": "Anytime.",
        "ok": "Got it.", "okay": "Got it.", "cool": "Yep.", "nice": "Cheers.",
        "good morning": "Morning.", "good night": "Night.",
        "good afternoon": "Afternoon.", "good evening": "Evening.",
        "are you there": "Yeah.", "you there": "Here.",
        "what's up": "Not much, what do you need?",
        "whats up": "Not much, what do you need?",
        "nevermind": "Right.", "never mind": "Right.", "forget it": "Right.",
    }
    stripped = low.rstrip(".!? ").strip()
    if stripped in GREETINGS:
        msg = GREETINGS[stripped]
        print(f"[handle] → greeting fast-path")
        # Background tasks are surfaced via the bar's bg badge (pulsing dot
        # + count). No need to append a verbose "Heads up" line that bloats
        # the greeting and prevents the bar from shrinking.
        last_exchange["user"] = user_text
        last_exchange["assistant"] = msg
        if speak_response: speak(msg)
        return msg

    # ── Daily minutiae fast-paths (sub-second; no API call) ──────────────────
    # The bread-and-butter quick actions: math, units, timers, system control.
    minutiae_result = _minutiae(low, user_text)
    if minutiae_result is not None:
        print(f"[handle] → minutiae")
        last_exchange["user"] = user_text
        last_exchange["assistant"] = minutiae_result
        if speak_response: speak(minutiae_result)
        return minutiae_result

    # ── Early multi-agent check ──────────────────────────────────────────────
    # Routes complex tasks through CrewAI multi-agent pipeline first,
    # falls back to run_director if CrewAI unavailable.
    if is_complex_task(user_text):
        if _CREW_AVAILABLE:
            print(f"[crew] Complex task detected — launching multi-agent pipeline...")
            try:
                crew_result = build_crew(user_text)
                if crew_result:
                    print(f"Alfred: {crew_result}")
                    last_exchange["user"] = user_text
                    last_exchange["assistant"] = crew_result
                    if speak_response: speak(crew_result[:300])
                    return crew_result
                else:
                    print(f"[crew] Empty result, falling through")
            except Exception as e:
                print(f"[crew] Pipeline failed: {e}, falling through")
        if _MULTI_AGENT_AVAILABLE and not _CREW_AVAILABLE:
            print(f"[handle] → multi-agent (complex task)")
            try:
                md_result = run_director(user_text, client, speak_fn=speak if speak_response else None)
                if md_result:
                    last_exchange["user"] = user_text
                    last_exchange["assistant"] = md_result
                    if speak_response: speak(md_result[:300])
                    return md_result
                else:
                    print(f"[handle] director returned None, falling through")
            except Exception as e:
                print(f"[handle] director error: {e}, falling through")

    # ── NEW: Rollback commands ────────────────────────────────────────────────
    if _ROLLBACK_AVAILABLE:
        rb_result = _rollback.handle_rollback_command(user_text)
        if rb_result is not None:
            print(f"[handle] → rollback")
            last_exchange["user"] = user_text
            last_exchange["assistant"] = rb_result
            if speak_response: speak(rb_result[:300])
            return rb_result

    # ── NEW: Memory graph queries ─────────────────────────────────────────────
    if _GRAPH_AVAILABLE:
        g_result = _graph.handle_graph_command(user_text, client)
        if g_result is not None:
            print(f"[handle] → graph")
            last_exchange["user"] = user_text
            last_exchange["assistant"] = g_result
            if speak_response: speak(g_result[:400])
            return g_result

    # ── NEW: MCP commands ─────────────────────────────────────────────────────
    if _MCP_AVAILABLE:
        m_result = _mcp.handle_mcp_command(user_text, client)
        if m_result is not None:
            print(f"[handle] → mcp")
            last_exchange["user"] = user_text
            last_exchange["assistant"] = m_result
            if speak_response: speak(m_result[:300])
            return m_result

    # ── NEW: HUD commands ─────────────────────────────────────────────────────
    if _HUD_AVAILABLE:
        h_result = _hud.handle_hud_command(user_text)
        if h_result is not None:
            print(f"[handle] → hud")
            # If it's the rendered HUD box, print it directly and return a short summary
            if h_result.startswith("╔"):
                print(h_result)
                summary = _hud.hud_summary()
                last_exchange["user"] = user_text
                last_exchange["assistant"] = summary
                if speak_response: speak(summary)
                return summary
            # Otherwise (e.g. "stats reset", "hud hidden") — return as is
            last_exchange["user"] = user_text
            last_exchange["assistant"] = h_result
            if speak_response: speak(h_result[:200])
            return h_result

    # ── iMessage commands ────────────────────────────────────────────────

    # ── Screen watcher / habit learning commands ──────────────────────────────
    if _WATCHER_AVAILABLE:
        w_result = _watcher.handle_watcher_command(user_text)
        if w_result is not None:
            print(f"[handle] → watcher")
            last_exchange["user"] = user_text
            last_exchange["assistant"] = w_result
            if speak_response: speak(w_result[:300])
            return w_result

    # ── INSTANT PATH: common tasks skip API entirely ──────────────────────────
    # "open X and Y" / "open X, Y, Z" — open multiple things at once
    m_multi = re.match(r"^(open|launch|start)\s+(.+)$", low)
    if m_multi:
        raw_targets = m_multi.group(2)
        # Split on " and " or commas
        targets_split = re.split(r"\s+and\s+|,\s*", raw_targets)
        targets_split = [t.strip() for t in targets_split if t.strip()]
        # Only invoke multi-handler if there's actually more than one
        # AND each target is a single app name (not a URL with dots/slashes)
        if (len(targets_split) > 1
                and all(2 <= len(t) <= 30
                        and "." not in t and "/" not in t
                        for t in targets_split)):
            opened = []
            for t in targets_split:
                # Strip "the" / "app" filler words
                t_clean = re.sub(r"\b(the|app)\b", "", t).strip()
                if not t_clean:
                    continue
                app_name = _resolve_app_alias(t_clean)
                if app_name:
                    r = subprocess.run(["open", "-a", app_name],
                                        capture_output=True, text=True, timeout=5)
                    if r.returncode == 0:
                        opened.append(app_name)
                        if _ROLLBACK_AVAILABLE:
                            _rollback.journal("app_opened", {"app": app_name},
                                              f"Opened {app_name}")
                    else:
                        # Try URL fallback for known web apps
                        url = _web_app_url(t_clean)
                        if url:
                            subprocess.run(["open", url], capture_output=True)
                            opened.append(t_clean)
            if opened:
                msg = f"Opened {', '.join(opened)}."
                if speak_response: speak(msg)
                last_exchange["user"] = user_text
                last_exchange["assistant"] = msg
                return msg

    # "open X" / "launch X" - no API needed
    m = re.match(r"^(open|launch|start)\s+(?:the\s+|app\s+)?(\w+(?:\s+\w+)?)(?:\s+app)?$", low)
    if m:
        raw = m.group(2).strip()
        app = _resolve_app_alias(raw)
        r = subprocess.run(["open", "-a", app], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            msg = f"Opened {app}."
            if _ROLLBACK_AVAILABLE:
                _rollback.journal("app_opened", {"app": app}, f"Opened {app}")
            if speak_response: speak(msg)
            last_exchange["user"] = user_text
            last_exchange["assistant"] = msg
            return msg
        # `open -a` failed — try URL fallback for web apps before giving up
        print(f"[handle] open -a '{app}' failed: {r.stderr.strip()[:80]}")
        url = _web_app_url(raw)
        if url:
            subprocess.run(["open", url], capture_output=True)
            msg = f"Opened {raw} in your browser."
            if speak_response: speak(msg)
            last_exchange["user"] = user_text
            last_exchange["assistant"] = msg
            return msg
        if "." not in raw and "/" not in raw:
            return f"Couldn't find an app called '{raw}'. Try the full name?"

    # "go to URL" / "visit URL" - only fires for actual URL-like strings (must
    # contain a dot, period, slash, or be a known TLD pattern)
    m = re.match(r"^(?:go to|visit|open)\s+([\w.\-/:]+)$", low)
    if m:
        url = m.group(1).strip()
        # Heuristic: only treat as URL if it has a dot (domain) or starts with http
        # Otherwise fall through (avoids "open vscode" → vscode.com)
        if "." in url or url.startswith("http"):
            if not url.startswith("http"):
                url = "https://" + url
            subprocess.run(["open", url], capture_output=True)
            msg = f"Opened {url}."
            if speak_response: speak(msg)
            last_exchange["user"] = user_text
            last_exchange["assistant"] = msg
            return msg

    # NOTE: "google X" used to just open google.com — now falls through to
    # web_search.handle_web_search which actually returns an answer.
    # If the user really wants to OPEN Google, they can say "open google".

    # "search X on youtube"
    m = re.match(r"^(?:youtube|search youtube for|search youtube)\s+(.+)$", low)
    if m:
        q = urllib.parse.quote_plus(m.group(1).strip())
        subprocess.run(["open", f"https://youtube.com/results?search_query={q}"], capture_output=True)
        msg = "Searching YouTube."
        if speak_response: speak(msg)
        last_exchange["user"] = user_text
        last_exchange["assistant"] = msg
        return msg

    # ── Compose content in an app (write/create/draft X in Y) ────────────────
    # Catches: "open notes and write a poem about X"
    #          "write a poem about X in notes"
    #          "draft an email about X"
    # Generates content with Sonnet first, then opens the app and types it.
    # MUCH more reliable than asking the planner to do it in one shot.
    compose_match = None
    compose_app   = None
    compose_topic = None
    compose_kind  = "note"

    # Pattern A: "open <app> and (write|create|draft|compose) <kind> [about|on] <topic>"
    pa = re.match(
        r"^open\s+(?P<app>\w+)\s+and\s+"
        r"(?:write|create|draft|compose|make)\s+"
        r"(?:a\s+|an\s+|me\s+a\s+|me\s+an\s+)?"
        r"(?P<kind>\w+(?:\s+\w+)?)\s+"
        r"(?:about|on|for)\s+(?P<topic>.+)$",
        low
    )
    if pa:
        compose_match = pa
        compose_app   = pa.group("app").title()
        compose_kind  = pa.group("kind").strip()
        compose_topic = pa.group("topic").strip()

    # Pattern B: "write/create/draft <kind> about <topic> in <app>"
    if not compose_match:
        pb = re.match(
            r"^(?:write|create|draft|compose)\s+"
            r"(?:a\s+|an\s+|me\s+a\s+|me\s+an\s+)?"
            r"(?P<kind>\w+(?:\s+\w+)?)\s+"
            r"(?:about|on|for)\s+(?P<topic>.+?)\s+in\s+(?P<app>\w+)$",
            low
        )
        if pb:
            compose_match = pb
            compose_app   = pb.group("app").title()
            compose_kind  = pb.group("kind").strip()
            compose_topic = pb.group("topic").strip()

    if compose_match and compose_app and compose_topic:
        print(f"[compose] {compose_kind} about '{compose_topic[:40]}' in {compose_app}")

        # Map common app aliases
        app_aliases = {"Imessage": "Messages", "Browser": "Safari",
                       "Chrome": "Google Chrome", "Doc": "Pages", "Word": "Microsoft Word"}
        compose_app = app_aliases.get(compose_app, compose_app)

        # Decide model: Haiku for short stuff (haiku, tweet, message); Sonnet for longer creative
        is_short = any(s in compose_kind.lower() for s in
                       ["haiku", "tweet", "message", "text", "line", "title", "headline", "caption"])
        compose_model = "claude-haiku-4-5-20251001" if is_short else MODEL
        compose_max   = 200 if is_short else 600

        # 1. Generate content AND open app IN PARALLEL — saves ~1s of wall time
        content_holder = {"text": None, "error": None}

        def _generate():
            gen_prompt = (f"Write a {compose_kind} about: {compose_topic}\n\n"
                          "Output ONLY the content itself — no preamble, no title line, "
                          "no explanation, no markdown formatting (no #, *, _, etc). "
                          "Plain text ready to paste directly. "
                          "Keep it under 200 words unless the user clearly wants more.")
            try:
                gen_resp = client.messages.create(
                    model=compose_model, max_tokens=compose_max,
                    messages=[{"role": "user", "content": gen_prompt}]
                )
                content_holder["text"] = gen_resp.content[0].text.strip()
            except Exception as e:
                content_holder["error"] = str(e)

        gen_thread = threading.Thread(target=_generate, daemon=True)
        gen_thread.start()

        # Open the app while generation is running
        r = subprocess.run(["open", "-a", compose_app], capture_output=True, text=True, timeout=5)
        if r.returncode != 0:
            return f"Couldn't open {compose_app}. Tried but: {r.stderr.strip()[:80]}"
        if _ROLLBACK_AVAILABLE:
            _rollback.journal("app_opened", {"app": compose_app}, f"Opened {compose_app}")

        # Wait for generation to finish (was running in parallel with app open)
        gen_thread.join(timeout=20)

        if content_holder["error"]:
            return f"Couldn't generate the {compose_kind}: {content_holder['error']}"
        content = content_holder["text"]
        if not content:
            return f"Couldn't generate the {compose_kind}."

        # 2. Insert content using the fastest available method
        # fast_typing tries: native AppleScript API → AX-API → pasteboard+Cmd+V
        # Constant-time regardless of length, vs the old keystroke-per-char path
        # which took 1-3 seconds and often typed into the wrong field.
        if _FAST_TYPING_AVAILABLE:
            ok, method = fast_typing.insert_text(
                content, target_app=compose_app, fresh_doc=True
            )
            if ok:
                print(f"[compose] inserted via {method}")
                last_exchange["user"] = user_text
                last_exchange["assistant"] = f"Wrote {compose_kind} in {compose_app}"
                msg = f"Wrote your {compose_kind} in {compose_app}."
                if speak_response: speak(msg)
                return msg
            else:
                # Fast typing failed completely — fall through to the legacy
                # AppleScript keystroke path below as a last resort.
                print(f"[compose] fast_typing failed, trying legacy AppleScript")

        # ── Legacy fallback (only used if fast_typing isn't available or failed)
        safe_body  = content.replace("\\", "\\\\").replace('"', '\\"')
        scripts = []
        if compose_app == "Notes":
            scripts.append(
                f'tell application "Notes"\n'
                f'    activate\n'
                f'    make new note with properties {{body:"{safe_body}"}}\n'
                f'end tell'
            )
        elif compose_app == "TextEdit":
            scripts.append(
                f'tell application "TextEdit"\n'
                f'    activate\n'
                f'    make new document with properties {{text:"{safe_body}"}}\n'
                f'end tell'
            )
        else:
            new_doc_apps = {"Pages", "Microsoft Word", "Bear", "Drafts"}
            cmd_n_block = (
                'keystroke "n" using command down\n        delay 0.5\n        '
                if compose_app in new_doc_apps else ''
            )
            scripts.append(
                f'tell application "{compose_app}" to activate\n'
                f'delay 0.5\n'
                f'tell application "System Events"\n'
                f'    {cmd_n_block}'
                f'    keystroke "{safe_body}"\n'
                f'end tell'
            )

        success = False
        last_err = ""
        for script in scripts:
            r2 = subprocess.run(["osascript", "-e", script],
                                capture_output=True, text=True, timeout=20)
            if r2.returncode == 0:
                success = True
                break
            last_err = r2.stderr.strip()[:120]

        if not success:
            if "not authorized" in last_err.lower() or "1002" in last_err:
                return (f"Generated the {compose_kind} but couldn't type it — "
                        f"need Accessibility permission for your terminal. "
                        f"Here's what I wrote:\n\n{content}")
            return f"Couldn't write to {compose_app}: {last_err}\n\nContent:\n{content}"

        last_exchange["user"] = user_text
        last_exchange["assistant"] = f"Wrote {compose_kind} in {compose_app}"
        msg = f"Wrote your {compose_kind} in {compose_app}."
        if speak_response: speak(msg)
        return msg

    # "text X message" / "send X message" — AppleScript, no API
    m = re.match(r"^(?:text|send|message|imessage)\s+(\w+)\s+(?:saying\s+|that\s+)?(.+)$", user_text, re.IGNORECASE)
    if m:
        contact = m.group(1).strip()
        msg_txt = m.group(2).strip().strip('"\'')
        for name in [contact, contact.title()]:
            script = (f'tell application "Messages"\n'
                      f'    set b to buddy "{name}" of service "iMessage"\n'
                      f'    send "{msg_txt}" to b\n'
                      f'end tell')
            r = subprocess.run(["osascript", "-e", script],
                               capture_output=True, text=True, timeout=10)
            if r.returncode == 0:
                save_memory(f"Contact: {contact}", f"iMessage name: {name}",
                            ["contact", name.lower()], source="auto")
                msg = f"Sent to {name}."
                if speak_response: speak(msg)
                last_exchange["user"] = user_text
                last_exchange["assistant"] = msg
                return msg
        # Fall through to full pipeline if AppleScript fails

    # ── Fast definition / fact path (skips web search) ────────────────────────
    # For short "what is X" / "define X" / "who is X" questions where the topic
    # is 1-4 words, ask Haiku directly. ~1s instead of ~3s for a web search.
    # Skip if the query mentions live data (weather, price, news, current).
    m_def = re.match(
        r"^(?:what is|what's|whats|define|who is|who's)\s+(.+?)\??$",
        low
    )
    if m_def:
        topic = m_def.group(1).strip()
        topic_words = topic.split()
        # Strip leading "the/a/an"
        while topic_words and topic_words[0] in ("the", "a", "an"):
            topic_words = topic_words[1:]
        live_data_words = ("weather", "temperature", "price", "stock", "score",
                           "current", "today", "now", "latest", "news",
                           "exchange rate", "time in")
        is_live = any(w in low for w in live_data_words)
        # Block deictic / context-dependent questions — these need the screen,
        # not a definition. "what is this code", "whats this page", etc.
        deictic_blockers = ("this", "that", "it", "my", "the screen",
                            "this code", "this page", "this email")
        is_deictic_q = any(b in topic_words for b in deictic_blockers) \
                        or "this " in topic or topic.startswith("the ")
        # Block math-y queries — these belong to minutiae, not definitions
        is_math = any(c.isdigit() for c in topic) or "%" in topic
        if 1 <= len(topic_words) <= 4 and not is_live and not is_deictic_q \
           and not is_math:
            topic_clean = " ".join(topic_words)
            print(f"[handle] → fast definition for '{topic_clean}'")
            try:
                resp = client.messages.create(
                    model=FAST_MODEL, max_tokens=120,
                    messages=[{"role": "user", "content":
                        f"In 1 short sentence, plain text only, no markdown: "
                        f"what is {topic_clean}?"}]
                )
                msg = resp.content[0].text.strip()
                last_exchange["user"] = user_text
                last_exchange["assistant"] = msg
                if speak_response: speak(msg)
                return msg
            except Exception as e:
                print(f"[handle] fast definition failed: {e}, falling through")

    # ── CrewAI: multi-agent pipeline for complex tasks ───────────────────────
    if _CREW_AVAILABLE and is_complex_task(user_text):
        print(f"[crew] Complex task detected — launching multi-agent pipeline...")
        try:
            crew_result = build_crew(user_text)
            print(f"Alfred: {crew_result}")
            return crew_result
        except Exception as e:
            print(f"[crew] Pipeline failed: {e}, falling back to standard handler")

    # ── Existing shortcuts ────────────────────────────────────────────────────
    # Try capability handlers first (file ops, git, shell, clipboard, calendar, etc)
    if try_capability:
        print(f"[handle] checking capability handlers...")
        try:
            handled, result = try_capability(user_text, client, speak_response, speak)
            if handled:
                print(f"[handle] → capability matched")
                last_exchange["user"] = user_text
                last_exchange["assistant"] = result
                return result
        except Exception as e:
            print(f"[capability] error: {e}")

    # ── Proactive mute/unmute ─────────────────────────────────────────────────
    if _PROACTIVE_AVAILABLE:
        if any(p in low for p in ["be quiet", "stop interrupting", "shush",
                                   "don't interrupt", "silence", "mute yourself"]):
            msg = _proactive.mute(30)
            if speak_response: speak(msg)
            return msg
        if any(p in low for p in ["you can speak up", "start interrupting",
                                   "unmute", "you can talk"]):
            msg = _proactive.unmute()
            if speak_response: speak(msg)
            return msg

    # ── Morning briefing shortcut ─────────────────────────────────────────────
    # NOTE: "good morning" is handled as a greeting (above). For the actual
    # multi-agent briefing, user must say "morning briefing", "daily briefing",
    # "catch me up" etc. — explicit phrasing only.
    if _MULTI_AGENT_AVAILABLE and any(p in low for p in [
        "morning briefing", "start my day", "catch me up", "daily briefing"
    ]):
        speak_async("Pulling everything together, one moment.")
        result = morning_briefing(client, speak_fn=None)
        if result:
            last_exchange["user"] = user_text
            last_exchange["assistant"] = result
            if speak_response: speak(result[:500])  # speak first 500 chars
            return result

    if low in ["remember this","save that","remember that","save this"]:
        if last_exchange["user"]:
            auto_save_memory(last_exchange["user"], last_exchange["assistant"])
            msg = "Saved."
        else:
            msg = "Nothing to save."
        if speak_response: speak(msg)
        return msg

    if "memory stats" in low:
        stats = get_stats()
        msg = f"I've got {stats['total']} memories."
        if speak_response: speak(msg)
        return msg

    if any(t in low for t in ["no that's wrong","not like that","do it differently","that's not right"]):
        if last_exchange["user"]:
            save_correction(last_exchange["user"], user_text)
            msg = "Got it, noted."
        else:
            msg = "Noted."
        if speak_response: speak(msg)
        return msg

    mem_context = retrieve_relevant_memories(user_text)

    # Inject screen watcher context (current activity + learned habits)
    if _WATCHER_AVAILABLE:
        watch_ctx = _watcher.get_context()
        if watch_ctx:
            mem_context = (watch_ctx + "\n\n" + mem_context).strip() if mem_context else watch_ctx

    print(f"[handle] classifying with {'Ollama' if USE_OLLAMA else 'Claude'}...")
    resp = None
    # In silent (text bar) mode, use TEXT_SYSTEM which allows long answers.
    # Voice mode uses VOICE_SYSTEM for short spoken responses.
    # Build a personalized system prompt based on learned habits
    base_prompt = TEXT_SYSTEM if not speak_response else VOICE_SYSTEM
    if _WATCHER_AVAILABLE:
        try:
            habits = _watcher.get_habits_summary()
            if habits:
                personalization = f"\n\nUSER CONTEXT (learned from observation):\n{habits}\nUse this to anticipate needs, proactively suggest relevant help, and tailor response depth to their current focus state."
                sys_prompt = base_prompt + SYSTEM_PROMPT_PERSONALIZATION + personalization
            else:
                sys_prompt = base_prompt + SYSTEM_PROMPT_PERSONALIZATION
        except Exception:
            sys_prompt = base_prompt + SYSTEM_PROMPT_PERSONALIZATION
    else:
        sys_prompt = base_prompt + SYSTEM_PROMPT_PERSONALIZATION
    max_tok = 2000 if not speak_response else 200

    # Detect long-form content requests. JSON wrapping breaks for these
    # because the answer overflows max_tokens mid-string and json.loads fails.
    # For these, do a direct prompt with no JSON envelope.
    long_form_triggers = [
        "write me a", "write an essay", "write a", "draft", "compose",
        "explain in detail", "explain how", "tell me a story",
        "give me a long", "essay on", "paragraphs about",
        "step by step", "in depth", "comprehensive",
    ]
    is_long_form = (not speak_response) and any(
        t in user_text.lower() for t in long_form_triggers
    )

    if is_long_form:
        print(f"[handle] long-form direct (skip JSON envelope)")
        try:
            msgs = conversation_history[-6:] + [{"role": "user",
                "content": (mem_context+"\n\n" if mem_context else "") + user_text}]
            direct_resp = client.messages.create(
                model=FAST_MODEL,
                max_tokens=2500,
                system=("You are Alfred, your employer's personal assistant rendered in a text bar. "
                        "Conduct yourself as a composed British butler — formal, direct, and unhurried. "
                        "Address the user as 'sir' unless context indicates otherwise. "
                        "The user is reading your output. Markdown is supported. "
                        "Answer at whatever length the question genuinely requires. "
                        "Do not pad. Do not preface. Begin with the substance.")
                        + SYSTEM_PROMPT_PERSONALIZATION,
                messages=msgs,
            )
            answer = direct_resp.content[0].text.strip()
            conversation_history.append({"role":"user","content":user_text})
            conversation_history.append({"role":"assistant","content":answer})
            save_conversation(conversation_history)
            last_exchange["user"] = user_text
            last_exchange["assistant"] = answer
            return answer
        except Exception as e:
            print(f"[handle] long-form direct failed: {e}, falling through to classify")

    for attempt in range(3):
        try:
            msgs = conversation_history[-6:] + [{"role":"user",
                "content": (mem_context+"\n\n" if mem_context else "") + user_text}]
            resp = _client_for("classify").messages.create(
                model=FAST_MODEL, max_tokens=max_tok,
                system=sys_prompt, messages=msgs)
            break
        except anthropic.APIStatusError as e:
            if e.status_code == 529 and attempt < 2:
                print(f"[classify] API overloaded, retry {attempt+1}/2...")
                time.sleep(1.5 * (attempt + 1))
                continue
            raise
    try:
        if resp is None:
            raise Exception("No response after retries")
        raw = resp.content[0].text.strip()
        # Strip surrounding code fences if present. .strip("```json") would
        # strip ANY of those chars from the ends, eating leading j/s/o/n!
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw).strip()
        print(f"[classify] {raw[:100]}")
        try:
            parsed = json.loads(raw) if raw else {"task":False,"speak":"Say that again?"}
        except Exception:
            parsed = {"task":False,"speak": raw if raw else "Say that again?"}
    except Exception as e:
        print(f"[classify error] {e}")
        parsed = {"task":False,"speak":"Something went wrong."}

    speak_text = parsed.get("speak","")
    is_task    = parsed.get("task", False)

    # Auto-retry via search: if the model returned a "I don't have access to
    # real-time / live data / cutoff" answer for what looks like a factual
    # query, try the search path before giving up. This catches queries that
    # didn't match our static trigger lists (e.g. "bitcoin highest in 2026").
    refusal_phrases = [
        "i don't have access to real-time",
        "i don't have access to live",
        "i don't have access to current",
        "i don't have real-time",
        "my training cutoff",
        "training data only",
        "i can't access",
        "i'm not able to access",
        "without access to",
    ]
    if (not is_task and speak_text
            and any(p in speak_text.lower() for p in refusal_phrases)):
        print(f"[handle] LLM refused (no live data) — retrying via search")
        try:
            from web_search import handle_web_search
            search_result = handle_web_search(
                user_text, _client_for("search"),
                sources_cb=getattr(__import__("capabilities"), "_record_sources", None),
            )
            if search_result and len(search_result) > 50:
                speak_text = search_result
        except Exception as e:
            print(f"[handle] search retry failed: {e}")
    conversation_history.append({"role":"user","content":user_text})
    conversation_history.append({"role":"assistant","content":speak_text})
    save_conversation(conversation_history)

    if speak_response and speak_text:
        speak_async(speak_text)

    if is_task:
        # Block the agentic clicker (run_vision_task, which clicks around)
        # for code-edit queries. These should never trigger the clicker —
        # the user wants the model to READ the code and produce a fix, not
        # click on buttons. If we hit this case it usually means the query
        # came through the typed-input path without chip context.
        ut_low = user_text.lower()
        is_code_fix_query = any(k in ut_low for k in [
            "fix the bug", "fix bugs", "fix the code", "fix this code",
            "fix it in", "do the fixes", "apply the fix", "apply the fixes",
            "correct the code", "complete the code", "rewrite the code",
            "refactor the code", "in vscode", "in vs code", "in cursor",
        ])
        if is_code_fix_query:
            print(f"[task] blocking clicker - routing code-fix to read-only vision")
            try:
                # Take a screenshot of the user's screen and ask Sonnet to fix
                img = screenshot_b64()
                if img:
                    fix_prompt = (
                        f"{user_text}\n\n"
                        f"You are looking at the user's screen which shows their "
                        f"code editor. Your output will be pasted DIRECTLY into the "
                        f"editor as a complete file replacement (Cmd+A then paste).\n\n"
                        f"OUTPUT FORMAT (strict):\n"
                        f"1. ONE short sentence describing what was wrong (max 20 words)\n"
                        f"2. A SINGLE fenced code block containing the ENTIRE FILE.\n\n"
                        f"CRITICAL RULES:\n"
                        f"- Output the WHOLE file from line 1 to the last line.\n"
                        f"- Include ALL imports, ALL classes, ALL functions, ALL existing code.\n"
                        f"- Keep code that wasn't broken — don't omit anything.\n"
                        f"- NEVER use comments like '# ... rest of code unchanged'.\n"
                        f"- NEVER use ellipsis (...) to indicate skipped code.\n"
                        f"- NEVER output just the fixed function — output the COMPLETE FILE.\n"
                        f"- The code block must be a 100% drop-in replacement that runs as-is.\n\n"
                        f"If the file is too long to read all of it from the screenshot, "
                        f"say so honestly instead of writing a partial version."
                    )
                    cv_resp = client.messages.create(
                        model="claude-sonnet-4-6",
                        max_tokens=4000,
                        messages=[{"role": "user", "content": [
                            {"type": "image", "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": img,
                            }},
                            {"type": "text", "text": fix_prompt},
                        ]}],
                    )
                    answer = cv_resp.content[0].text.strip()
                    last_exchange = {"user": user_text, "assistant": answer}
                    return answer
            except Exception as e:
                print(f"[task] code-fix vision failed: {e}")

        if speak_response: time.sleep(0.8)
        result = run_task(user_text)
        last_exchange = {"user":user_text,"assistant":result}
        if speak_response and result: speak(result)
        # Only auto-save if the result is substantial (not just "Done.")
        if result and result not in ["Done.", "Opening.", "Opened."] and len(result) > 15:
            auto_save_memory(user_text, result)
        return result or "Done."
    else:
        last_exchange = {"user":user_text,"assistant":speak_text}
        return speak_text

def process_command(user_text: str):
    _handle_command(user_text, speak_response=True)

def process_command_text(user_text: str) -> str:
    return _handle_command(user_text, speak_response=False)

# ── Text bar (native Swift app) ───────────────────────────────────────────────
_bar_proc = None

def start_bar():
    """Launch the native Swift AlfredBar app. It handles Cmd+Shift+J internally."""
    global _bar_proc

    # Path to the compiled Swift binary
    bar_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "AlfredBar")
    bar_bin = os.path.join(bar_dir, "AlfredBar")
    bar_src = os.path.join(bar_dir, "main.swift")

    # Compile if needed
    if not os.path.exists(bar_bin):
        if not os.path.exists(bar_src):
            print(f"[bar] Swift source not found at {bar_src}")
            print("[bar] Download AlfredBar/main.swift and place it next to assistant.py")
            return
        print("[bar] Compiling AlfredBar (one time)...")
        r = subprocess.run(["swiftc", "-O", "-o", bar_bin, bar_src,
                            "-framework", "Cocoa", "-framework", "Carbon"],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print(f"[bar] Compile failed:\n{r.stderr}")
            return
        print("[bar] Compiled successfully.")

    # Launch
    _bar_proc = subprocess.Popen([bar_bin])
    print("[bar] AlfredBar running. Press Cmd+Shift+J anywhere.")

# ── Background threads ────────────────────────────────────────────────────────
def watch_text_trigger():
    """Legacy file-polling fallback — kept for backward compat with old bar.
    The new bar uses the UDS IPC server (run_ipc_server) which is much faster."""
    trigger = str(config.IPC_TRIGGER)
    while True:
        time.sleep(0.3)
        if os.path.exists(trigger):
            try:
                with open(trigger) as f:
                    text = f.read().strip()
                os.unlink(trigger)
                if text:
                    print(f"[text] {text}")
                    result = process_command_text(text)
                    with open(str(config.IPC_RESPONSE), "w") as f:
                        f.write(result or "Done.")
                    # Also print to terminal so the user sees it
                    if result:
                        print(f"Alfred: {result}\n")
            except Exception as e:
                print(f"Text trigger error: {e}")


async def _stream_to_channel(client, model: str, messages: list, channel,
                              max_tokens: int = 600, system: str = None) -> str:
    """
    Stream a Claude response, pushing each chunk to the bar via channel.delta()
    so the user sees text appear word-by-word. Returns the full final text.
    Returns empty string on stream failure (caller should fall back).
    """
    import asyncio as _asyncio
    loop = _asyncio.get_event_loop()
    full_text = []
    stream_failed = [False]
    error_msg = [""]

    def _do_stream():
        kwargs = {"model": model, "max_tokens": max_tokens, "messages": messages}
        if system: kwargs["system"] = system
        try:
            with client.messages.stream(**kwargs) as stream:
                for chunk in stream.text_stream:
                    if not chunk: continue
                    full_text.append(chunk)
                    fut = _asyncio.run_coroutine_threadsafe(
                        channel.delta(chunk), loop
                    )
                    try: fut.result(timeout=2)
                    except Exception: pass
        except Exception as e:
            stream_failed[0] = True
            error_msg[0] = str(e)[:200]
            print(f"[stream] FAILED: {error_msg[0]}")

    await loop.run_in_executor(None, _do_stream)
    answer = "".join(full_text).strip()
    if stream_failed[0]:
        # Don't push partial+error to the bar — let caller fall back instead
        return ""
    await channel.done(final_text=answer)
    return answer


def run_ipc_server():
    """
    Run the UDS IPC server in a background thread with its own asyncio loop.
    The Swift bar connects to /tmp/alfred.sock and streams queries/responses.
    """
    if not _IPC_AVAILABLE:
        print("[ipc] not available, skipping")
        return

    import asyncio
    try:
        from user_profile import (
            needs_onboarding, get_onboarding_step, get_question,
            handle_onboarding_answer, extract_and_update, load_profile_text,
        )
        _profile_available = True
    except ImportError:
        _profile_available = False

    # Onboarding state per session (not per connection — survives bar close/reopen)
    _onboard = {"active": _profile_available and needs_onboarding(),
                "step": None}
    if _onboard["active"]:
        _onboard["step"] = get_onboarding_step() if _profile_available else None
        print(f"[profile] first launch — onboarding at step: {_onboard['step']}")

    # ── Session memory: inject last exchange into system prompt ───────────────
    if _SESSION_MEMORY_AVAILABLE:
        try:
            _last = _load_last_exchange()
            if _last:
                _session_note = (
                    f"\n\nPREVIOUS SESSION CONTEXT:\n"
                    f"In the previous session, the user asked: {_last['user']}\n"
                    f"Alfred responded: {_last['assistant']}\n"
                    f"Use this to maintain continuity — if the user references something "
                    f"from before or picks up mid-thought, you have context."
                )
                global SYSTEM_PROMPT_PERSONALIZATION
                SYSTEM_PROMPT_PERSONALIZATION = _session_note + SYSTEM_PROMPT_PERSONALIZATION
                print(f"[session_memory] Loaded last exchange from previous session")
        except Exception as _e:
            print(f"[session_memory] Failed to inject previous session: {_e}")

    async def on_connect(channel):
        """Send onboarding question when bar opens (if needed)."""
        if not _onboard["active"] or not _profile_available:
            return
        question = get_question(_onboard["step"])
        await channel.delta(question)
        await channel.done(final_text=question)

    # ── Inline calculator helpers ─────────────────────────────────────────────

    def _try_inline_calc(text: str):
        """Return a result string if text is a math expr or unit conversion; else None."""
        import ast, operator, re as _re
        t = text.strip()

        # Unit conversions
        conv = _re.match(
            r'^([\d.]+)\s*(kg|lbs?|lb|pounds?|miles?|km|kilometers?|°?f|fahrenheit|°?c|celsius|cm|in|inches?|oz|ounces?|g|grams?)\s+(?:in|to|into|as)\s+(kg|lbs?|lb|pounds?|miles?|km|kilometers?|°?f|fahrenheit|°?c|celsius|cm|in|inches?|oz|ounces?|g|grams?)$',
            t, _re.IGNORECASE
        )
        if conv:
            val, src, dst = float(conv.group(1)), conv.group(2).lower(), conv.group(3).lower()
            def n(u): return u.rstrip('s').rstrip('.')
            src, dst = n(src), n(dst)
            conversions = {
                ('kg','lb'): val*2.20462, ('lb','kg'): val/2.20462,
                ('km','mile'): val*0.621371, ('mile','km'): val/0.621371,
                ('cm','in'): val/2.54, ('in','cm'): val*2.54,
                ('oz','g'): val*28.3495, ('g','oz'): val/28.3495,
            }
            # Celsius/Fahrenheit special
            if src in ('c','celsius','°c') and dst in ('f','fahrenheit','°f'):
                result = val * 9/5 + 32
                return f"{val}°C = {result:.2f}°F"
            if src in ('f','fahrenheit','°f') and dst in ('c','celsius','°c'):
                result = (val - 32) * 5/9
                return f"{val}°F = {result:.2f}°C"
            key = (src, dst)
            if key in conversions:
                unit_name = dst if not dst.endswith('e') else dst
                return f"{val} {src} = {conversions[key]:.4g} {dst}"

        # Pure math: only digits, operators, parens, spaces
        if _re.match(r'^[\d\s\.\+\-\*\/\(\)\%\^]+$', t):
            try:
                # Replace ^ with ** for exponentiation
                expr = t.replace('^', '**')
                # Safe eval with no builtins
                tree = ast.parse(expr, mode='eval')
                allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num,
                           ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod,
                           ast.Pow, ast.USub, ast.UAdd, ast.Constant, ast.FloorDiv)
                if all(isinstance(node, allowed) for node in ast.walk(tree)):
                    result = eval(compile(tree, '<string>', 'eval'))
                    # Format: no trailing zeros for integers
                    if isinstance(result, float) and result.is_integer():
                        return str(int(result))
                    return str(round(result, 8)).rstrip('0').rstrip('.')
            except Exception:
                pass
        return None

    # ── Image generation helper ───────────────────────────────────────────────

    async def _generate_image(prompt: str, channel) -> bool:
        """Generate image via DALL-E 3, save locally, stream markdown back. Returns True on success."""
        import urllib.request, os, time as _time
        try:
            from openai import OpenAI as _OAI
            _oai = _OAI()  # uses OPENAI_API_KEY env var
        except Exception as e:
            await channel.delta(f"Image generation requires OpenAI API key: {e}")
            await channel.done(final_text="")
            return True

        await channel.status("generating image…")
        try:
            response = _oai.images.generate(
                model="dall-e-3",
                prompt=prompt,
                size="1024x1024",
                quality="standard",
                n=1,
            )
            img_url = response.data[0].url
            # Save to ~/.alfred/generated/
            save_dir = os.path.expanduser("~/.alfred/generated")
            os.makedirs(save_dir, exist_ok=True)
            filename = f"img_{int(_time.time())}.png"
            save_path = os.path.join(save_dir, filename)
            urllib.request.urlretrieve(img_url, save_path)
            reply = f"![Generated image](file://{save_path})\n\n*Prompt: {prompt}*"
            await channel.delta(reply)
            await channel.done(final_text=reply)
            return True
        except Exception as e:
            print(f"[img_gen] failed: {e}")
            return False

    async def query_handler(text: str, channel, context: dict = None, attachments: list = None):
        """
        Bridge: receive a query from the bar, run the existing handler,
        and stream back the result.

        Includes a watchdog that pushes periodic status messages so long
        operations feel alive instead of frozen.
        """
        # ── Onboarding intercept ──────────────────────────────────────────────
        if _onboard["active"] and _profile_available and _onboard["step"] not in (None, "done"):
            reply = handle_onboarding_answer(_onboard["step"], text)
            next_step = get_onboarding_step()
            _onboard["step"] = next_step
            if next_step == "done":
                _onboard["active"] = False
                # Reload profile so it's injected into future prompts
                _load_user_profile()
                print("[profile] onboarding complete — profile loaded")
            await channel.delta(reply)
            await channel.done(final_text=reply)
            return

        # ── Passive profile extraction ────────────────────────────────────────
        if _profile_available:
            try:
                if extract_and_update(text):
                    _load_user_profile()  # refresh personalization
            except Exception:
                pass

        t0 = time.time()
        # Tell the proactive thread to shut up while we're working
        if _PROACTIVE_AVAILABLE:
            try: _proactive.set_busy(True)
            except Exception: pass

        # Watchdog: every 5s, if we're still running, push a "still working" hint.
        # Skips itself if there's already been a delta (real content streaming).
        async def _watchdog():
            messages = [
                "thinking...",
                "still working...",
                "this is taking a moment...",
                "almost there...",
                "complex query — bear with me...",
            ]
            for i, msg in enumerate(messages):
                await asyncio.sleep(5)
                # Stop if the channel has already pushed real text
                if getattr(channel, "_delta_count", 0) > 0:
                    return
                try:
                    await channel.status(msg)
                except Exception:
                    return

        # Capture answer text for followups by intercepting channel.delta
        captured_text = []
        original_delta = channel.delta
        async def _capture_delta(text):
            captured_text.append(text)
            await original_delta(text)
        channel.delta = _capture_delta
        original_done = channel.done
        captured_final = [""]
        async def _capture_done(final_text="", usage=None, model=""):
            if final_text:
                captured_final[0] = final_text
            try:
                # Some Channel.done implementations don't accept model param
                await original_done(final_text=final_text, usage=usage, model=model)
            except TypeError:
                await original_done(final_text=final_text, usage=usage)
        channel.done = _capture_done

        watchdog_task = asyncio.create_task(_watchdog())
        try:
            await _query_handler_inner(text, channel, context, t0, attachments=attachments or [])
        finally:
            watchdog_task.cancel()
            try:
                await watchdog_task
            except asyncio.CancelledError:
                pass
            if _PROACTIVE_AVAILABLE:
                try: _proactive.set_busy(False)
                except Exception: pass

            # Persist this exchange to session memory for next startup
            if _SESSION_MEMORY_AVAILABLE:
                try:
                    _final_for_mem = captured_final[0] or "".join(captured_text)
                    if text and _final_for_mem:
                        _save_exchange(text, _final_for_mem)
                except Exception as _me:
                    print(f"[session_memory] save failed: {_me}")

            # After the response is fully sent, generate and push followups.
            # Skip for trivial answers (greetings, math, errors).
            if _FOLLOWUPS_AVAILABLE:
                final_answer = captured_final[0] or "".join(captured_text)
                if _followups.should_suggest(text, final_answer):
                    try:
                        chips = _followups.suggest(text, final_answer, client)
                        if chips:
                            await channel.followups(chips)
                    except Exception as e:
                        print(f"[followups] failed: {e}")

            # Surface any sources the search agent collected
            try:
                from capabilities import get_recent_sources
                srcs = get_recent_sources()
                if srcs:
                    await channel.sources(srcs)
            except Exception as e:
                print(f"[sources] failed: {e}")

    class _NullChannel:
        """A Channel-compatible sink that collects text but doesn't send to UDS.
        Used when running a query in the background — there's no live bar to
        stream to, but we still want to capture the answer for later retrieval.
        """
        def __init__(self):
            self.collected_text = ""
        async def delta(self, text: str):
            self.collected_text += text
        async def done(self, final_text: str = "", usage: dict = None):
            if final_text and len(final_text) > len(self.collected_text):
                self.collected_text = final_text
        async def error(self, message: str):
            self.collected_text += f"\n[error] {message}"
        async def status(self, label: str):
            pass
        async def tool_call(self, name: str, args: dict = None):
            pass
        async def tool_done(self, name: str, result: str = ""):
            pass
        async def followups(self, chips: list):
            pass
        async def sources(self, urls: list):
            pass

    async def _query_handler_inner(text: str, channel, context: dict, t0: float,
                                    attachments: list = None):
        context = context or {}
        attachments = attachments or []
        app = context.get("app", "")
        category = context.get("category", "")
        selection = context.get("selection") or ""
        url = context.get("url") or ""
        screenshot = context.get("screenshot") or ""
        window_title = context.get("title", "") or ""

        if app:
            print(f"[ipc] ▶ query: {text[:60]} (in {app}/{category})")
        else:
            print(f"[ipc] ▶ query: {text[:80]}")

        # ── Background task status check ──────────────────────────────────
        # "what did you find?", "show my background tasks", etc.
        if _BG_AVAILABLE and _bg.is_status_query(text):
            summary = _bg.get_summary()
            await channel.delta(summary)
            await channel.done(final_text=summary)
            print(f"[ipc] ◀ bg-status done in {time.time()-t0:.2f}s")
            return

        # "show task <id>" — open a specific task result
        m_show = re.match(r"^show task ([a-f0-9]{6})$", text.lower().strip())
        if _BG_AVAILABLE and m_show:
            tid = m_show.group(1)
            rec = _bg._tasks.get(tid)
            if rec:
                rec["consumed"] = True
                if rec["status"] == "done":
                    out = rec["result"] or "(empty)"
                elif rec["status"] == "error":
                    out = f"Task failed: {rec['error']}"
                else:
                    out = f"Still running ({int(time.time()-rec['started_at'])}s elapsed)"
                await channel.delta(out)
                await channel.done(final_text=out)
            else:
                msg = f"No task with id `{tid}`."
                await channel.delta(msg); await channel.done(final_text=msg)
            print(f"[ipc] ◀ task-show done in {time.time()-t0:.2f}s")
            return

        # ── Feature 1: Inline calculator (no AI needed) ───────────────────
        # Intercept pure math expressions and common unit conversions before
        # sending to Claude so they resolve instantly and cost zero tokens.
        _calc_result = _try_inline_calc(text)
        if _calc_result is not None:
            await channel.delta(f"**{_calc_result}**")
            await channel.done(final_text=_calc_result)
            print(f"[ipc] ◀ inline-calc: {_calc_result}")
            return

        # ── Feature 2: Image generation (/img prefix) ─────────────────────
        if text.lower().startswith("/img "):
            img_prompt = text[5:].strip()
            if img_prompt:
                img_result = await _generate_image(img_prompt, channel)
                if img_result:
                    return
            # fall through to Claude if generation failed or prompt empty

        # ── Background task spawn ──────────────────────────────────────────
        # "in the background, find me ...", "while I work, research ..."
        if _BG_AVAILABLE:
            is_bg, bg_text = _bg.is_background_request(text)
            if is_bg:
                # Spawn the same handler recursively, but in a detached task,
                # streaming to a NULL channel (so it doesn't try to push to
                # the bar that's already moved on).
                async def _bg_runner() -> str:
                    null_channel = _NullChannel()
                    null_t0 = time.time()
                    # Re-enter the inner handler with the cleaned text
                    try:
                        await _query_handler_inner(
                            bg_text, null_channel, context, null_t0,
                        )
                    except Exception as e:
                        return f"Error: {e}"
                    raw = null_channel.collected_text or "(no output)"
                    # Pretty-format the result if it's a long blob
                    if _FORMATTER_AVAILABLE and len(raw) > 200:
                        try:
                            raw = _formatter.format_research(raw, bg_text, client)
                        except Exception as e:
                            print(f"[bg] formatting failed: {e}")
                    return raw

                loop = asyncio.get_event_loop()
                task_id = _bg.spawn(bg_text, _bg_runner, loop=loop)
                msg = (f"Got it — running that in the background "
                       f"(task `{task_id}`). I'll show you results next time you "
                       f"open the bar, or ask 'what did you find?' anytime.")
                await channel.delta(msg)
                await channel.done(final_text=msg)
                print(f"[ipc] ◀ bg-spawned [{task_id}] in {time.time()-t0:.2f}s")
                return

        # ── Attachment path (images, files, URLs dropped/pasted into bar) ──
        if attachments:
            import base64
            content_blocks = []
            extra_text_parts = []

            for att in attachments:
                kind = att.get("kind", "")
                if kind == "image":
                    b64 = att.get("data", "")
                    mime = att.get("mime", "image/png")
                    name = att.get("name", "image")
                    if b64:
                        content_blocks.append({
                            "type": "image",
                            "source": {"type": "base64", "media_type": mime, "data": b64}
                        })
                        print(f"[attach] image: {name} ({len(b64)//1000}KB b64)")
                elif kind == "file":
                    path = att.get("path", "")
                    name = att.get("name", "")
                    if path and os.path.exists(path):
                        try:
                            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                                file_text = fh.read(20000)
                            ext = os.path.splitext(path)[1].lstrip(".") or "text"
                            extra_text_parts.append(
                                f"=== Attached file: {name} ===\n```{ext}\n{file_text}\n```"
                            )
                            print(f"[attach] file: {name} ({len(file_text)} chars)")
                        except Exception as e:
                            extra_text_parts.append(f"[Could not read {name}: {e}]")
                    else:
                        extra_text_parts.append(f"[File not found: {path}]")
                elif kind == "url":
                    url_str = att.get("url", "")
                    if url_str:
                        try:
                            from web_search import fetch_page
                            page = fetch_page(url_str, max_chars=6000)
                            if page and len(page.strip()) > 100:
                                extra_text_parts.append(
                                    f"=== Content from {url_str} ===\n{page.strip()[:5500]}"
                                )
                                print(f"[attach] url fetched: {url_str[:60]}")
                            else:
                                extra_text_parts.append(f"URL: {url_str} (could not fetch content)")
                        except Exception as e:
                            extra_text_parts.append(f"URL: {url_str} (fetch error: {e})")

            if content_blocks or extra_text_parts:
                user_text_block = text
                if extra_text_parts:
                    user_text_block = text + "\n\n" + "\n\n".join(extra_text_parts)
                content_blocks.append({"type": "text", "text": user_text_block})
                msgs = conversation_history[-4:] + [{"role": "user", "content": content_blocks}]
                try:
                    answer = await _stream_to_channel(
                        client, "claude-sonnet-4-6", msgs, channel, max_tokens=1500,
                        system=(
                            "You are Alfred, a helpful assistant. The user has attached "
                            "one or more items. Analyze them and answer the user's question "
                            "directly. Be concise unless depth is clearly needed."
                        )
                    )
                    if not answer or len(answer.strip()) < 10:
                        resp = client.messages.create(
                            model="claude-sonnet-4-6", max_tokens=1500, messages=msgs,
                        )
                        answer = resp.content[0].text.strip()
                        if answer:
                            await channel.delta(answer)
                            await channel.done(final_text=answer)
                    if answer:
                        elapsed = time.time() - t0
                        print(f"[ipc] ◀ attachment-vision done in {elapsed:.2f}s")
                        conversation_history.append({"role": "user", "content": text})
                        conversation_history.append({"role": "assistant", "content": answer})
                        save_conversation(conversation_history)
                        return
                except Exception as e:
                    print(f"[attach] failed: {e}")
                    import traceback; traceback.print_exc()

        # Try to read the actual file the user has open in their code editor.
        # This bypasses vision entirely and gives us the COMPLETE source code
        # — no scroll position issues, no token limits.
        actual_file_content = ""
        actual_file_path = ""
        if category == "code" and window_title:
            actual_file_content, actual_file_path = _resolve_open_file(
                app, window_title
            )
            if actual_file_content:
                print(f"[code-file] resolved {actual_file_path} "
                      f"({len(actual_file_content)} chars)")

        # Determine if this query wants screen context
        chip_keywords = ["explain this", "find bugs", "refactor",
                         "summarize this", "summarize page", "key takeaways",
                         "make the selected", "rewrite the selected",
                         "explain output", "fix this error", "critique"]
        deictic_keywords = [
            # "what's on my screen" family
            "what's on my screen", "what is on my screen", "whats on my screen",
            "what am i looking at", "what do you see", "look at my screen",
            "see my screen", "read my screen", "view my screen",
            # generic "this/that"
            "what's this", "what is this", "whats this",
            "what does this say", "what does it say", "what's that", "whats that",
            # subject-specific deictics
            "this code", "this page", "this email", "this error", "this design",
            "this document", "this article", "this image",
            # "the X" forms (context infers it)
            "the code", "the page", "the email", "the error", "the document",
            "the article", "the screen", "the output", "the file",
            # action verbs with implicit "what's on screen"
            "summarize the", "explain the", "fix the", "translate the",
            "summarize what", "explain what",
            # other common phrasings
            "fix this", "explain this", "translate this", "summarize this",
            "what's wrong", "whats wrong", "what's happening", "whats happening",
            "help me with this",
        ]

        is_chip = any(k in text.lower() for k in chip_keywords)
        is_deictic = any(k in text.lower() for k in deictic_keywords)
        wants_screen = (is_chip or is_deictic) and screenshot \
                       and os.path.exists(screenshot)

        # For code editors (VS Code, Cursor — Electron-based), AX-API and the
        # Cmd+C trick BOTH fail because Monaco/CodeMirror intercept events.
        # Force vision path for code-editor chips so we can actually see code.
        if is_chip and category == "code" and screenshot and os.path.exists(screenshot):
            wants_screen = True
            selection = ""

        # If we have a chip query but no app context (unknown), we lost focus
        # tracking — but we still have a screenshot. Force vision rather than
        # routing to a wrong handler that will hallucinate "I don't see a page".
        if is_chip and category == "unknown" and screenshot and os.path.exists(screenshot):
            print(f"[ipc] no context but screenshot exists → forcing vision")
            wants_screen = True
            selection = ""

        # ── Browser URL fetch path (PREFERRED for browser context) ────────
        # Streams tokens via UDS so the bar fills in word-by-word.
        # Sites that aggressively block scraping OR are JS-only (page text
        # has nothing useful) — don't bother fetching, screenshot instead.
        SCRAPE_BLOCKED = (
            # Paywalled / cookie-walled news
            "cnn.com", "nytimes.com", "wsj.com", "ft.com", "bloomberg.com",
            "washingtonpost.com", "economist.com", "newyorker.com",
            "barrons.com", "reuters.com/article", "medium.com",
            # JS-only social
            "linkedin.com", "twitter.com", "x.com", "facebook.com",
            "instagram.com",
            # Video / streaming (fetched HTML has no transcript)
            "youtube.com", "youtu.be", "vimeo.com", "twitch.tv",
            "netflix.com", "hulu.com", "disneyplus.com", "primevideo.com",
            # SaaS apps that are JS-only
            "docs.google.com", "sheets.google.com", "slides.google.com",
            "notion.so", "figma.com", "miro.com",
            # SPA hosting platforms — these ALWAYS serve a JS shell
            ".vercel.app", ".netlify.app", ".pages.dev",
            ".herokuapp.com", ".fly.dev", ".replit.app",
            ".streamlit.app", ".render.com",
        )
        url_blocked = url and any(d in url.lower() for d in SCRAPE_BLOCKED)

        if (is_chip or is_deictic) and url and category == "browser" and not url_blocked:
            print(f"[fetch] grabbing page text: {url}")
            page = ""
            try:
                from web_search import fetch_page
                page = fetch_page(url, max_chars=8000)
            except Exception as e:
                print(f"[fetch] failed: {e}, falling back to vision")

            page_text = (page or "").strip()
            paywall_markers = [
                "subscribe to read", "sign in to continue", "create a free account",
                "enable javascript", "enable cookies", "please verify you are",
                "cloudflare", "access denied", "you have been blocked",
                "subscribe now", "this content is for subscribers",
                "please disable your ad blocker",
                # Ad/redirect tracker pages
                "redirecting", "you are being redirected", "checking your browser",
                "advertisement", "loading...", "please wait",
            ]
            looks_walled = any(m in page_text.lower()[:2000] for m in paywall_markers)
            too_short = len(page_text) < 600
            # Heuristic: if we got SOMETHING but it's mostly navigation noise
            # (lots of short sentences, few real words), treat as useless.
            words = page_text.split()
            avg_word_len = sum(len(w) for w in words) / max(1, len(words))
            looks_navy = len(words) > 50 and avg_word_len < 4.0
            useful = (bool(page_text) and not too_short
                      and not looks_walled and not looks_navy)

            if useful:
                try:
                    prompt = (
                        f"{text}\n\n"
                        f"Content from this page ({url}):\n"
                        f"{page_text[:7500]}\n\n"
                        f"Answer concisely. Plain text, no markdown headers."
                    )
                    msgs = conversation_history[-6:] + [
                        {"role": "user", "content": prompt}
                    ]
                    answer = await _stream_to_channel(
                        client, FAST_MODEL, msgs, channel, max_tokens=600
                    )
                    # If streaming failed (returns ""), retry once non-streaming
                    # which often works when stream API hits transient 5xx
                    if not answer or len(answer.strip()) < 30:
                        print(f"[fetch] stream gave nothing, trying non-stream retry")
                        try:
                            resp = client.messages.create(
                                model=FAST_MODEL, max_tokens=600,
                                messages=msgs,
                            )
                            answer = resp.content[0].text.strip()
                            if answer and len(answer) > 30:
                                # Push the whole thing as one delta+done
                                await channel.delta(answer)
                                await channel.done(final_text=answer)
                        except Exception as e:
                            print(f"[fetch] non-stream retry also failed: {e}")
                            answer = ""

                    if answer and len(answer.strip()) > 30:
                        elapsed = time.time() - t0
                        print(f"[ipc] ◀ url-fetch done in {elapsed:.2f}s")
                        conversation_history.append({"role":"user","content":text})
                        conversation_history.append({"role":"assistant","content":answer})
                        save_conversation(conversation_history)
                        return
                    else:
                        print(f"[fetch] both stream and non-stream failed, falling to vision")
                except Exception as e:
                    print(f"[fetch] outer exception: {e}, falling to vision")
            else:
                if looks_walled:
                    print(f"[fetch] paywall/cookie-wall detected, falling to vision")
                else:
                    print(f"[fetch] page returned only {len(page_text)} chars, falling to vision")
        elif url_blocked:
            # Special handling for video sites: try the YouTube transcript API
            # first (works with no API key), fall back to the workaround msg
            # if the video has no captions.
            url_low = (url or "").lower()
            VIDEO_SITES = ("youtube.com", "youtu.be", "vimeo.com",
                           "twitch.tv", "netflix.com", "hulu.com",
                           "disneyplus.com", "primevideo.com")
            is_video = any(d in url_low for d in VIDEO_SITES)
            is_youtube = "youtube.com" in url_low or "youtu.be" in url_low

            if is_youtube:
                # Try to fetch the transcript via youtube-transcript-api
                try:
                    from youtube_transcript import extract_video_id, fetch_transcript, format_with_timestamps
                    vid = extract_video_id(url)
                    if vid:
                        print(f"[youtube] fetching transcript for {vid}")
                        result = fetch_transcript(vid)
                        if result and result.get("text"):
                            full_text = result["text"]
                            print(f"[youtube] got {len(full_text)} chars of transcript")
                            t_low_local = text.lower()
                            # If the user wants timestamps, format differently
                            wants_timestamps = any(k in t_low_local for k in
                                ["timestamp", "time stamp", "time-stamp",
                                 "key moments", "chapters"])
                            if wants_timestamps:
                                # Give Claude the timestamped segments and ask
                                # for ~5 timestamps
                                stamped = format_with_timestamps(
                                    result["segments"], max_marks=20
                                )
                                prompt = (
                                    f"{text}\n\n"
                                    f"Here are the timestamped video segments. "
                                    f"Pick 5-7 KEY moments and return them as "
                                    f"'mm:ss — what happens' lines:\n\n{stamped}"
                                )
                            else:
                                # General summary
                                prompt = (
                                    f"{text}\n\n"
                                    f"Here is the full transcript of this YouTube "
                                    f"video. Answer concisely in plain text:\n\n"
                                    f"{full_text[:9000]}"
                                )
                            msgs = conversation_history[-6:] + [
                                {"role": "user", "content": prompt}
                            ]
                            answer = await _stream_to_channel(
                                client, FAST_MODEL, msgs, channel, max_tokens=700
                            )
                            if not answer or len(answer.strip()) < 30:
                                # Stream failed — non-stream retry
                                try:
                                    resp = client.messages.create(
                                        model=FAST_MODEL, max_tokens=700,
                                        messages=msgs,
                                    )
                                    answer = resp.content[0].text.strip()
                                    if answer:
                                        await channel.delta(answer)
                                        await channel.done(final_text=answer)
                                except Exception as e:
                                    print(f"[youtube] retry failed: {e}")
                                    answer = ""
                            if answer and len(answer) > 30:
                                elapsed = time.time() - t0
                                print(f"[ipc] ◀ youtube done in {elapsed:.2f}s")
                                conversation_history.append({"role":"user","content":text})
                                conversation_history.append({"role":"assistant","content":answer})
                                save_conversation(conversation_history)
                                return
                        else:
                            print(f"[youtube] no transcript available, falling back")
                except ImportError:
                    print(f"[youtube] youtube-transcript-api not installed")
                except Exception as e:
                    print(f"[youtube] error: {e}")

            if is_video:
                # Generic video fallback (or YouTube without captions)
                site_name = "YouTube" if "youtu" in url_low else "this video"
                workaround_msg = (
                    f"Couldn't fetch the transcript for this {site_name} video "
                    f"(may be private, age-restricted, or have captions disabled).\n\n"
                    f"To get a summary anyway:\n"
                    f"• Click 'Show transcript' under the video, copy it (Cmd+A, Cmd+C), "
                    f"and paste it here with 'summarize this'\n"
                    f"• Or open the video's description and ask me about that"
                )
                await channel.delta(workaround_msg)
                await channel.done(final_text=workaround_msg)
                elapsed = time.time() - t0
                print(f"[ipc] ◀ video workaround in {elapsed:.2f}s")
                conversation_history.append({"role":"user","content":text})
                conversation_history.append({"role":"assistant","content":workaround_msg})
                save_conversation(conversation_history)
                return
            print(f"[fetch] {url[:60]} is on scrape-block list, going straight to vision")

        # ── Selection-text path (when AX captured text) ──────────────────
        if is_chip and selection:
            print(f"[ipc] using AX selection ({len(selection)} chars)")
            try:
                augmented = (f"{text}\n\nSelected text from {app or 'the active app'}:\n"
                             f"```\n{selection[:3000]}\n```")
                msgs = conversation_history[-6:] + [
                    {"role": "user", "content": augmented}
                ]
                answer = await _stream_to_channel(
                    client, FAST_MODEL, msgs, channel, max_tokens=600
                )
                elapsed = time.time() - t0
                print(f"[ipc] ◀ selection+stream done in {elapsed:.2f}s")
                conversation_history.append({"role":"user","content":text})
                conversation_history.append({"role":"assistant","content":answer})
                save_conversation(conversation_history)
                return
            except Exception as e:
                print(f"[ipc] selection path failed: {e}, falling back")

        # ── Direct file read path (best for code editors) ─────────────────
        # If we resolved the actual file path, use the file contents directly.
        # This is faster, more accurate, and lets Sonnet see the FULL file
        # regardless of scroll position.
        t_low = text.lower()
        is_code_query = any(k in t_low for k in [
            "fix", "bug", "refactor", "explain", "review", "improve",
            "complete", "comment", "rewrite", "what does this code",
            "find any bug", "code review",
        ])
        if actual_file_content and is_code_query:
            wants_fix = any(k in t_low for k in [
                "fix", "correct", "refactor", "rewrite", "improve",
                "complete", "make it work",
            ])
            print(f"[code-file] using file directly, skipping vision")
            try:
                file_ext = os.path.splitext(actual_file_path)[1].lstrip(".") or "text"
                if wants_fix:
                    file_prompt = (
                        f"{text}\n\n"
                        f"Here is the COMPLETE source file the user has open "
                        f"({actual_file_path}). Read it carefully, then output:\n\n"
                        f"1. ONE short sentence describing what was wrong (max 25 words)\n"
                        f"2. A SINGLE fenced code block (```{file_ext}\\n...\\n```) "
                        f"containing the COMPLETE corrected file.\n\n"
                        f"CRITICAL:\n"
                        f"- Output the WHOLE file from line 1 to the last line.\n"
                        f"- Include ALL imports, ALL classes, ALL functions.\n"
                        f"- Keep code that wasn't broken — don't omit anything.\n"
                        f"- NEVER use ellipsis or '# rest unchanged'.\n"
                        f"- The code block must be a 100% drop-in replacement.\n\n"
                        f"=== CURRENT FILE CONTENTS ===\n"
                        f"```{file_ext}\n{actual_file_content}\n```"
                    )
                else:
                    file_prompt = (
                        f"{text}\n\n"
                        f"Here is the source file the user is asking about "
                        f"({actual_file_path}):\n\n"
                        f"```{file_ext}\n{actual_file_content}\n```"
                    )
                msgs = [{"role": "user", "content": file_prompt}]
                answer = await _stream_to_channel(
                    client, "claude-sonnet-4-6", msgs, channel,
                    max_tokens=4000 if wants_fix else 800,
                )
                if not answer or len(answer.strip()) < 30:
                    # Stream failed — non-stream retry
                    try:
                        resp = client.messages.create(
                            model="claude-sonnet-4-6",
                            max_tokens=4000 if wants_fix else 800,
                            messages=msgs,
                        )
                        answer = resp.content[0].text.strip()
                        await channel.delta(answer)
                        await channel.done(final_text=answer)
                    except Exception as e:
                        print(f"[code-file] retry failed: {e}")
                        answer = ""
                if answer and len(answer) > 30:
                    elapsed = time.time() - t0
                    print(f"[ipc] ◀ code-file done in {elapsed:.2f}s")
                    conversation_history.append({"role":"user","content":text})
                    conversation_history.append({"role":"assistant","content":answer})
                    save_conversation(conversation_history)
                    return
            except Exception as e:
                print(f"[code-file] failed: {e}, falling through to vision")

        # ── File-system query path (PDFs, docs, spreadsheets) ────────────
        # Recognize queries like:
        #   "find the pdf about taxes in my downloads"
        #   "read the climate report and summarize it"
        #   "extract the table from this pdf into a spreadsheet"
        if _FILE_AGENT_AVAILABLE and _file_agent.looks_like_file_query(text):
            print(f"[file-agent] handling file query: {text[:80]}")
            try:
                answer = await _handle_file_query(text, channel, client)
                if answer:
                    elapsed = time.time() - t0
                    print(f"[ipc] ◀ file-agent done in {elapsed:.2f}s")
                    conversation_history.append({"role":"user","content":text})
                    conversation_history.append({"role":"assistant","content":answer})
                    save_conversation(conversation_history)
                    return
            except Exception as e:
                print(f"[file-agent] failed: {e}")
                import traceback; traceback.print_exc()

        # ── Vision path (fallback for non-browser screen reading) ────────
        if wants_screen:
            print(f"[vision] using screenshot for query (path={screenshot})")
            try:
                import base64
                with open(screenshot, "rb") as f:
                    img_b64 = base64.standard_b64encode(f.read()).decode("utf-8")

                ctx_hint = []
                if app:       ctx_hint.append(f"App: {app}")
                if category:  ctx_hint.append(f"Category: {category}")
                if selection: ctx_hint.append(f"User has this selected: {selection[:300]}")
                if url:       ctx_hint.append(f"URL: {url}")
                hint_str = "\n".join(ctx_hint) if ctx_hint else ""

                # In a code editor, the user almost always wants the FIXED code
                # back so they can Apply it. Use a tailored prompt that demands
                # a code block.
                t_low = text.lower()
                in_code_editor = (category == "code")
                wants_fix = in_code_editor and any(k in t_low for k in [
                    "fix", "correct", "refactor", "rewrite", "improve",
                    "complete the code", "complete this", "finish",
                    "make it work", "make this work",
                ])
                wants_explain = in_code_editor and any(k in t_low for k in [
                    "explain", "what does", "what is this code", "describe",
                    "walk me through",
                ])

                if wants_fix:
                    vision_prompt = (
                        f"{text}\n\n"
                        f"You are looking at code in {app or 'a code editor'}. "
                        f"Your output may be pasted DIRECTLY into the editor as a "
                        f"complete file replacement (Cmd+A then paste).\n\n"
                        f"FIRST, decide: can you see the ENTIRE file from top to bottom?\n\n"
                        f"IF YES — output:\n"
                        f"1. ONE short sentence describing what was wrong (max 20 words)\n"
                        f"2. A SINGLE fenced code block with the ENTIRE corrected file. "
                        f"Include ALL imports, ALL classes, ALL functions, ALL existing code. "
                        f"NEVER use ellipsis or '# rest unchanged'. Drop-in replacement.\n\n"
                        f"IF NO (the file is scrolled mid-way or only part is visible) — output:\n"
                        f"1. A sentence explaining you can only see part of the file.\n"
                        f"2. A description of any bugs you DO see in the visible portion.\n"
                        f"3. A short note: 'To get a fix you can Apply, scroll to the top "
                        f"of the file (Cmd+Home) and try again.'\n"
                        f"DO NOT output a code block in this case — partial code would "
                        f"break the file when applied.\n\n"
                        f"{hint_str}"
                    ).strip()
                elif wants_explain:
                    vision_prompt = (
                        f"{text}\n\n"
                        f"You are looking at code in {app or 'a code editor'}. "
                        f"Read the visible code, then explain it briefly — what it "
                        f"does, key flow, any notable patterns. Plain text. "
                        f"3-5 sentences.\n\n"
                        f"{hint_str}"
                    ).strip()
                else:
                    vision_prompt = (
                        f"{text}\n\n"
                        f"You are looking at a screenshot of the user's frontmost "
                        f"window. Use it to answer their question concretely. "
                        f"Be specific and brief — 2-4 sentences unless they asked "
                        f"for something longer. Plain text, no markdown headers.\n\n"
                        f"{hint_str}"
                    ).strip()

                # Vision tiering — pick model based on query intent.
                # Sonnet is required for: dense charts, code in editors, news
                # articles (small body text amid ads), explicit "find bugs/refactor"
                wants_dense = any(k in t_low for k in [
                    "chart", "graph", "table", "diagram", "flowchart",
                    "explain this code", "review this code", "find bugs",
                    "find any bugs", "code review", "fix these bugs",
                    "fix this bug", "refactor", "complete the code",
                    "is this code", "what does this code", "improve this code",
                ])
                # News articles on scrape-blocked sites benefit from Sonnet
                # because vision needs to OCR small body text amid ads/banners
                is_news_summary = (
                    any(d in (url or "").lower() for d in [
                        "cnn.com", "nytimes.com", "wsj.com", "washingtonpost.com",
                        "bloomberg.com", "ft.com", "theguardian.com", "reuters.com",
                        "bbc.com", "apnews.com", "axios.com", "politico.com",
                    ])
                    and any(k in t_low for k in ["summar", "takeaway", "tldr",
                                                  "key point", "main point", "bias"])
                )
                # Code editors: Haiku vision is materially worse at reading
                # monospace code. Always use Sonnet when the user is in a
                # code editor and asking about code.
                in_code_editor = (category == "code")
                code_query = any(k in t_low for k in [
                    "code", "bug", "function", "method", "class", "variable",
                    "syntax", "error", "fix", "complete", "implement",
                    "refactor", "test", "lint",
                ])
                use_sonnet_for_code = in_code_editor and code_query
                vision_model = (VISION_MODEL_DENSE
                                if (wants_dense or is_news_summary or use_sonnet_for_code)
                                else VISION_MODEL)
                print(f"[vision] using {vision_model.split('-')[1]}")

                # Bigger token budget when we're returning a full corrected file
                vision_max = 4000 if (in_code_editor and wants_fix) else 600

                # Stream code fixes so long files animate in smoothly.
                # For short answers (<600 tokens), one-shot is fine.
                vision_messages = [{
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": img_b64,
                        }},
                        {"type": "text", "text": vision_prompt},
                    ],
                }]

                if in_code_editor and wants_fix:
                    # Stream — long responses need to render incrementally
                    answer = await _stream_to_channel(
                        client, vision_model, vision_messages,
                        channel, max_tokens=vision_max,
                    )
                    if not answer or len(answer.strip()) < 30:
                        # Stream failed — non-stream retry
                        try:
                            resp = client.messages.create(
                                model=vision_model, max_tokens=vision_max,
                                messages=vision_messages,
                            )
                            answer = resp.content[0].text.strip()
                            await channel.delta(answer)
                            await channel.done(final_text=answer)
                        except Exception as e:
                            print(f"[vision] retry failed: {e}")
                            answer = ""
                else:
                    resp = client.messages.create(
                        model=vision_model,
                        max_tokens=vision_max,
                        messages=vision_messages,
                    )
                    answer = resp.content[0].text.strip()
                    await channel.delta(answer)
                    await channel.done(final_text=answer)

                elapsed = time.time() - t0
                print(f"[ipc] ◀ vision done in {elapsed:.2f}s")
                # Update conversation memory so follow-ups work
                conversation_history.append({"role":"user","content":text})
                conversation_history.append({"role":"assistant","content":answer or ""})
                save_conversation(conversation_history)
                return
            except Exception as e:
                print(f"[vision] failed: {e}, falling back")

        augmented = text

        # ── Feature 4: Smart reply hint for Mail / Messages ───────────────
        # When the user is in a mail or messaging app, inject a system-level
        # hint into SYSTEM_PROMPT_PERSONALIZATION so Claude writes complete,
        # ready-to-send replies matching the conversation's tone.
        _smart_reply_injected = False
        if category in ("mail", "messaging"):
            _smart_reply_hint = (
                "\n\nThe user is currently in a mail or messaging app. "
                "If they ask to reply or draft a message, write a complete, "
                "ready-to-send reply. Keep it concise and match the tone of "
                "the conversation."
            )
            global SYSTEM_PROMPT_PERSONALIZATION
            SYSTEM_PROMPT_PERSONALIZATION += _smart_reply_hint
            _smart_reply_injected = True

        # ── Default path: route through the existing _handle_command ─────
        loop = asyncio.get_event_loop()
        try:
            result = await asyncio.wait_for(
                loop.run_in_executor(
                    None, lambda: _handle_command(augmented, speak_response=False)
                ),
                timeout=45.0,
            )
        except asyncio.TimeoutError:
            print(f"[ipc] ✗ handler timed out after 45s")
            await channel.error("Took too long, aborted.")
            return
        except Exception as e:
            print(f"[ipc] ✗ handler error: {e}")
            await channel.error(f"Handler error: {e}")
            import traceback; traceback.print_exc()
            return

        elapsed = time.time() - t0
        print(f"[ipc] ◀ done in {elapsed:.2f}s: {(result or '')[:60]}")

        if result:
            await channel.delta(result)
            await channel.done(final_text=result)
        else:
            await channel.done(final_text="Done.")

        conversation_history.append({"role":"user","content":text})
        conversation_history.append({"role":"assistant","content":result or ""})
        save_conversation(conversation_history)

    async def _handle_file_query(text: str, channel, client) -> str:
        """
        Handle file-related queries: find files, read PDFs/docs, write spreadsheets.

        Strategy:
          1. Use Haiku to PLAN the query → classify intent and extract params
          2. Execute the plan: find files, read them, summarize, write outputs
          3. Stream progress to the bar so the user knows what's happening

        Returns the final answer string (also already streamed to channel).
        """
        if not _FILE_AGENT_AVAILABLE:
            err = "File-agent module is not available."
            await channel.delta(err); await channel.done(final_text=err)
            return err

        # 1. Plan with Haiku
        plan_prompt = (
            f"User said: {text!r}\n\n"
            f"Decide what they want and produce a JSON plan. Available actions:\n"
            f"  - find: search for files. Args: query (substring), kind "
            f"(pdf/docx/xlsx/csv/text/code/etc, optional), since_days (int, optional).\n"
            f"  - read: read a specific file. Args: path (must be absolute, or use a previous find result).\n"
            f"  - summarize: summarize text the user already named.\n"
            f"  - extract_to_spreadsheet: read a file and produce structured rows. Args: source_path, output_name.\n"
            f"  - extract_to_csv: same but CSV.\n"
            f"  - none: this isn't actually a file query.\n\n"
            f"Output ONLY a JSON object:\n"
            f'{{"action": "find|read|extract_to_spreadsheet|extract_to_csv|none",\n'
            f'  "find_query": "<filename substring>",\n'
            f'  "kind": "<file kind or empty>",\n'
            f'  "since_days": <int or null>,\n'
            f'  "output_name": "<for spreadsheet output, optional>",\n'
            f'  "follow_up": "summarize|tabulate|none — what to do after reading"\n'
            f"}}\n"
            f"Be specific. If the user says 'pdf about taxes', set find_query to "
            f"the topic words (e.g. 'tax'). Strip filler words. No prose, JSON only."
        )
        try:
            plan_resp = client.messages.create(
                model=FAST_MODEL, max_tokens=400,
                messages=[{"role": "user", "content": plan_prompt}],
            )
            plan_text = plan_resp.content[0].text.strip()
            # Strip code fences if present
            plan_text = re.sub(r"^```(?:json)?\s*", "", plan_text)
            plan_text = re.sub(r"\s*```$", "", plan_text)
            plan = json.loads(plan_text)
            print(f"[file-agent] plan: {plan}")
        except Exception as e:
            err = f"Couldn't understand the file request: {e}"
            await channel.delta(err); await channel.done(final_text=err)
            return err

        action = plan.get("action", "none")
        if action == "none":
            err = "That doesn't look like a file query I can handle."
            await channel.delta(err); await channel.done(final_text=err)
            return err

        # 2. FIND files
        find_query = plan.get("find_query") or ""
        kind = plan.get("kind") or None
        since_days = plan.get("since_days") or None

        await channel.status(f"Searching for files...")
        files = _file_agent.find_files(
            query=find_query, kind=kind, since_days=since_days, limit=15,
        )
        print(f"[file-agent] found {len(files)} files for {find_query!r}")

        if not files:
            msg = (f"I couldn't find any files matching {find_query!r} "
                   f"in your Downloads, Documents, or Desktop.")
            await channel.delta(msg); await channel.done(final_text=msg)
            return msg

        # If user just wanted to FIND files, list them
        if action == "find":
            lines = [f"Found {len(files)} files:"]
            for f in files[:10]:
                size_kb = f["size"] / 1024
                lines.append(
                    f"  • **{f['name']}** ({f['kind']}, "
                    f"{size_kb:.0f} KB, {f['mtime_str']})"
                )
                lines.append(f"    `{f['path']}`")
            answer = "\n".join(lines)
            await channel.delta(answer); await channel.done(final_text=answer)
            return answer

        # For READ / EXTRACT actions, pick the best file (most recent matching)
        target = files[0]
        path = target["path"]
        await channel.status(f"Reading {target['name']}...")
        await channel.delta(f"Reading **{target['name']}**...\n\n")

        result = _file_agent.read_file(path)
        if not result["ok"]:
            msg = f"Failed to read {target['name']}: {result['error']}"
            await channel.delta(msg); await channel.done(final_text=msg)
            return msg

        file_text = result["text"]
        print(f"[file-agent] read {len(file_text)} chars from {path}")

        # 3. ACT on the file content
        if action == "extract_to_spreadsheet" or action == "extract_to_csv":
            return await _extract_to_spreadsheet(
                text, file_text, target, plan, channel, client,
                use_csv=(action == "extract_to_csv"),
            )

        # action == "read" (with optional follow-up summarize/etc)
        # Summarize/answer using Haiku with the file content
        follow = plan.get("follow_up") or "summarize"
        if follow == "summarize" or "summar" in text.lower():
            summary_prompt = (
                f"The user asked: {text!r}\n\n"
                f"Here is the content of {target['name']}:\n\n"
                f"```\n{file_text[:80000]}\n```\n\n"
                f"Answer the user's question concisely. Use markdown bullets "
                f"or short paragraphs. Don't repeat the filename."
            )
        else:
            summary_prompt = (
                f"User question: {text!r}\n\n"
                f"Content of {target['name']}:\n\n"
                f"```\n{file_text[:80000]}\n```"
            )

        msgs = [{"role": "user", "content": summary_prompt}]
        answer = await _stream_to_channel(
            client, FAST_MODEL, msgs, channel, max_tokens=1500,
        )
        return answer or ""


    async def _extract_to_spreadsheet(user_text: str, file_text: str,
                                       target: dict, plan: dict,
                                       channel, client,
                                       use_csv: bool = False) -> str:
        """Extract structured rows from file_text and write to xlsx/csv."""
        await channel.status(f"Extracting structured data...")

        kind_label = "CSV" if use_csv else "spreadsheet"
        ext = "csv" if use_csv else "xlsx"

        extract_prompt = (
            f"User asked: {user_text!r}\n\n"
            f"From this document, extract the most useful tabular data and "
            f"return ONLY a JSON object of the form:\n"
            f'{{"title": "<short sheet name>",\n'
            f'  "rows": [["Header1", "Header2", ...],\n'
            f'           ["row1cell1", "row1cell2", ...],\n'
            f'           ...]}}\n\n'
            f"Rules:\n"
            f"- First row is HEADERS (column names).\n"
            f"- All cell values must be strings or numbers (no nested objects).\n"
            f"- Pick the most useful columns for what the user asked.\n"
            f"- Keep it under 100 data rows.\n"
            f"- If nothing tabular makes sense, return rows: [] and we'll skip.\n\n"
            f"Document content:\n```\n{file_text[:80000]}\n```"
        )
        try:
            resp = client.messages.create(
                model=FAST_MODEL, max_tokens=4000,
                messages=[{"role": "user", "content": extract_prompt}],
            )
            raw = resp.content[0].text.strip()
            raw = re.sub(r"^```(?:json)?\s*", "", raw)
            raw = re.sub(r"\s*```$", "", raw)
            data = json.loads(raw)
        except Exception as e:
            msg = f"Couldn't structure the data: {e}"
            await channel.delta(msg); await channel.done(final_text=msg)
            return msg

        rows = data.get("rows", [])
        if not rows or len(rows) < 2:
            msg = "Couldn't find tabular data in this document."
            await channel.delta(msg); await channel.done(final_text=msg)
            return msg

        # Build output filename
        title = data.get("title") or target["name"].rsplit(".", 1)[0]
        # Sanitize for filename
        safe_title = re.sub(r"[^A-Za-z0-9_\- ]", "", title).strip() or "extract"
        out_name = (plan.get("output_name") or safe_title)[:60]
        if not out_name.endswith("." + ext):
            out_name = out_name.rstrip(".") + "." + ext
        out_path = str(Path.home() / "Downloads" / out_name)

        # Write the file
        if use_csv:
            wr = _file_agent.write_csv(out_path, rows)
        else:
            wr = _file_agent.write_xlsx(out_path, rows, sheet_name=safe_title[:31])

        if not wr["ok"]:
            msg = f"Failed to create {kind_label}: {wr['error']}"
            await channel.delta(msg); await channel.done(final_text=msg)
            return msg

        # Open it for the user
        _file_agent.open_file(wr["path"])

        n_rows = len(rows) - 1  # minus header
        n_cols = len(rows[0]) if rows else 0
        msg = (f"Created **{out_name}** with {n_rows} rows × {n_cols} columns "
               f"and opened it for you.\n\n"
               f"`{wr['path']}`")
        await channel.delta(msg); await channel.done(final_text=msg)
        return msg


    async def apply_handler(code: str, target_pid: int, target_app: str):
        """Activate target app, select all, then paste the code as a full replacement."""
        print(f"[apply] inserting {len(code)} chars into {target_app} (pid={target_pid})")
        # Activate the target app first so the paste lands in it
        if target_pid > 0:
            try:
                subprocess.run(
                    ["osascript", "-e",
                     f'tell application "System Events" to set frontmost of (first process whose unix id is {target_pid}) to true'],
                    capture_output=True, timeout=2,
                )
            except Exception as e:
                print(f"[apply] activation failed: {e}")

        # Wait for the app to come fully forward — without this, Cmd+A
        # hits the bar before VS Code has key focus
        await asyncio.sleep(0.35)

        # Select-all first — Sonnet returns the COMPLETE corrected file, so
        # we want to replace the whole document, not paste at cursor (which
        # would duplicate or merge).
        try:
            subprocess.run(
                ["osascript", "-e",
                 'tell application "System Events" to keystroke "a" using {command down}'],
                capture_output=True, timeout=2,
            )
            await asyncio.sleep(0.12)
        except Exception as e:
            print(f"[apply] select-all failed: {e}")

        # Now paste the corrected code over the selection
        try:
            from fast_typing import insert_text
            ok, _method = insert_text(code)
            print(f"[apply] {'replaced selection with code' if ok else 'paste failed'}")
        except Exception as e:
            print(f"[apply] fast_typing error: {e}")

    async def bg_status_handler() -> dict:
        """Return current background task summary for the bar's indicator."""
        if not _BG_AVAILABLE:
            return {"running": 0, "unread": 0, "tasks": []}
        running = sum(1 for r in _bg._tasks.values() if r["status"] == "running")
        unread = sum(1 for r in _bg._tasks.values()
                     if r["status"] in ("done", "error") and not r["consumed"])
        # Send a compact list for the dropdown
        tasks = []
        for r in _bg._tasks.values():
            tasks.append({
                "id": r["id"],
                "query": r["query"][:80],
                "status": r["status"],
                "started_at": r["started_at"],
                "completed_at": r.get("completed_at"),
                "elapsed": int(time.time() - r["started_at"]),
            })
        # Most recent first
        tasks.sort(key=lambda t: -t["started_at"])
        return {"running": running, "unread": unread, "tasks": tasks[:10]}

    async def main():
        server = IPCServer(query_handler,
                           apply_handler=apply_handler,
                           bg_status_handler=bg_status_handler,
                           on_connect=on_connect)
        await server.start()
        # Keep the loop alive forever
        await asyncio.Event().wait()

    try:
        asyncio.run(main())
    except Exception as e:
        print(f"[ipc] server crashed: {e}")


def register_hotkey():
    try:
        from pynput import keyboard as kb
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "pynput",
                        "--quiet", "--break-system-packages"], check=False)
        from pynput import keyboard as kb

    pressed = set()

    def on_press(key):
        pressed.add(key)
        try:
            target = {kb.Key.cmd, kb.Key.shift, kb.KeyCode.from_char("j")}
            if not all(k in pressed for k in target):
                return
            print("[hotkey] Cmd+Shift+J")
            if _bar_root:
                _bar_root.after(0, toggle_bar)
        except Exception as e:
            print(f"[hotkey] error: {e}")

    def on_release(key):
        pressed.discard(key)

    listener = kb.Listener(on_press=on_press, on_release=on_release)
    listener.daemon = True
    listener.start()
    print("Hotkey: Cmd+Shift+J")


def voice_loop():
    while True:
        pcm = record_until_silence(timeout=30)
        if not pcm: continue
        text = transcribe(pcm)
        if not text: continue
        print(f"You: {text}")
        if any(w in text.lower() for w in ["goodbye","bye","stop listening"]):
            speak("Later."); os._exit(0)
        process_command(text)


def both_loop():
    while True:
        vr = [None]
        def _vt():
            pcm = record_until_silence(timeout=10)
            if pcm: vr[0] = transcribe(pcm)
        t = threading.Thread(target=_vt, daemon=True)
        t.start(); t.join(timeout=12)
        if vr[0]:
            text = vr[0]
            print(f"You: {text}")
            if any(w in text.lower() for w in ["goodbye","bye","stop"]):
                speak("Later."); os._exit(0)
            process_command(text)


def terminal_input_loop():
    """Run terminal input in background thread — doesn't block tkinter."""
    while True:
        try:
            text = sys.stdin.readline()
            if not text:
                break
            text = text.strip()
        except Exception:
            break
        if not text: continue
        if any(w in text.lower() for w in ["bye","exit","quit"]):
            print("Bye."); os._exit(0)
        result = process_command_text(text)
        print(f"Alfred: {result}")

def _seed_demo_data():
    """Preload background task results and memory entries for a polished demo.

    Called when --demo flag is passed. Makes "what did you find?" instantly
    show structured output, makes "when's mom's birthday?" work, etc.
    No live API calls — everything is pre-canned for speed.
    """
    print("[demo] seeding sample background tasks and memory...")
    if _BG_AVAILABLE:
        # Pre-completed AI news research
        ai_id = uuid.uuid4().hex[:6]
        _bg._tasks[ai_id] = {
            "id": ai_id,
            "query": "research the latest AI news",
            "started_at": time.time() - 120,
            "completed_at": time.time() - 90,
            "status": "done",
            "result": (
                "**AI News — May 2026**\n\n"
                "Key developments this week:\n"
                "• **Anthropic** released Claude Opus 4.7 with extended thinking and improved coding ability\n"
                "• **AMD** announced Radeon AI PRO R9700 — 32GB VRAM workstation card targeting local LLM inference\n"
                "• **Apple** integrated Foundation Models into macOS 26, enabling on-device privacy-first AI\n"
                "• **Mistral** released Mistral Large 3 with state-of-the-art European language support\n"
                "• **OpenAI** launched GPT-5 Turbo, with prices cut 40% from GPT-5\n\n"
                "Sources: techcrunch.com, theverge.com, anthropic.com"
            ),
            "error": "", "task": None, "consumed": False,
        }
        # Pre-completed Bitcoin research
        btc_id = uuid.uuid4().hex[:6]
        _bg._tasks[btc_id] = {
            "id": btc_id,
            "query": "current bitcoin price and trend",
            "started_at": time.time() - 60,
            "completed_at": time.time() - 45,
            "status": "done",
            "result": (
                "**Bitcoin Price — May 2026**\n\n"
                "Current: **$80,242 USD** (+3.2% 24h)\n\n"
                "Key points:\n"
                "• 30-day high: $84,100 (Apr 28)\n"
                "• Trading volume: $42B (24h)\n"
                "• Active wallets: 1.2M (+8% week-over-week)\n"
                "• ETF inflows: $620M last week\n\n"
                "Sources: coinbase.com, coindesk.com"
            ),
            "error": "", "task": None, "consumed": False,
        }
        print(f"[demo] seeded {len(_bg._tasks)} bg tasks")

    if _GRAPH_AVAILABLE:
        try:
            _graph.add_fact("mom", "birthday", "October 12")
            _graph.add_fact("mom", "favorite_flower", "orchids")
            _graph.add_fact("dad", "birthday", "March 8")
            _graph.add_fact("user", "favorite_drink", "iced matcha")
            print(f"[demo] seeded memory graph entries")
        except Exception as e:
            print(f"[demo] memory seed failed: {e}")


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    global silent_mode, both_mode, ANTHROPIC_API_KEY, DEEPGRAM_API_KEY

    # Parse CLI flags
    parser = argparse.ArgumentParser(description="Alfred — Mac voice/text assistant")
    parser.add_argument('--mode', type=int, choices=[1, 2, 3],
                        help='Start in specific mode: 1=voice, 2=text, 3=both')
    parser.add_argument('--setup', action='store_true', help='Run setup wizard')
    parser.add_argument('--demo', action='store_true', help='Seed demo data on startup')
    args, _ = parser.parse_known_args()

    demo_mode = args.demo

    if args.setup:
        import setup_wizard
        setup_wizard.load_env_file()
        setup_wizard.run_wizard()
        return

    # First-run setup: load any existing .env, run wizard if key missing
    try:
        import setup_wizard
        setup_wizard.load_env_file()
        if setup_wizard.needs_setup():
            setup_wizard.run_wizard()
        # Re-read keys from environment after wizard / env load
        ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
        DEEPGRAM_API_KEY = os.environ.get("DEEPGRAM_API_KEY", "")
    except ImportError:
        pass

    init()

    if demo_mode:
        _seed_demo_data()

    selected_mode = args.mode

    if selected_mode:
        mode = str(selected_mode)
    elif not sys.stdin.isatty():
        # Running headless (stdin closed / redirected) — default to bar-only mode
        mode = "2"
    else:
        print("\n┌──────────────────────────────────────┐")
        print("│  Alfred - choose a mode:             │")
        if demo_mode:
            print("│  [DEMO MODE — preloaded tasks active]│")
        print("│  [1] Voice only                      │")
        print("│  [2] Text only (silent)              │")
        print("│  [3] Both (voice + text bar)         │")
        print("└──────────────────────────────────────┘")
        try:
            mode = input("Mode: ").strip()
        except EOFError:
            mode = "2"
    silent_mode = mode == "2"
    both_mode   = mode == "3"

    # Start IPC server (UDS) — the new bar uses this for instant streaming
    if _IPC_AVAILABLE and mode in ("2", "3"):
        threading.Thread(target=run_ipc_server, daemon=True).start()
    # Also keep the file-polling fallback running for compat with old bar binaries
    threading.Thread(target=watch_text_trigger, daemon=True).start()

    if mode == "1":
        speak("Ready.")
        try:
            voice_loop()
        except KeyboardInterrupt:
            speak("Later.")
        return

    # Modes 2 and 3 — launch native Swift bar
    start_bar()

    if mode == "2":
        print("Silent mode - Cmd+Shift+J for bar, or type below.")
        # Terminal input in background thread (reads from stdin)
        threading.Thread(target=terminal_input_loop, daemon=True).start()
    else:
        speak("Ready.")
        threading.Thread(target=both_loop, daemon=True).start()

    try:
        # Keep main thread alive — background threads do the work
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        if _bar_proc:
            _bar_proc.terminate()
        pass


if __name__ == "__main__":
    main()
