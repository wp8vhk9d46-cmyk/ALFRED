#!/bin/bash
# start_backend.sh — launch Alfred's Python backend without a terminal window.
# Bundled in Alfred.app/Contents/Resources/; run automatically by Alfred on startup.

ALFRED_APP="$HOME/.alfred/app"
LOG_DIR="$HOME/.alfred/logs"
mkdir -p "$LOG_DIR" "$HOME/.alfred/db"
echo "[start_backend] invoked at $(date)" >> "$LOG_DIR/backend_launch.log"

# Skip if already running
if pgrep -f "python.*assistant\.py" > /dev/null 2>&1; then
    echo "[start_backend] assistant.py already running — skipping" >> "$LOG_DIR/backend_launch.log"
    exit 0
fi

# Find the python3 that has 'anthropic' installed
PYTHON=""
for p in \
    /usr/local/bin/python3 \
    /opt/homebrew/bin/python3 \
    /opt/homebrew/bin/python3.13 \
    /opt/homebrew/bin/python3.12 \
    /opt/homebrew/bin/python3.11 \
    /usr/bin/python3 \
    $(which python3 2>/dev/null) \
    ; do
    if [ -x "$p" ] && "$p" -c "import anthropic" 2>/dev/null; then
        PYTHON="$p"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    osascript -e 'display alert "Alfred" message "Could not find a Python 3 installation with the '\''anthropic'\'' package.\n\nRun: pip3 install anthropic\nThen relaunch Alfred."'
    exit 1
fi

"$PYTHON" "$ALFRED_APP/assistant.py" --mode 2 \
    >> "$LOG_DIR/assistant.log" 2>&1 &
